import Frame from "../imports/index";

export default function App() {
  return (
    <div style={{ width: "1080px", height: "1080px", position: "relative", overflow: "hidden" }}>
      <Frame />
    </div>
  );
}
