import svgPaths from "./svg-maubxcy8q9";

function Group1() {
  return (
    <div className="absolute inset-[14.07%_89.63%_82.87%_6.76%]">
      <div className="absolute inset-[-16.06%_-13.59%]">
        <svg className="block size-full" fill="none" height="43.6" preserveAspectRatio="none" viewBox="0 0 49.6 43.6" width="49.6">
          <g id="Group 2">
            <path d={svgPaths.p37af6800} fill="#7FF425" id="Vector" />
            <g filter="url(#filter0_f_0_370)" id="Vector_2">
              <path d={svgPaths.p37af6800} fill="#7FF425" />
            </g>
          </g>
          <defs>
            <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="43.6" id="filter0_f_0_370" width="49.6" x="0" y="0">
              <feFlood floodOpacity="0" result="BackgroundImageFix" />
              <feBlend in="SourceGraphic" in2="BackgroundImageFix" mode="normal" result="shape" />
              <feGaussianBlur result="effect1_foregroundBlur_0_370" stdDeviation="2.65" />
            </filter>
          </defs>
        </svg>
      </div>
    </div>
  );
}

function Group() {
  return (
    <div className="absolute inset-[4.07%_75.93%_89.39%_5.83%]">
      <div className="absolute inset-[-10.91%_0_0_0]">
        <svg className="block size-full" fill="none" height="78.2893" preserveAspectRatio="none" viewBox="0 0 197 78.2893" width="197">
          <g id="Group 1">
            <g id="Group">
              <path d={svgPaths.p319ac300} fill="#7A7A7A" id="Vector" />
              <path d={svgPaths.pee92100} fill="#7A7A7A" id="Vector_2" />
            </g>
            <path d={svgPaths.p2250ba00} fill="#80F425" id="Vector_3" />
            <path d={svgPaths.p355f9700} fill="#80F425" id="Vector_4" />
            <g filter="url(#filter0_f_0_375)" id="Vector_5">
              <path d={svgPaths.p2250ba00} fill="#80F425" />
            </g>
            <g filter="url(#filter1_f_0_375)" id="Vector_6">
              <path d={svgPaths.p355f9700} fill="#80F425" />
            </g>
          </g>
          <defs>
            <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="74.2767" id="filter0_f_0_375" width="79.0083" x="63.5296" y="0">
              <feFlood floodOpacity="0" result="BackgroundImageFix" />
              <feBlend in="SourceGraphic" in2="BackgroundImageFix" mode="normal" result="shape" />
              <feGaussianBlur result="effect1_foregroundBlur_0_375" stdDeviation="3.85" />
            </filter>
            <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="63.2142" id="filter1_f_0_375" width="68.9747" x="97.1642" y="0.00282669">
              <feFlood floodOpacity="0" result="BackgroundImageFix" />
              <feBlend in="SourceGraphic" in2="BackgroundImageFix" mode="normal" result="shape" />
              <feGaussianBlur result="effect1_foregroundBlur_0_375" stdDeviation="3.85" />
            </filter>
          </defs>
        </svg>
      </div>
    </div>
  );
}

export default function Frame() {
  return (
    <div className="bg-white relative size-full">
      <div className="absolute bg-[#1b1b1b] left-0 size-[1080px] top-0" />
      <div className="absolute bg-[#161616] h-[942px] left-0 top-[138px] w-[1080px]" />
      <div className="absolute bg-[#161616] h-[942px] left-[331px] top-[138px] w-[749px]" />
      <div className="absolute bg-black h-[139px] left-0 top-[-1px] w-[1099px]" />
      <div className="absolute bg-[#1f1f1f] h-[64px] left-0 top-[138px] w-[331px]" />
      <div className="absolute bg-[#1f1f1f] h-[64px] left-0 top-[207px] w-[331px]" />
      <div className="absolute bg-[#1f1f1f] h-[64px] left-0 top-[276px] w-[331px]" />
      <div className="absolute bg-[#1f1f1f] h-[64px] left-0 top-[345px] w-[331px]" />
      <div className="absolute bg-[#1f1f1f] h-[64px] left-0 top-[902px] w-[331px]" />
      <div className="absolute bg-[#1f1f1f] h-[552px] left-0 top-[345px] w-[331px]" />
      <div className="absolute bg-[#1c1c1c] h-[64px] left-0 top-[411px] w-[331px]" />
      <div className="absolute bg-[#1c1c1c] h-[64px] left-0 top-[480px] w-[331px]" />
      <div className="absolute bg-[#1c1c1c] h-[64px] left-0 top-[549px] w-[331px]" />
      <div className="absolute bg-[#1c1c1c] h-[64px] left-0 top-[618px] w-[331px]" />
      <div className="absolute bg-[#1c1c1c] h-[64px] left-0 top-[687px] w-[331px]" />
      <div className="absolute bg-[#1c1c1c] h-[64px] left-0 top-[756px] w-[331px]" />
      <div className="absolute bg-[#1c1c1c] h-[64px] left-0 top-[825px] w-[331px]" />
      <div className="absolute flex h-[942px] items-center justify-center left-[333px] top-[138px] w-0">
        <div className="-rotate-90 flex-none">
          <div className="h-0 relative w-[942px]">
            <div className="absolute inset-[-8.3px_-0.77%_-7.3px_-0.77%]">
              <svg className="block size-full" fill="none" height="15.6" preserveAspectRatio="none" viewBox="0 0 956.6 15.6" width="956.6">
                <g filter="url(#filter0_f_0_374)" id="Line 1">
                  <line stroke="#00FF7B" x1="7.3" x2="949.3" y1="7.8" y2="7.8" />
                </g>
                <defs>
                  <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="15.6" id="filter0_f_0_374" width="956.6" x="0" y="0">
                    <feFlood floodOpacity="0" result="BackgroundImageFix" />
                    <feBlend in="SourceGraphic" in2="BackgroundImageFix" mode="normal" result="shape" />
                    <feGaussianBlur result="effect1_foregroundBlur_0_374" stdDeviation="3.65" />
                  </filter>
                </defs>
              </svg>
            </div>
          </div>
        </div>
      </div>
      <div className="absolute flex h-[942px] items-center justify-center left-[335px] top-[138px] w-0">
        <div className="-rotate-90 flex-none">
          <div className="h-0 relative w-[942px]">
            <div className="absolute inset-[-2px_0_0_0]">
              <svg className="block size-full" fill="none" height="2" preserveAspectRatio="none" viewBox="0 0 942 2" width="942">
                <line id="Line 3" stroke="#80F425" strokeWidth="2" x2="942" y1="1" y2="1" />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <div className="absolute h-0 left-0 top-[138px] w-[1080px]">
        <div className="absolute inset-[-1px_0_0_0]">
          <svg className="block size-full" fill="none" height="1" preserveAspectRatio="none" viewBox="0 0 1080 1" width="1080">
            <line id="Line 2" stroke="#80F425" x2="1080" y1="0.5" y2="0.5" />
          </svg>
        </div>
      </div>
      <div className="absolute h-0 left-0 top-[138px] w-[1080px]">
        <div className="absolute inset-[-6px_-0.37%_-4px_-0.37%]">
          <svg className="block size-full" fill="none" height="10" preserveAspectRatio="none" viewBox="0 0 1088 10" width="1088">
            <g filter="url(#filter0_f_0_369)" id="Line 4">
              <line stroke="#80F425" strokeWidth="2" x1="4" x2="1084" y1="5" y2="5" />
            </g>
            <defs>
              <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="10" id="filter0_f_0_369" width="1088" x="0" y="0">
                <feFlood floodOpacity="0" result="BackgroundImageFix" />
                <feBlend in="SourceGraphic" in2="BackgroundImageFix" mode="normal" result="shape" />
                <feGaussianBlur result="effect1_foregroundBlur_0_369" stdDeviation="2" />
              </filter>
            </defs>
          </svg>
        </div>
      </div>
      <div className="absolute bg-[#d9d9d9] h-[296px] left-[310px] rounded-[9px] top-[152px] w-[13px]" />
      <div className="absolute bg-[#d9d9d9] h-[296px] left-[1058px] rounded-[9px] top-[152px] w-[13px]" />
      <div className="absolute inset-[20.46%_89.63%_76.48%_6.76%]" data-name="Vector">
        <svg className="absolute block inset-0 size-full" fill="none" height="33" preserveAspectRatio="none" viewBox="0 0 39 33" width="39">
          <path d={svgPaths.p16914100} fill="#7FF425" id="Vector" />
        </svg>
      </div>
      <div className="absolute inset-[26.85%_89.63%_70.09%_6.76%]" data-name="Vector">
        <svg className="absolute block inset-0 size-full" fill="none" height="33" preserveAspectRatio="none" viewBox="0 0 39 33" width="39">
          <path d={svgPaths.p16914100} fill="#7FF425" id="Vector" />
        </svg>
      </div>
      <div className="absolute inset-[84.81%_89.63%_12.13%_6.76%]" data-name="Vector">
        <svg className="absolute block inset-0 size-full" fill="none" height="33" preserveAspectRatio="none" viewBox="0 0 39 33" width="39">
          <path d={svgPaths.p16914100} fill="#7FF425" id="Vector" />
        </svg>
      </div>
      <div className="absolute inset-[33.24%_89.63%_63.7%_6.76%]" data-name="Vector">
        <svg className="absolute block inset-0 size-full" fill="none" height="33" preserveAspectRatio="none" viewBox="0 0 39 33" width="39">
          <path d={svgPaths.p16914100} fill="#7FF425" id="Vector" />
        </svg>
      </div>
      <Group1 />
      <div className="absolute inset-[20.46%_89.63%_76.48%_6.76%]" data-name="Vector">
        <div className="absolute inset-[-16.06%_-13.59%]">
          <svg className="block size-full" fill="none" height="43.6" preserveAspectRatio="none" viewBox="0 0 49.6 43.6" width="49.6">
            <g filter="url(#filter0_f_0_366)" id="Vector">
              <path d={svgPaths.p37af6800} fill="#7FF425" />
            </g>
            <defs>
              <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="43.6" id="filter0_f_0_366" width="49.6" x="0" y="0">
                <feFlood floodOpacity="0" result="BackgroundImageFix" />
                <feBlend in="SourceGraphic" in2="BackgroundImageFix" mode="normal" result="shape" />
                <feGaussianBlur result="effect1_foregroundBlur_0_366" stdDeviation="2.65" />
              </filter>
            </defs>
          </svg>
        </div>
      </div>
      <div className="absolute inset-[26.85%_89.63%_70.09%_6.76%]" data-name="Vector">
        <div className="absolute inset-[-16.06%_-13.59%]">
          <svg className="block size-full" fill="none" height="43.6" preserveAspectRatio="none" viewBox="0 0 49.6 43.6" width="49.6">
            <g filter="url(#filter0_f_0_366)" id="Vector">
              <path d={svgPaths.p37af6800} fill="#7FF425" />
            </g>
            <defs>
              <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="43.6" id="filter0_f_0_366" width="49.6" x="0" y="0">
                <feFlood floodOpacity="0" result="BackgroundImageFix" />
                <feBlend in="SourceGraphic" in2="BackgroundImageFix" mode="normal" result="shape" />
                <feGaussianBlur result="effect1_foregroundBlur_0_366" stdDeviation="2.65" />
              </filter>
            </defs>
          </svg>
        </div>
      </div>
      <div className="absolute inset-[84.81%_89.63%_12.13%_6.76%]" data-name="Vector">
        <div className="absolute inset-[-16.06%_-13.59%]">
          <svg className="block size-full" fill="none" height="43.6" preserveAspectRatio="none" viewBox="0 0 49.6 43.6" width="49.6">
            <g filter="url(#filter0_f_0_366)" id="Vector">
              <path d={svgPaths.p37af6800} fill="#7FF425" />
            </g>
            <defs>
              <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="43.6" id="filter0_f_0_366" width="49.6" x="0" y="0">
                <feFlood floodOpacity="0" result="BackgroundImageFix" />
                <feBlend in="SourceGraphic" in2="BackgroundImageFix" mode="normal" result="shape" />
                <feGaussianBlur result="effect1_foregroundBlur_0_366" stdDeviation="2.65" />
              </filter>
            </defs>
          </svg>
        </div>
      </div>
      <div className="absolute inset-[33.24%_89.63%_63.7%_6.76%]" data-name="Vector">
        <div className="absolute inset-[-16.06%_-13.59%]">
          <svg className="block size-full" fill="none" height="43.6" preserveAspectRatio="none" viewBox="0 0 49.6 43.6" width="49.6">
            <g filter="url(#filter0_f_0_366)" id="Vector">
              <path d={svgPaths.p37af6800} fill="#7FF425" />
            </g>
            <defs>
              <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="43.6" id="filter0_f_0_366" width="49.6" x="0" y="0">
                <feFlood floodOpacity="0" result="BackgroundImageFix" />
                <feBlend in="SourceGraphic" in2="BackgroundImageFix" mode="normal" result="shape" />
                <feGaussianBlur result="effect1_foregroundBlur_0_366" stdDeviation="2.65" />
              </filter>
            </defs>
          </svg>
        </div>
      </div>
      <p className="[word-break:break-word] absolute font-['Inter:Regular',sans-serif] font-normal leading-[normal] left-[137px] not-italic text-[25.806px] text-white top-[156px] whitespace-nowrap">Músicas</p>
      <p className="[word-break:break-word] absolute font-['Inter:Regular',sans-serif] font-normal leading-[normal] left-[137px] not-italic text-[25.806px] text-white top-[225px] whitespace-nowrap">Memes</p>
      <p className="[word-break:break-word] absolute font-['Inter:Regular',sans-serif] font-normal leading-[normal] left-[137px] not-italic text-[25.806px] text-white top-[292px] whitespace-nowrap">Vídeos Me...</p>
      <p className="[word-break:break-word] absolute font-['Inter:Regular',sans-serif] font-normal leading-[normal] left-[137px] not-italic text-[25.806px] text-white top-[918px] whitespace-nowrap">Transições</p>
      <p className="[word-break:break-word] absolute font-['Inter:Regular',sans-serif] font-normal leading-[normal] left-[137px] not-italic text-[25.806px] text-white top-[361px] whitespace-nowrap">SFX</p>
      <p className="[word-break:break-word] absolute font-['Inter:Regular',sans-serif] font-normal leading-[normal] left-[109px] not-italic text-[25.806px] text-white top-[429px] whitespace-nowrap">Arquivo1.wav</p>
      <p className="[word-break:break-word] absolute font-['Inter:Regular',sans-serif] font-normal leading-[normal] left-[109px] not-italic text-[25.806px] text-white top-[496px] whitespace-nowrap">Arquivo2.wav</p>
      <p className="[word-break:break-word] absolute font-['Inter:Regular',sans-serif] font-normal leading-[normal] left-[109px] not-italic text-[25.806px] text-white top-[564px] whitespace-nowrap">Arquivo3.wav</p>
      <p className="[word-break:break-word] absolute font-['Inter:Regular',sans-serif] font-normal leading-[normal] left-[109px] not-italic text-[25.806px] text-white top-[633px] whitespace-nowrap">Arquivo4.wav</p>
      <p className="[word-break:break-word] absolute font-['Inter:Regular',sans-serif] font-normal leading-[normal] left-[109px] not-italic text-[25.806px] text-white top-[701px] whitespace-nowrap">Arquivo5.wav</p>
      <p className="[word-break:break-word] absolute font-['Inter:Regular',sans-serif] font-normal leading-[normal] left-[109px] not-italic text-[25.806px] text-white top-[772px] whitespace-nowrap">Arquivo6.wav</p>
      <p className="[word-break:break-word] absolute font-['Inter:Regular',sans-serif] font-normal leading-[normal] left-[109px] not-italic text-[25.806px] text-white top-[840px] whitespace-nowrap">Arquivo6.wav</p>
      <div className="absolute h-[15px] left-[40px] top-[161px] w-[7.5px]">
        <div className="absolute inset-[-15.31%_-20.47%_-15.31%_-30.61%]">
          <svg className="block size-full" fill="none" height="19.5918" preserveAspectRatio="none" viewBox="0 0 11.331 19.5918" width="11.331">
            <path d={svgPaths.p1a5bdde8} id="Vector 1" stroke="white" strokeLinecap="round" strokeWidth="4.59184" />
          </svg>
        </div>
      </div>
      <div className="absolute h-[15px] left-[40px] top-[230px] w-[7.5px]">
        <div className="absolute inset-[-15.31%_-20.47%_-15.31%_-30.61%]">
          <svg className="block size-full" fill="none" height="19.5918" preserveAspectRatio="none" viewBox="0 0 11.331 19.5918" width="11.331">
            <path d={svgPaths.p1a5bdde8} id="Vector 1" stroke="white" strokeLinecap="round" strokeWidth="4.59184" />
          </svg>
        </div>
      </div>
      <div className="absolute h-[15px] left-[40px] top-[299px] w-[7.5px]">
        <div className="absolute inset-[-15.31%_-20.47%_-15.31%_-30.61%]">
          <svg className="block size-full" fill="none" height="19.5918" preserveAspectRatio="none" viewBox="0 0 11.331 19.5918" width="11.331">
            <path d={svgPaths.p1a5bdde8} id="Vector 1" stroke="white" strokeLinecap="round" strokeWidth="4.59184" />
          </svg>
        </div>
      </div>
      <div className="absolute h-[15px] left-[40px] top-[925px] w-[7.5px]">
        <div className="absolute inset-[-15.31%_-20.47%_-15.31%_-30.61%]">
          <svg className="block size-full" fill="none" height="19.5918" preserveAspectRatio="none" viewBox="0 0 11.331 19.5918" width="11.331">
            <path d={svgPaths.p1a5bdde8} id="Vector 1" stroke="white" strokeLinecap="round" strokeWidth="4.59184" />
          </svg>
        </div>
      </div>
      <div className="absolute flex h-[7.5px] items-center justify-center left-[36.25px] top-[371.75px] w-[15px]">
        <div className="flex-none rotate-90">
          <div className="h-[15px] relative w-[7.5px]">
            <div className="absolute inset-[-15.31%_-20.47%_-15.31%_-30.61%]">
              <svg className="block size-full" fill="none" height="19.5918" preserveAspectRatio="none" viewBox="0 0 11.331 19.5918" width="11.331">
                <path d={svgPaths.p1a5bdde8} id="Vector 4" stroke="white" strokeLinecap="round" strokeWidth="4.59184" />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <div className="absolute bg-[#2a2a2a] h-[227px] left-[350px] top-[391px] w-[329px]" />
      <div className="absolute bg-[#2a2a2a] h-[227px] left-[350px] top-[630px] w-[329px]" />
      <div className="absolute bg-[#2a2a2a] h-[227px] left-[350px] top-[152px] w-[329px]" />
      <div className="absolute bg-[#232323] h-[187px] left-[362px] top-[164px] w-[304px]" />
      <div className="absolute bg-[#232323] h-[187px] left-[362px] top-[402px] w-[304px]" />
      <div className="absolute bg-[#232323] h-[187px] left-[362px] top-[640px] w-[304px]" />
      <div className="absolute bg-[#232323] h-[187px] left-[362px] top-[874px] w-[304px]" />
      <div className="absolute bg-[#2a2a2a] h-[227px] left-[694px] top-[391px] w-[329px]" />
      <div className="absolute bg-[#2a2a2a] h-[227px] left-[694px] top-[630px] w-[329px]" />
      <div className="absolute bg-[#2a2a2a] h-[227px] left-[350px] top-[870px] w-[329px]" />
      <div className="absolute bg-[#2a2a2a] h-[227px] left-[694px] top-[152px] w-[329px]" />
      <p className="[word-break:break-word] absolute font-['Inter:Regular',sans-serif] font-normal leading-[normal] left-[363px] not-italic text-[11.655px] text-white top-[357px] whitespace-nowrap">Arquivo1.wav</p>
      <p className="[word-break:break-word] absolute font-['Inter:Regular',sans-serif] font-normal leading-[normal] left-[363px] not-italic text-[11.655px] text-white top-[595px] whitespace-nowrap">Arquivo1.wav</p>
      <p className="[word-break:break-word] absolute font-['Inter:Regular',sans-serif] font-normal leading-[normal] left-[363px] not-italic text-[11.655px] text-white top-[833px] whitespace-nowrap">Arquivo1.wav</p>
      <p className="[word-break:break-word] absolute font-['Inter:Regular',sans-serif] font-normal leading-[normal] left-[363px] not-italic text-[11.655px] text-white top-[1071px] whitespace-nowrap">Arquivo1.wav</p>
      <p className="[word-break:break-word] absolute font-['Inter:Regular',sans-serif] font-normal leading-[normal] left-[706px] not-italic text-[11.655px] text-white top-[357px] whitespace-nowrap">Arquivo1.wav</p>
      <p className="[word-break:break-word] absolute font-['Inter:Regular',sans-serif] font-normal leading-[normal] left-[706px] not-italic text-[11.655px] text-white top-[595px] whitespace-nowrap">Arquivo1.wav</p>
      <p className="[word-break:break-word] absolute font-['Inter:Regular',sans-serif] font-normal leading-[normal] left-[706px] not-italic text-[11.655px] text-white top-[833px] whitespace-nowrap">Arquivo1.wav</p>
      <div className="absolute bg-[#232323] h-[187px] left-[706px] top-[164px] w-[304px]" />
      <div className="absolute bg-[#232323] h-[187px] left-[706px] top-[402px] w-[304px]" />
      <div className="absolute bg-[#232323] h-[187px] left-[706px] top-[640px] w-[304px]" />
      <div className="absolute bg-[#232323] h-[187px] left-[362px] top-[882px] w-[304px]" />
      <div className="absolute bg-[#7ff425] h-[133px] left-[634px] rounded-[7px] top-[185px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[35px] left-[634px] rounded-[7px] top-[478px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[69px] left-[634px] rounded-[7px] top-[705px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[133px] left-[634px] rounded-[7px] top-[917px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[133px] left-[979px] rounded-[7px] top-[185px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[133px] left-[979px] rounded-[7px] top-[429px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[133px] left-[979px] rounded-[7px] top-[673px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[87px] left-[620px] rounded-[7px] top-[208px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[39px] left-[620px] rounded-[7px] top-[476px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[87px] left-[620px] rounded-[7px] top-[696px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[87px] left-[620px] rounded-[7px] top-[940px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[87px] left-[965px] rounded-[7px] top-[208px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[87px] left-[965px] rounded-[7px] top-[452px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[87px] left-[965px] rounded-[7px] top-[696px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[55px] left-[606px] rounded-[7px] top-[224px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[55px] left-[606px] rounded-[7px] top-[468px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[35px] left-[606px] rounded-[7px] top-[722px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[55px] left-[606px] rounded-[7px] top-[956px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[55px] left-[951px] rounded-[7px] top-[224px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[55px] left-[951px] rounded-[7px] top-[468px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[35px] left-[951px] rounded-[7px] top-[722px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[69px] left-[592px] rounded-[7px] top-[217px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[69px] left-[592px] rounded-[7px] top-[461px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[69px] left-[592px] rounded-[7px] top-[705px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[69px] left-[592px] rounded-[7px] top-[949px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[69px] left-[937px] rounded-[7px] top-[217px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[69px] left-[937px] rounded-[7px] top-[461px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[69px] left-[937px] rounded-[7px] top-[705px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[47px] left-[578px] rounded-[7px] top-[228px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[47px] left-[578px] rounded-[7px] top-[472px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[47px] left-[578px] rounded-[7px] top-[716px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[47px] left-[578px] rounded-[7px] top-[960px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[47px] left-[923px] rounded-[7px] top-[228px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[47px] left-[923px] rounded-[7px] top-[472px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[35px] left-[923px] rounded-[7px] top-[722px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[25px] left-[564px] rounded-[7px] top-[239px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[25px] left-[564px] rounded-[7px] top-[483px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[25px] left-[564px] rounded-[7px] top-[727px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[25px] left-[564px] rounded-[7px] top-[971px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[25px] left-[909px] rounded-[7px] top-[239px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[25px] left-[909px] rounded-[7px] top-[483px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[25px] left-[909px] rounded-[7px] top-[727px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[17px] left-[550px] rounded-[7px] top-[243px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[17px] left-[550px] rounded-[7px] top-[487px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[17px] left-[550px] rounded-[7px] top-[731px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[17px] left-[550px] rounded-[7px] top-[975px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[17px] left-[895px] rounded-[7px] top-[243px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[17px] left-[895px] rounded-[7px] top-[487px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[17px] left-[895px] rounded-[7px] top-[731px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[17px] left-[536px] rounded-[7px] top-[243px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[17px] left-[536px] rounded-[7px] top-[487px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[17px] left-[536px] rounded-[7px] top-[731px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[17px] left-[536px] rounded-[7px] top-[975px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[17px] left-[881px] rounded-[7px] top-[243px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[17px] left-[881px] rounded-[7px] top-[487px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[17px] left-[881px] rounded-[7px] top-[731px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[17px] left-[522px] rounded-[7px] top-[243px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[17px] left-[522px] rounded-[7px] top-[487px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[17px] left-[522px] rounded-[7px] top-[731px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[17px] left-[522px] rounded-[7px] top-[975px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[17px] left-[867px] rounded-[7px] top-[243px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[17px] left-[867px] rounded-[7px] top-[487px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[17px] left-[867px] rounded-[7px] top-[731px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[17px] left-[508px] rounded-[7px] top-[243px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[73px] left-[508px] rounded-[7px] top-[459px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[17px] left-[508px] rounded-[7px] top-[731px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[17px] left-[508px] rounded-[7px] top-[975px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[17px] left-[853px] rounded-[7px] top-[243px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[17px] left-[853px] rounded-[7px] top-[487px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[17px] left-[853px] rounded-[7px] top-[731px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[17px] left-[494px] rounded-[7px] top-[243px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[17px] left-[494px] rounded-[7px] top-[487px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[17px] left-[494px] rounded-[7px] top-[731px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[17px] left-[494px] rounded-[7px] top-[975px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[17px] left-[839px] rounded-[7px] top-[243px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[17px] left-[839px] rounded-[7px] top-[487px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[83px] left-[839px] rounded-[7px] top-[698px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[17px] left-[480px] rounded-[7px] top-[243px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[17px] left-[480px] rounded-[7px] top-[487px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[17px] left-[480px] rounded-[7px] top-[731px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[35px] left-[480px] rounded-[7px] top-[722px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[17px] left-[480px] rounded-[7px] top-[975px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[17px] left-[825px] rounded-[7px] top-[243px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[17px] left-[825px] rounded-[7px] top-[487px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[25px] left-[825px] rounded-[7px] top-[727px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[17px] left-[466px] rounded-[7px] top-[243px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[17px] left-[466px] rounded-[7px] top-[487px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[69px] left-[466px] rounded-[7px] top-[705px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[17px] left-[466px] rounded-[7px] top-[975px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[37px] left-[811px] rounded-[7px] top-[233px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[17px] left-[811px] rounded-[7px] top-[487px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[17px] left-[811px] rounded-[7px] top-[731px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[17px] left-[452px] rounded-[7px] top-[243px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[17px] left-[452px] rounded-[7px] top-[487px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[17px] left-[452px] rounded-[7px] top-[731px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[17px] left-[452px] rounded-[7px] top-[975px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[69px] left-[797px] rounded-[7px] top-[217px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[17px] left-[797px] rounded-[7px] top-[487px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[17px] left-[797px] rounded-[7px] top-[731px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[17px] left-[438px] rounded-[7px] top-[243px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[59px] left-[438px] rounded-[7px] top-[466px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[17px] left-[438px] rounded-[7px] top-[731px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[17px] left-[438px] rounded-[7px] top-[975px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[37px] left-[783px] rounded-[7px] top-[233px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[17px] left-[783px] rounded-[7px] top-[487px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[17px] left-[783px] rounded-[7px] top-[731px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[17px] left-[424px] rounded-[7px] top-[243px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[139px] left-[424px] rounded-[7px] top-[426px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[17px] left-[424px] rounded-[7px] top-[731px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[41px] left-[424px] rounded-[7px] top-[963px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[17px] left-[769px] rounded-[7px] top-[243px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[17px] left-[769px] rounded-[7px] top-[487px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[17px] left-[769px] rounded-[7px] top-[731px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[17px] left-[410px] rounded-[7px] top-[243px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[39px] left-[410px] rounded-[7px] top-[476px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[17px] left-[410px] rounded-[7px] top-[731px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[83px] left-[410px] rounded-[7px] top-[942px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[17px] left-[755px] rounded-[7px] top-[243px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[17px] left-[755px] rounded-[7px] top-[487px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[25px] left-[755px] rounded-[7px] top-[727px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[17px] left-[396px] rounded-[7px] top-[243px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[17px] left-[396px] rounded-[7px] top-[487px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[17px] left-[396px] rounded-[7px] top-[731px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[47px] left-[396px] rounded-[7px] top-[960px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[17px] left-[741px] rounded-[7px] top-[243px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[17px] left-[741px] rounded-[7px] top-[487px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[61px] left-[741px] rounded-[7px] top-[709px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[17px] left-[382px] rounded-[7px] top-[243px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[17px] left-[382px] rounded-[7px] top-[487px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[17px] left-[382px] rounded-[7px] top-[731px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[17px] left-[382px] rounded-[7px] top-[975px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[17px] left-[727px] rounded-[7px] top-[243px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[17px] left-[727px] rounded-[7px] top-[487px] w-[10px]" />
      <div className="absolute bg-[#7ff425] h-[69px] left-[727px] rounded-[7px] top-[705px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[133px] left-[634px] rounded-[7px] top-[185px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[35px] left-[634px] rounded-[7px] top-[478px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[69px] left-[634px] rounded-[7px] top-[705px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[133px] left-[634px] rounded-[7px] top-[917px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[133px] left-[979px] rounded-[7px] top-[185px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[133px] left-[979px] rounded-[7px] top-[429px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[133px] left-[979px] rounded-[7px] top-[673px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[87px] left-[620px] rounded-[7px] top-[208px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[39px] left-[620px] rounded-[7px] top-[476px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[87px] left-[620px] rounded-[7px] top-[696px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[87px] left-[620px] rounded-[7px] top-[940px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[87px] left-[965px] rounded-[7px] top-[208px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[87px] left-[965px] rounded-[7px] top-[452px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[87px] left-[965px] rounded-[7px] top-[696px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[55px] left-[606px] rounded-[7px] top-[224px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[55px] left-[606px] rounded-[7px] top-[468px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[35px] left-[606px] rounded-[7px] top-[722px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[55px] left-[606px] rounded-[7px] top-[956px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[55px] left-[951px] rounded-[7px] top-[224px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[55px] left-[951px] rounded-[7px] top-[468px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[35px] left-[951px] rounded-[7px] top-[722px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[69px] left-[592px] rounded-[7px] top-[217px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[69px] left-[592px] rounded-[7px] top-[461px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[69px] left-[592px] rounded-[7px] top-[705px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[69px] left-[592px] rounded-[7px] top-[949px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[69px] left-[937px] rounded-[7px] top-[217px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[69px] left-[937px] rounded-[7px] top-[461px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[69px] left-[937px] rounded-[7px] top-[705px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[47px] left-[578px] rounded-[7px] top-[228px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[47px] left-[578px] rounded-[7px] top-[472px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[47px] left-[578px] rounded-[7px] top-[716px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[47px] left-[578px] rounded-[7px] top-[960px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[47px] left-[923px] rounded-[7px] top-[228px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[47px] left-[923px] rounded-[7px] top-[472px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[35px] left-[923px] rounded-[7px] top-[722px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[25px] left-[564px] rounded-[7px] top-[239px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[25px] left-[564px] rounded-[7px] top-[483px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[25px] left-[564px] rounded-[7px] top-[727px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[25px] left-[564px] rounded-[7px] top-[971px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[25px] left-[909px] rounded-[7px] top-[239px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[25px] left-[909px] rounded-[7px] top-[483px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[25px] left-[909px] rounded-[7px] top-[727px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[17px] left-[550px] rounded-[7px] top-[243px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[17px] left-[550px] rounded-[7px] top-[487px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[17px] left-[550px] rounded-[7px] top-[731px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[17px] left-[550px] rounded-[7px] top-[975px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[17px] left-[895px] rounded-[7px] top-[243px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[17px] left-[895px] rounded-[7px] top-[487px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[17px] left-[895px] rounded-[7px] top-[731px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[17px] left-[536px] rounded-[7px] top-[243px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[17px] left-[536px] rounded-[7px] top-[487px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[17px] left-[536px] rounded-[7px] top-[731px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[17px] left-[536px] rounded-[7px] top-[975px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[17px] left-[881px] rounded-[7px] top-[243px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[17px] left-[881px] rounded-[7px] top-[487px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[17px] left-[881px] rounded-[7px] top-[731px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[17px] left-[522px] rounded-[7px] top-[243px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[17px] left-[522px] rounded-[7px] top-[487px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[17px] left-[522px] rounded-[7px] top-[731px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[17px] left-[522px] rounded-[7px] top-[975px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[17px] left-[867px] rounded-[7px] top-[243px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[17px] left-[867px] rounded-[7px] top-[487px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[17px] left-[867px] rounded-[7px] top-[731px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[17px] left-[508px] rounded-[7px] top-[243px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[73px] left-[508px] rounded-[7px] top-[459px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[17px] left-[508px] rounded-[7px] top-[731px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[17px] left-[508px] rounded-[7px] top-[975px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[17px] left-[853px] rounded-[7px] top-[243px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[17px] left-[853px] rounded-[7px] top-[487px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[17px] left-[853px] rounded-[7px] top-[731px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[17px] left-[494px] rounded-[7px] top-[243px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[17px] left-[494px] rounded-[7px] top-[487px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[17px] left-[494px] rounded-[7px] top-[731px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[17px] left-[494px] rounded-[7px] top-[975px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[17px] left-[839px] rounded-[7px] top-[243px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[17px] left-[839px] rounded-[7px] top-[487px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[83px] left-[839px] rounded-[7px] top-[698px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[17px] left-[480px] rounded-[7px] top-[243px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[17px] left-[480px] rounded-[7px] top-[487px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[17px] left-[480px] rounded-[7px] top-[731px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[35px] left-[480px] rounded-[7px] top-[722px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[17px] left-[480px] rounded-[7px] top-[975px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[17px] left-[825px] rounded-[7px] top-[243px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[17px] left-[825px] rounded-[7px] top-[487px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[25px] left-[825px] rounded-[7px] top-[727px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[17px] left-[466px] rounded-[7px] top-[243px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[17px] left-[466px] rounded-[7px] top-[487px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[69px] left-[466px] rounded-[7px] top-[705px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[17px] left-[466px] rounded-[7px] top-[975px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[37px] left-[811px] rounded-[7px] top-[233px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[17px] left-[811px] rounded-[7px] top-[487px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[17px] left-[811px] rounded-[7px] top-[731px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[17px] left-[452px] rounded-[7px] top-[243px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[17px] left-[452px] rounded-[7px] top-[487px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[17px] left-[452px] rounded-[7px] top-[731px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[17px] left-[452px] rounded-[7px] top-[975px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[69px] left-[797px] rounded-[7px] top-[217px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[17px] left-[797px] rounded-[7px] top-[487px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[17px] left-[797px] rounded-[7px] top-[731px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[17px] left-[438px] rounded-[7px] top-[243px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[59px] left-[438px] rounded-[7px] top-[466px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[17px] left-[438px] rounded-[7px] top-[731px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[17px] left-[438px] rounded-[7px] top-[975px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[37px] left-[783px] rounded-[7px] top-[233px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[17px] left-[783px] rounded-[7px] top-[487px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[17px] left-[783px] rounded-[7px] top-[731px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[17px] left-[424px] rounded-[7px] top-[243px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[139px] left-[424px] rounded-[7px] top-[426px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[17px] left-[424px] rounded-[7px] top-[731px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[41px] left-[424px] rounded-[7px] top-[963px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[17px] left-[769px] rounded-[7px] top-[243px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[17px] left-[769px] rounded-[7px] top-[487px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[17px] left-[769px] rounded-[7px] top-[731px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[17px] left-[410px] rounded-[7px] top-[243px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[39px] left-[410px] rounded-[7px] top-[476px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[17px] left-[410px] rounded-[7px] top-[731px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[83px] left-[410px] rounded-[7px] top-[942px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[17px] left-[755px] rounded-[7px] top-[243px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[17px] left-[755px] rounded-[7px] top-[487px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[25px] left-[755px] rounded-[7px] top-[727px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[17px] left-[396px] rounded-[7px] top-[243px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[17px] left-[396px] rounded-[7px] top-[487px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[17px] left-[396px] rounded-[7px] top-[731px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[47px] left-[396px] rounded-[7px] top-[960px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[17px] left-[741px] rounded-[7px] top-[243px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[17px] left-[741px] rounded-[7px] top-[487px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[61px] left-[741px] rounded-[7px] top-[709px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[17px] left-[382px] rounded-[7px] top-[243px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[17px] left-[382px] rounded-[7px] top-[487px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[17px] left-[382px] rounded-[7px] top-[731px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[17px] left-[382px] rounded-[7px] top-[975px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[17px] left-[727px] rounded-[7px] top-[243px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[17px] left-[727px] rounded-[7px] top-[487px] w-[10px]" />
      <div className="absolute bg-[#7ff425] blur-[4.05px] h-[69px] left-[727px] rounded-[7px] top-[705px] w-[10px]" />
      <Group />
      <div className="absolute h-[53px] left-[741px] top-[46px] w-[282px]">
        <div className="absolute inset-[-28.3%_-5.32%]">
          <svg className="block size-full" fill="none" height="83" preserveAspectRatio="none" viewBox="0 0 312 83" width="312">
            <g filter="url(#filter0_f_0_367)" id="Rectangle 322">
              <path d={svgPaths.p2a05e000} fill="#7FF425" />
            </g>
            <defs>
              <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="83" id="filter0_f_0_367" width="312" x="0" y="0">
                <feFlood floodOpacity="0" result="BackgroundImageFix" />
                <feBlend in="SourceGraphic" in2="BackgroundImageFix" mode="normal" result="shape" />
                <feGaussianBlur result="effect1_foregroundBlur_0_367" stdDeviation="7.5" />
              </filter>
            </defs>
          </svg>
        </div>
      </div>
      <div className="absolute h-[53px] left-[741px] top-[46px] w-[282px]">
        <svg className="absolute block inset-0 size-full" fill="none" height="53" preserveAspectRatio="none" viewBox="0 0 282 53" width="282">
          <path d={svgPaths.pcabd900} fill="#7FF425" id="Rectangle 323" />
        </svg>
      </div>
      <p className="[word-break:break-word] absolute font-['Inter:Bold',sans-serif] font-bold leading-[normal] left-[760px] not-italic text-[25.806px] text-black top-[56px] whitespace-nowrap">Escolher Biblioteca</p>
    </div>
  );
}