# Installing Yoink (you received a .zxp file)

## Windows — 3 steps

1. Install **ZXPInstaller** (free, zxpinstaller.com) — or any ZXP installer.
2. Open it and drag the `Yoink-x.x.x.zxp` file into it.
3. Open Premiere Pro (restart it if it was running) →
   **Window > Extensions > YOINK!**.

Everything the panel needs is bundled — the three chips at the top of the
panel should be green.

## macOS — 4 steps

1. Install the ZXP the same way (ZXPInstaller → drag the .zxp in).
2. Install **Homebrew** (the Mac package manager). Open **Terminal**
   (Applications > Utilities, or search "Terminal" in Spotlight) and paste:

   ```
   /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
   ```

   This is the official installer from https://brew.sh. It asks for your Mac
   password and takes a few minutes. When it finishes it prints a
   **"Next steps"** list — run *every* command in it (usually three; the
   last one starts with `eval` and is what makes `brew` work in your current
   window). Already have Homebrew? Skip to step 3. If step 3 says
   `command not found: brew`, run
   `eval "$(/opt/homebrew/bin/brew shellenv)"` or open a new Terminal
   window, then retry.
3. In the same Terminal, install the three tools the panel uses:

   ```
   brew install yt-dlp ffmpeg handbrake
   ```

   (The `handbrake` formula is the command-line encoder the panel needs.)
4. Open Premiere Pro (restart it if it was running) →
   **Window > Extensions > YOINK!**.

*(If whoever built this ZXP filled `bin/mac` before building, steps 2–3
aren't needed — the chips will already be green.)*

## Checking it worked

Green chips at the top of the panel = ready; paste a video link and press the
button. A red chip: hover it — the tooltip says exactly what's missing and
where the panel looked.

Only fetch videos you own or are licensed to download. The tool does not
bypass DRM.
