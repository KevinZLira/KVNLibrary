# Third-party notices

Clip Fetcher's own code (the panel, host script, and build scripts) is MIT
licensed — see `LICENSE`. The tools it drives are separate projects with
their own licenses. When `bin/` is populated and a ZXP is distributed, these
notices and the texts in `licenses/` must ship with it.

## yt-dlp — `bin/yt-dlp.exe`

- Project: https://github.com/yt-dlp/yt-dlp
- License: The Unlicense (public domain). The Windows executable embeds
  Python and other components under their own permissive licenses; see the
  project's README for the full list.

## FFmpeg — `bin/ffmpeg.exe`, `bin/ffprobe.exe`

- Project: https://ffmpeg.org — binaries from https://github.com/yt-dlp/FFmpeg-Builds
- License: the `win64-gpl` builds fetched by `scripts/get-binaries.ps1` are
  **GPLv3**. Distributing them requires providing the license text and access
  to the corresponding source, both available at the FFmpeg-Builds repository
  above.

## HandBrakeCLI — `bin/HandBrakeCLI.exe`

- Project: https://handbrake.fr / https://github.com/HandBrake/HandBrake
- License: **GNU GPL v2** — full text in `licenses/HandBrake-COPYING.txt`
  (this is HandBrake's own COPYING file). Corresponding source:
  https://github.com/HandBrake/HandBrake
- Note: only the unmodified official CLI binary is redistributed; Clip
  Fetcher invokes it as a separate process and links nothing from it.

## Adobe CEP

- `js/CSInterface.js` in this kit is an original minimal shim around the
  documented `window.__adobe_cep__` bridge. If you replace it with Adobe's
  full `CSInterface.js` from the CEP-Resources repository, that file carries
  Adobe's own license header — keep it intact.

## Trademarks

YouTube, Adobe, and Premiere Pro are trademarks of their respective owners.
This project is not affiliated with or endorsed by Google/YouTube, Adobe, the
yt-dlp project, or the HandBrake project.
