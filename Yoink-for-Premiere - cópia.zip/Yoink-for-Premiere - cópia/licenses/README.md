License texts that must accompany a distributed ZXP.

- HandBrake-COPYING.txt — GPLv2, HandBrake's own COPYING file (applies to the
  bundled HandBrakeCLI).
- The GPL ffmpeg build's license and source pointers live at
  https://github.com/yt-dlp/FFmpeg-Builds — add its LICENSE.txt here when you
  bundle those binaries.

build-zxp.ps1 copies this whole folder into the signed package.
