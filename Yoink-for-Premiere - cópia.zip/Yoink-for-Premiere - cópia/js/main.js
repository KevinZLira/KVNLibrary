/* YOINK! — panel logic.
 *
 * Pipeline:  [01 Fetch]  yt-dlp downloads the video (optionally only the
 *                        in→out section, via --download-sections).
 *            [02 Encode] HandBrakeCLI re-encodes to H.264/AAC MP4
 *                        (optionally trimming here instead).
 *            [03 Timeline] ExtendScript (jsx/host.jsx) imports the file and
 *                        inserts it into the active sequence.
 *
 * Written conservatively (var, no template literals, no fs.promises) so it
 * runs on the oldest CEP runtime we target (CEP 9 / Premiere Pro 2019).
 * Security: every external tool is launched with child_process.spawn and an
 * ARGUMENT ARRAY — never a shell string — so nothing in a pasted URL or
 * filename can be interpreted as a command.
 */

(function () {
  "use strict";

  // ---------------------------------------------------------------- node ---
  var nodeRequire =
    (typeof window.cep_node !== "undefined" && window.cep_node.require)
      ? window.cep_node.require
      : (typeof window.require === "function" ? window.require : null);

  if (!nodeRequire) {
    document.body.innerHTML =
      '<div class="fatal">Node.js is not enabled for this panel.<br>' +
      'Make sure CSXS/manifest.xml keeps the <code>--enable-nodejs</code> ' +
      "CEF parameter, then restart Premiere Pro.</div>";
    return;
  }

  var cp   = nodeRequire("child_process");
  var fs   = nodeRequire("fs");
  var path = nodeRequire("path");
  var os   = nodeRequire("os");
  var proc = nodeRequire("process");

  var csi      = new CSInterface();
  var IS_WIN   = os.platform() === "win32";
  var EXT_ROOT = csi.getSystemPath(SystemPath.EXTENSION);
  var BIN_DIR  = path.join(EXT_ROOT, "bin");
  var DEFAULT_OUT = path.join(os.homedir(), "Documents", "Yoink");
  var BIN_NAME = "Yoink"; // project bin created in Premiere

  // ------------------------------------------------------------------ dom ---
  function $(id) { return document.getElementById(id); }

  var el = {
    url:        $("url"),
    timeIn:     $("timeIn"),
    timeOut:    $("timeOut"),
    trimMethod: $("trimMethod"),
    quality:    $("quality"),
    preset:     $("preset"),
    convert:    $("convert"),
    insertMode: $("insertMode"),
    audioOnly:  $("audioOnly"),
    outDir:     $("outDir"),
    browse:     $("browseBtn"),
    go:         $("goBtn"),
    cancel:     $("cancelBtn"),
    open:       $("openBtn"),
    log:        $("log"),
    barFill:    $("barFill"),
    barLabel:   $("barLabel")
  };

  var state = { running: false, cancelled: false, child: null };

  // ------------------------------------------------------------------ log ---
  function log(line, cls) {
    var d = document.createElement("div");
    if (cls) d.className = cls;
    d.textContent = line;
    el.log.appendChild(d);
    el.log.scrollTop = el.log.scrollHeight;
  }

  // ----------------------------------------------------------- rail / bar ---
  function stageEl(name) {
    return document.querySelector('.stage[data-stage="' + name + '"]');
  }
  function setStage(name, cls) {
    var s = stageEl(name);
    if (!s) return;
    s.className = "stage " + cls;
  }
  function setSub(name, text) {
    var s = document.querySelector('.sub[data-sub="' + name + '"]');
    if (s) s.textContent = text;
  }
  function resetRail(convertOn) {
    setStage("fetch", "idle");    setSub("fetch", "yt-dlp");
    setStage("encode", convertOn ? "idle" : "skip");
    setSub("encode", convertOn ? "HandBrake" : "skipped");
    setStage("timeline", "idle"); setSub("timeline", "Premiere");
  }
  function setBar(pct, label) {
    if (pct === null) {
      el.barFill.classList.add("indeterminate");
    } else {
      el.barFill.classList.remove("indeterminate");
      el.barFill.style.width = Math.max(0, Math.min(100, pct)) + "%";
    }
    if (label !== undefined) el.barLabel.textContent = label;
  }

  // ---------------------------------------------------------------- tools ---
  function exeName(base) { return IS_WIN ? base + ".exe" : base; }

  // ZXP installs can carry binaries for both platforms side by side.
  var PLAT_BIN = path.join(BIN_DIR, IS_WIN ? "win" : "mac");

  // GUI apps on macOS do NOT inherit the shell's PATH (no /opt/homebrew/bin,
  // /usr/local/bin), so a bare-name spawn misses Homebrew installs. Search
  // the usual homes explicitly, and loadShellPath() below extends this list
  // with the user's real login-shell PATH (covers custom Homebrew prefixes,
  // pipx, MacPorts, ...).
  var EXTRA_DIRS = IS_WIN ? [] :
    ["/opt/homebrew/bin", "/usr/local/bin", "/opt/local/bin",
     path.join(os.homedir(), ".local", "bin"),
     path.join(os.homedir(), "bin")];

  /** Ask the user's login shell for its PATH and fold new dirs into
   *  EXTRA_DIRS. Async; calls done() either way. */
  function loadShellPath(done) {
    if (IS_WIN) { done(); return; }
    var sh = (proc.env && proc.env.SHELL) || "/bin/zsh";
    try {
      cp.execFile(sh, ["-lc", 'echo -n "$PATH"'], { timeout: 8000 },
        function (err, stdout) {
          if (!err && stdout) {
            var parts = String(stdout).trim().split(":");
            for (var i = 0; i < parts.length; i++) {
              var d = parts[i];
              if (d && d.charAt(0) === "/" && EXTRA_DIRS.indexOf(d) === -1) {
                EXTRA_DIRS.push(d);
              }
            }
          }
          done();
        });
    } catch (e) { done(); }
  }

  function ensureExecutable(p) {
    // Zips built on Windows lose Unix exec bits; restore them (0755 = 493).
    if (!IS_WIN) { try { fs.chmodSync(p, 493); } catch (e) { /* read-only */ } }
  }

  /** Bundled copy (bin/<plat>/, then legacy flat bin/), then well-known
   *  install dirs, then bare name on PATH. */
  function resolveTool(base) {
    var name = exeName(base), i, p;
    var candidates = [path.join(PLAT_BIN, name), path.join(BIN_DIR, name)];
    for (i = 0; i < candidates.length; i++) {
      if (fs.existsSync(candidates[i])) {
        ensureExecutable(candidates[i]);
        return { cmd: candidates[i], bundled: true, label: "Bundled" };
      }
    }
    for (i = 0; i < EXTRA_DIRS.length; i++) {
      p = path.join(EXTRA_DIRS[i], name);
      if (fs.existsSync(p)) return { cmd: p, bundled: false, label: "Installed" };
    }
    return { cmd: name, bundled: false, label: "On PATH" };
  }

  /** Actionable "tool missing" advice for the current OS. */
  function toolHint(base) {
    if (IS_WIN) {
      return exeName(base) + " was not bundled and is not on PATH. " +
        "Rebuild the ZXP with scripts/build-zxp.ps1 (it bundles the tools), " +
        "or run scripts/get-binaries.ps1 for a dev install.";
    }
    return "This build has no macOS copy of " + base + ". Either install the " +
      "tools with Homebrew (brew install yt-dlp ffmpeg handbrake) and reopen " +
      "the panel, or rebuild the ZXP after running scripts/get-binaries.sh " +
      "on a Mac to fill bin/mac.";
  }

  /** Header readout: green "ready" when all three tools check out,
   *  red "not ready" if any fails; per-tool detail lives in
   *  Settings > Installs. */
  function updateSummary() {
    var all = $("chipAll");
    if (!all) return;
    var chips = [$("chipYtdlp"), $("chipFfmpeg"), $("chipHb")];
    var ok = 0, bad = 0, i;
    for (i = 0; i < chips.length; i++) {
      if (!chips[i]) continue;
      if (chips[i].classList.contains("ok")) ok++;
      else if (chips[i].classList.contains("bad")) bad++;
    }
    all.classList.remove("wait", "ok", "bad");
    if (bad > 0) {
      all.classList.add("bad");
      all.textContent = "not ready";
      all.title = "A required tool is missing. Windows: run scripts/" +
        "get-binaries.ps1 from the release kit. Mac: brew install yt-dlp " +
        "ffmpeg handbrake. Then close and reopen the panel.";
    } else if (ok === chips.length) {
      all.classList.add("ok");
      all.textContent = "ready";
      all.title = "yt-dlp, ffmpeg and HandBrakeCLI all found - details in " +
                  "Settings > Installs.";
    } else {
      all.classList.add("wait");
      all.textContent = "checking\u2026";
      all.title = "Checking yt-dlp, ffmpeg and HandBrakeCLI\u2026";
    }
  }

  function checkTool(base, versionArgs, chip) {
    var tool = resolveTool(base);
    try {
      cp.execFile(tool.cmd, versionArgs, { timeout: 15000, windowsHide: true },
        function (err, stdout, stderr) {
          chip.classList.remove("wait", "ok", "bad");
          if (err) {
            chip.classList.add("bad");
            chip.title = exeName(base) + " not found.\n" + toolHint(base);
          } else {
            chip.classList.add("ok");
            var firstLine = String(stdout || stderr || "").split(/\r?\n/)[0];
            chip.title = tool.label + ": " + tool.cmd + "\n" + firstLine;
          }
          updateSummary();
        });
    } catch (e) {
      chip.classList.remove("wait");
      chip.classList.add("bad");
      chip.title = String(e);
      updateSummary();
    }
  }

  // ----------------------------------------------------------- utilities ---
  function mkdirp(p) {
    if (fs.existsSync(p)) return;
    mkdirp(path.dirname(p));
    try { fs.mkdirSync(p); }
    catch (e) { if (!fs.existsSync(p)) throw e; }
  }

  /** "90", "1:30", "01:02:03.5" -> seconds. "" -> null. Bad input -> NaN. */
  function parseTimecode(v) {
    v = String(v || "").trim();
    if (!v) return null;
    if (!/^\d+(?::\d+){0,2}(?:\.\d+)?$/.test(v)) return NaN;
    var parts = v.split(":");
    var secs = 0;
    for (var i = 0; i < parts.length; i++) secs = secs * 60 + parseFloat(parts[i]);
    return isFinite(secs) ? secs : NaN;
  }

  function fmtSeconds(s) {
    // avoid float noise in CLI args
    return String(Math.round(s * 1000) / 1000);
  }

  /** yt-dlp format string: prefer H.264-in-MP4 so the file plays in Premiere
      even when the HandBrake pass is switched off. */
  function buildFormat(q) {
    // height<=?N (note the ?) keeps formats that don't REPORT a height —
    // Instagram often omits it, and a plain height<=N filter silently
    // excludes those, leaving nothing to download. The bare "/b" tail is
    // the unconditional last resort.
    var h = (q === "best") ? "" : "[height<=?" + q + "]";
    return "bv*" + h + "[ext=mp4][vcodec^=avc1]+ba[ext=m4a]" +
      "/b" + h + "[ext=mp4]" +
      "/bv*" + h + "+ba" +
      "/b" + h +
      "/b";
  }

  /** Canonicalise links that site share-sheets hand out. Instagram emits
   *  /reels/<id> (plural) plus tracking params; older yt-dlp extractors
   *  only match /reel/<id>/, so rewrite to that canonical form. */
  function normalizeVideoUrl(u) {
    var m = u.match(/^https?:\/\/(?:www\.)?instagram\.com\/reels?\/([A-Za-z0-9_-]+)/i);
    if (m) return "https://www.instagram.com/reel/" + m[1] + "/";
    // TikTok share links carry tracking params (?is_from_webapp=1&...).
    // Canonicalise to the bare video URL.
    m = u.match(/^https?:\/\/(?:www\.)?tiktok\.com\/(@[A-Za-z0-9_.\-]+)\/video\/(\d+)/i);
    if (m) return "https://www.tiktok.com/" + m[1] + "/video/" + m[2];
    return u;
  }

  /** Fallback when yt-dlp's output couldn't be parsed: newest media file the
      job could plausibly have written. */
  function newestMediaFile(dir, sinceMs) {
    var best = null;
    try {
      var names = fs.readdirSync(dir);
      for (var i = 0; i < names.length; i++) {
        if (!/\.(mp4|mkv|webm|mov|m4v)$/i.test(names[i])) continue;
        var p = path.join(dir, names[i]);
        var st;
        try { st = fs.statSync(p); } catch (e) { continue; }
        if (!st.isFile() || st.mtime.getTime() < sinceMs - 5000) continue;
        if (!best || st.mtime.getTime() > best.m) best = { p: p, m: st.mtime.getTime() };
      }
    } catch (e) { /* dir unreadable */ }
    return best ? best.p : null;
  }

  // ------------------------------------------------------------- spawning ---
  /**
   * Spawn a tool with an argument array, stream stdout+stderr to onLine
   * (handles \n and the \r-only progress updates HandBrake emits), and call
   * done(err, exitCode) exactly once.
   */
  function runTool(cmd, args, onLine, done) {
    log("$ " + cmd + " " + args.join(" "), "cmd");
    var finished = false;
    function finish(err, code) {
      if (finished) return;
      finished = true;
      state.child = null;
      done(err, code);
    }

    var child;
    try {
      child = cp.spawn(cmd, args, { windowsHide: true });
    } catch (e) { finish(e, null); return; }
    state.child = child;

    var buf = { out: "", err: "" };
    function feed(key, chunk) {
      buf[key] += chunk.toString("utf8");
      var pieces = buf[key].split(/\r\n|\n|\r/);
      buf[key] = pieces.pop();
      for (var i = 0; i < pieces.length; i++) {
        if (pieces[i]) onLine(pieces[i], key);
      }
    }

    child.stdout.on("data", function (c) { feed("out", c); });
    child.stderr.on("data", function (c) { feed("err", c); });
    child.on("error", function (e) { finish(e, null); });
    child.on("close", function (code) {
      if (buf.out) onLine(buf.out, "out");
      if (buf.err) onLine(buf.err, "err");
      finish(null, code);
    });
  }

  function cancelRun() {
    state.cancelled = true;
    var c = state.child;
    if (!c) return;
    try {
      if (IS_WIN) {
        // /T also kills the ffmpeg child yt-dlp spawns for merges.
        cp.spawn("taskkill", ["/PID", String(c.pid), "/T", "/F"], { windowsHide: true });
      } else {
        c.kill("SIGTERM");
      }
    } catch (e) { /* already gone */ }
  }

  // ------------------------------------------------------ stage 01: fetch ---
  function download(opts, done) {
    setStage("fetch", "active");
    setSub("fetch", "starting…");
    setBar(null, "Contacting site…");

    var ytdlp = resolveTool("yt-dlp");
    // In/out points are part of the identity of a request: bake them into
    // the filename so no earlier file (full video, other trim, cancelled
    // leftover, or an already-extracted MP3) can ever be mistaken for it.
    var sectSuffix = "";
    if (opts.trim) {
      sectSuffix = " [" + (opts.timeIn !== null ? opts.timeIn : 0) + "-" +
                   (opts.timeOut !== null ? opts.timeOut : "end") + "]";
    }
    var isTikTok = /tiktok\.com/i.test(opts.url);
    var args = [
      "--ignore-config",
      "--no-playlist",
      // Changed in/out points must always take effect: never reuse a
      // leftover file from a previous/cancelled run with the same name
      // (implies --no-continue, so stale .part files restart too).
      "--force-overwrites",
      "--newline",
      "--windows-filenames",
      "--restrict-filenames",
      "-o", path.join(opts.outDir,
                      "%(title).70s [%(id)s]" + sectSuffix + ".%(ext)s")
    ];
    if (opts.audioOnly) {
      // Best audio, extracted to MP3 (needs ffmpeg, which is bundled).
      args.push("-f", "ba/b", "-x", "--audio-format", "mp3",
                "--audio-quality", "0");
    } else {
      args.push("-f", buildFormat(opts.quality),
                "--merge-output-format", "mp4");
    }

    var ffmpeg = resolveTool("ffmpeg");
    var ffmpegKnown = ffmpeg.cmd.indexOf(path.sep) !== -1; // resolved to a real file
    if (ffmpegKnown) args.push("--ffmpeg-location", path.dirname(ffmpeg.cmd));

    if (opts.trim && opts.trimMethod === "download") {
      var s = (opts.timeIn  === null) ? "0"   : fmtSeconds(opts.timeIn);
      var e = (opts.timeOut === null) ? "inf" : fmtSeconds(opts.timeOut);
      args.push("--download-sections", "*" + s + "-" + e,
                "--force-keyframes-at-cuts");
      log("Trimming at download: " + s + "s to " + e +
          (e === "inf" ? "" : "s") + " (needs ffmpeg).", "note");
    }

    if (isTikTok) {
      // TikTok's bot-wall serves a page with no player data on rapid
      // repeats; more page-fetch attempts with breathing room between
      // them ride it out instead of failing on the first try.
      args.push("--extractor-retries", "6", "--retry-sleep", "extractor:3");
    }

    args.push(opts.url);

    // TikTok bot-wall retry ladder: the whole yt-dlp attempt re-runs (up
    // to 10 tries, 5 s apart) while the fetch stage stays active and the
    // bar keeps sweeping. Only the 10th failure surfaces as an error.
    var tiktokTries = 0;

    function attemptFetch() {

    var startedAt = Date.now();
    var finalFromMerger = null;
    var lastDestination = null;
    var lastErrorLine = "";

    runTool(ytdlp.cmd, args, function (line) {
      var m;

      m = line.match(/\[ExtractAudio\] Destination: (.+)/);
      if (m) { finalFromMerger = m[1].trim(); }

      m = line.match(/\[Merger\] Merging formats into "(.+)"/);
      if (m) { finalFromMerger = m[1]; }

      m = line.match(/\[download\] Destination: (.+)/);
      if (m) { lastDestination = m[1].trim(); }

      m = line.match(/\[download\] (.+) has already been downloaded/);
      if (m) { lastDestination = m[1].trim(); log(line); return; }

      m = line.match(/\[download\]\s+(\d+(?:\.\d+)?)%/);
      if (m) {
        var pct = parseFloat(m[1]);
        setBar(pct, "Fetching " + pct.toFixed(1) + "%");
        setSub("fetch", pct.toFixed(0) + "%");
        return; // keep the log readable — skip per-tick progress lines
      }

      if (/^ERROR/i.test(line)) { lastErrorLine = line; log(line, "err"); }
      else log(line);
    }, function (err, code) {
      if (state.cancelled) { done(new Error("cancelled")); return; }
      if (err) {
        done(new Error("Could not start yt-dlp (" + err.message + "). " +
          toolHint("yt-dlp")));
        return;
      }
      if (code !== 0) {
        var failMsg = "yt-dlp exited with code " + code +
          ", see the log above.";
        if (isTikTok && /universal data for rehydration/i.test(lastErrorLine)) {
          tiktokTries++;
          if (tiktokTries < 10) {
            // Status stays generic; from the 4th fail on, gently level
            // with the user. The log gets one quiet note at the start.
            if (tiktokTries >= 4) {
              setBar(null, "Sometimes TikTok takes a while…");
              if (tiktokTries === 4) {
                log("Sometimes TikTok takes a while - still trying.", "note");
              }
            } else {
              setBar(null, "Fetching…");
              if (tiktokTries === 1) {
                log("TikTok is being slow - retrying quietly.", "note");
              }
            }
            // Wait in 1 s ticks so Cancel still responds during the pause.
            var waited = 0;
            (function tick() {
              if (state.cancelled) { done(new Error("cancelled")); return; }
              if (waited >= 5000) { attemptFetch(); return; }
              waited += 1000;
              setTimeout(tick, 1000);
            })();
            return;
          }
          var walled = new Error("TikTok blocks rapid repeated downloads, " +
            "try again in 30 seconds.");
          walled.plain = true; // shown as-is, no "Fetch failed:" prefix
          done(walled);
          return;
        }
        if (isTikTok &&
            /unable to obtain file audio codec/i.test(lastErrorLine)) {
          // ffprobe can't read the audio stream TikTok served (typically
          // muted/protected music). Nothing a retry can fix.
          var noAudio = new Error("TikTok blocked the audio from this clip.");
          noAudio.plain = true;
          done(noAudio);
          return;
        }
        if (/instagram\.com/i.test(opts.url)) {
          failMsg += " Instagram support lives inside yt-dlp and Instagram " +
            "changes its site often, so this usually means the bundled " +
            "yt-dlp is out of date. Refresh it (Windows: run " +
            "scripts/get-binaries.ps1 -Update and rebuild; mac Homebrew: " +
            "brew upgrade yt-dlp) and try again. Some reels also require " +
            "being logged in, which this panel does not do.";
        }
        done(new Error(failMsg));
        return;
      }
      var file = finalFromMerger || lastDestination ||
                 newestMediaFile(opts.outDir, startedAt);
      if (!file || !fs.existsSync(file)) {
        done(new Error("Download finished but the output file could not be located."));
        return;
      }
      setStage("fetch", "done");
      setSub("fetch", path.basename(file));
      log("Downloaded: " + file, "ok");
      done(null, file);
    });

    } // attemptFetch

    attemptFetch();
  }

  // ----------------------------------------------------- stage 02: encode ---
  function encode(inputFile, opts, done) {
    setStage("encode", "active");
    setSub("encode", "starting…");
    setBar(0, "Encoding 0%");

    var hb = resolveTool("HandBrakeCLI");
    var base = inputFile.replace(/\.[^.\\\/]+$/, "");
    // Pick an output path HandBrake can actually open: delete a stale
    // leftover from an earlier run, and if it can't be deleted (Premiere
    // has it open), step to -converted-2, -3, ... instead of failing with
    // avio_open2 errno -13.
    var outFile = base + "-converted.mp4";
    var suffix = 2;
    while (outFile.toLowerCase() === inputFile.toLowerCase() ||
           fs.existsSync(outFile)) {
      if (outFile.toLowerCase() !== inputFile.toLowerCase()) {
        try { fs.unlinkSync(outFile); break; }
        catch (eBusy) {
          log("A previous converted file is in use (probably open in " +
              "Premiere); writing a new file instead.", "note");
        }
      }
      outFile = base + "-converted-" + (suffix++) + ".mp4";
    }

    var args = [
      "-i", inputFile,
      "-o", outFile,
      "--preset", opts.preset,
      "--format", "av_mp4",
      "--optimize"
    ];

    if (opts.trim && opts.trimMethod === "handbrake") {
      var startS = (opts.timeIn === null) ? 0 : opts.timeIn;
      args.push("--start-at", "seconds:" + fmtSeconds(startS));
      if (opts.timeOut !== null) {
        // HandBrake's --stop-at is a DURATION measured from --start-at.
        var duration = Math.max(0.1, opts.timeOut - startS);
        args.push("--stop-at", "seconds:" + fmtSeconds(duration));
      }
      log("Trimming at encode: start " + fmtSeconds(startS) + "s" +
          (opts.timeOut !== null
            ? ", duration " + fmtSeconds(opts.timeOut - startS) + "s"
            : ""), "note");
    }

    runTool(hb.cmd, args, function (line) {
      var m = line.match(/(\d+(?:\.\d+)?)\s*%/);
      if (m && /Encoding/i.test(line)) {
        var pct = parseFloat(m[1]);
        setBar(pct, "Encoding " + pct.toFixed(1) + "%");
        setSub("encode", pct.toFixed(0) + "%");
        return;
      }
      if (/error/i.test(line)) log(line, "err");
    }, function (err, code) {
      if (state.cancelled) { done(new Error("cancelled")); return; }
      if (err) {
        done(new Error("Could not start HandBrakeCLI (" + err.message + "). " +
          toolHint("HandBrakeCLI") +
          " Note: the HandBrake GUI app cannot be used here — the panel " +
          "needs the separate HandBrakeCLI build."));
        return;
      }
      if (code !== 0 || !fs.existsSync(outFile)) {
        // Leave nothing poisonous behind: a partial output would block the
        // next attempt, and a section-trimmed download embodies the bad
        // timestamps, so both go.
        try {
          if (fs.existsSync(outFile)) fs.unlinkSync(outFile);
        } catch (e0) {}
        if (opts.trim) {
          if (opts.trimMethod === "download") {
            try { fs.unlinkSync(inputFile); } catch (e1) {}
          }
          var friendly = new Error("Please make sure the in/out timestamps " +
            "are correct and inside the video's length, then try again.");
          friendly.plain = true; // shown as-is, no "Encode failed:" prefix
          done(friendly);
          return;
        }
        done(new Error("HandBrakeCLI exited with code " + code +
          ", see the log above."));
        return;
      }
      setStage("encode", "done");
      setSub("encode", path.basename(outFile));
      log("Encoded: " + outFile, "ok");

      // Only the final video is kept: the raw download is removed once the
      // encode succeeds. (With Encode to MP4 off, the download IS the final
      // video and this stage never runs.)
      try {
        fs.unlinkSync(inputFile);
        log("Removed raw download.", "note");
      } catch (e) {
        log("Could not remove the raw download: " + e.message, "note");
      }
      done(null, outFile);
    });
  }

  // --------------------------------------------------- stage 03: timeline ---
  function jsxArg(s) {
    return '"' + String(s).replace(/\\/g, "\\\\").replace(/"/g, '\\"') + '"';
  }

  function ensureJsxLoaded(cb) {
    csi.evalScript("typeof CF_importAndInsert", function (res) {
      if (res === "function") { cb(); return; }
      var jsxPath = path.join(EXT_ROOT, "jsx", "host.jsx").replace(/\\/g, "/");
      csi.evalScript('$.evalFile(' + jsxArg(jsxPath) + ')', function () { cb(); });
    });
  }

  function sendToPremiere(filePath, mode, isAudio, done) {
    setStage("timeline", "active");
    setSub("timeline", "importing…");
    setBar(null, "Handing off to Premiere…");

    ensureJsxLoaded(function () {
      var call = "CF_importAndInsert(" +
        jsxArg(filePath) + "," + jsxArg(mode) + "," + jsxArg(BIN_NAME) +
        "," + jsxArg(isAudio ? "1" : "0") + ")";
      csi.evalScript(call, function (res) {
        res = String(res || "");
        if (!res || res === CSInterface.EVAL_ERROR) {
          done(new Error("The ExtendScript call failed. Is a project open?"));
          return;
        }
        var sep = res.indexOf("|");
        var status = (sep === -1) ? res : res.substring(0, sep);
        var detail = (sep === -1) ? ""  : res.substring(sep + 1);
        if (status !== "OK") { done(new Error(detail || "Unknown host error.")); return; }
        done(null, detail);
      });
    });
  }

  // ------------------------------------------------------------- the run ---
  function setFormEnabled(enabled) {
    var ids = ["url","timeIn","timeOut","trimMethod","quality","preset",
               "convert","audioOnly","insertMode","outDir","browseBtn","goBtn",
               "clearTcBtn","clearUrlBtn"];
    for (var i = 0; i < ids.length; i++) {
      var n = $(ids[i]);
      if (n) n.disabled = !enabled;
    }
    el.cancel.hidden = enabled;
  }

  function finishRun(ok, message) {
    state.running = false;
    state.cancelled = false;
    setFormEnabled(true);
    updateLicenseUI(); // re-assert the license gate — setFormEnabled(true) above would otherwise re-enable goBtn even if unlicensed
    if (ok) {
      setBar(100, message);
      log(message, "ok");
    } else {
      setBar(0, message);
      log(message, "err");
    }
  }

  function go() {
    if (state.running) return;
    if (!licensed) {
      // Belt and suspenders: goBtn is already disabled via updateLicenseUI(),
      // but this covers the brief async window right after panel load,
      // before the first background validate call has resolved.
      setBar(0, "License required — open Settings (gear) to activate.");
      return;
    }

    var url = el.url.value.trim();
    if (!/^https?:\/\/\S+$/i.test(url)) {
      setBar(0, "Enter a full http(s) link first.");
      el.url.focus();
      return;
    }
    var canonical = normalizeVideoUrl(url);
    if (canonical !== url) {
      log("Link normalized: " + canonical, "note");
      url = canonical;
    }

    var tIn  = parseTimecode(el.timeIn.value);
    var tOut = parseTimecode(el.timeOut.value);
    if ((tIn !== null && isNaN(tIn)) || (tOut !== null && isNaN(tOut))) {
      setBar(0, "Timecodes look like 90, 1:30, or 1:02:03.");
      return;
    }
    if (tIn !== null && tOut !== null && tOut <= tIn) {
      setBar(0, "The out point must come after the in point.");
      return;
    }

    var opts = {
      url: url,
      timeIn: tIn,
      timeOut: tOut,
      trim: (tIn !== null || tOut !== null),
      trimMethod: el.trimMethod.value,
      quality: el.quality.value,
      preset: el.preset.value,
      convert: el.convert.checked,
      audioOnly: el.audioOnly.checked,
      insertMode: el.insertMode.value,
      outDir: el.outDir.value.trim() || DEFAULT_OUT
    };
    if (opts.audioOnly && opts.trim && opts.trimMethod === "handbrake") {
      // No encode stage in audio-only mode - trim during the download.
      opts.trimMethod = "download";
      log("Audio only: trimming during the download instead.", "note");
    }

    // Trimming in HandBrake only makes sense if the encode stage runs.
    if (opts.trim && opts.trimMethod === "handbrake" && !opts.convert) {
      opts.convert = true;
      el.convert.checked = true;
      log("Encode enabled automatically (trim is set to happen in HandBrake).", "note");
    }

    try { mkdirp(opts.outDir); }
    catch (e) {
      setBar(0, "Can't create the download folder: " + e.message);
      return;
    }

    saveSettings();
    state.running = true;
    state.cancelled = false;
    setFormEnabled(false);
    resetRail(opts.convert);
    el.log.innerHTML = "";
    log("Job started " + new Date().toLocaleTimeString());

    download(opts, function (err, rawFile) {
      if (err) {
        setStage("fetch", state.cancelled ? "idle" : "error");
        finishRun(false, state.cancelled ? "Cancelled."
          : (err.plain ? err.message : "Fetch failed: " + err.message));
        return;
      }

      function afterMedia(mediaErr, finalFile) {
        if (mediaErr) {
          setStage("encode", state.cancelled ? "idle" : "error");
          finishRun(false, state.cancelled ? "Cancelled."
            : (mediaErr.plain ? mediaErr.message
                              : "Encode failed: " + mediaErr.message));
          return;
        }
        sendToPremiere(finalFile, opts.insertMode, opts.audioOnly, function (impErr, detail) {
          if (impErr) {
            setStage("timeline", "error");
            finishRun(false, "Import failed: " + impErr.message);
            return;
          }
          setStage("timeline", "done");
          var msg =
            detail === "playhead"  ? "Done — clip inserted at the playhead." :
            detail === "append"    ? "Done — clip appended to the end of the sequence." :
            detail === "bin-noseq" ? "Done — imported to the bin (no sequence was open)." :
                                     "Done — clip imported to the \"" + BIN_NAME + "\" bin.";
          setSub("timeline", "done");
          finishRun(true, msg);
        });
      }

      if (opts.convert && !opts.audioOnly) {
        encode(rawFile, opts, afterMedia);
      } else if (opts.convert && opts.audioOnly) {
        // Audio is already MP3 - nothing to encode. Complete the stage
        // instantly so the rail flows 01 -> 02 -> 03 without a gap.
        setStage("encode", "done");
        log("Audio only - already MP3, no encode needed.", "note");
        afterMedia(null, rawFile);
      } else {
        afterMedia(null, rawFile);
      }
    });
  }

  // ------------------------------------------------------------ settings ---
  var SETTINGS = ["quality","preset","insertMode","trimMethod"];
  function saveSettings() {
    try {
      for (var i = 0; i < SETTINGS.length; i++) {
        localStorage.setItem("cf." + SETTINGS[i], $(SETTINGS[i]).value);
      }
      localStorage.setItem("cf.outDir", el.outDir.value);
      localStorage.setItem("cf.convert", el.convert.checked ? "1" : "0");
    } catch (e) { /* storage unavailable — non-fatal */ }
  }
  function loadSettings() {
    try {
      for (var i = 0; i < SETTINGS.length; i++) {
        var v = localStorage.getItem("cf." + SETTINGS[i]);
        if (v !== null) $(SETTINGS[i]).value = v;
      }
      var savedDir = localStorage.getItem("cf.outDir");
      // migrate the pre-rename default so Browse/Open land on Documents/Yoink
      if (savedDir === path.join(os.homedir(), "Documents", "ClipFetcher")) {
        savedDir = null;
        localStorage.removeItem("cf.outDir");
      }
      el.outDir.value = savedDir || DEFAULT_OUT;
      var c = localStorage.getItem("cf.convert");
      if (c !== null) el.convert.checked = (c === "1");
      // Retired settings from older builds.
      localStorage.removeItem("cf.deleteOriginal");
      localStorage.removeItem("cf.keepFiles");
    } catch (e) {
      el.outDir.value = DEFAULT_OUT;
    }
  }

  // -------------------------------------------------------------- license ---
  // Talks to the same WooCommerce + License Manager REST API FilmForge uses
  // (same store/business, separate product & key pool for YOINK!). Two
  // response-parsing quirks below were real bugs found building that system
  // — ported here rather than rediscovered:
  //   - LMFWC can return HTTP 200 + "success":true for an actual rejection
  //     (e.g. activation limit reached), with the real error nested in
  //     data.errors.<code>[0]. licenseBodyOk() checks for that "errors"
  //     object and treats it as failure regardless of the top-level flag.
  //   - Deactivating a specific machine needs ?token=<this machine's own
  //     activation token>. A bare deactivate-by-key call clears every seat
  //     on the license, not just this one.

  var LICENSE_BASE_URL   = "https://plugdealer.shop";
  var LICENSE_GRACE_DAYS = 7;

  /* Real consumer key/secret for plugdealer.shop, XOR-obfuscated — not
     shown in plaintext here on purpose. Verified working against the live
     server (validate + activate + deactivate all round-tripped correctly)
     before being embedded. Kept as a byte array rather than a plain string
     so a casual `grep -r ck_` on the unzipped .zxp doesn't turn it up
     directly — NOT real protection (this is plain JavaScript; anyone
     reading the code sees exactly what it does in seconds), just not the
     literal laziest extraction attempt either. To regenerate if this key
     is ever rotated:
       python3 -c "
       key = 0x5A
       s = 'ck_PASTE_YOUR_REAL_CONSUMER_KEY_HERE'
       print('[' + ','.join(str(ord(c) ^ key) for c in s) + ']')
       " */
  var LICENSE_OBF_KEY = 0x5A;
  var LICENSE_OBF_CONSUMER_KEY    = [57,49,5,99,111,105,57,59,108,62,59,105,108,63,111,110,60,104,110,62,60,62,107,59,57,105,109,108,111,105,57,63,63,108,57,110,110,109,104,59,105,60,110];
  var LICENSE_OBF_CONSUMER_SECRET = [57,41,5,106,108,105,110,57,105,111,107,56,99,59,106,109,105,108,107,109,63,105,108,109,63,108,111,105,109,106,59,105,98,99,110,107,62,106,99,59,60,108,99];

  function licenseDeobfuscate(arr) {
    var out = "";
    for (var i = 0; i < arr.length; i++) out += String.fromCharCode(arr[i] ^ LICENSE_OBF_KEY);
    return out;
  }
  function licenseConsumerKey()    { return licenseDeobfuscate(LICENSE_OBF_CONSUMER_KEY); }
  function licenseConsumerSecret() { return licenseDeobfuscate(LICENSE_OBF_CONSUMER_SECRET); }

  function licenseBase64Encode(s) {
    var BufferCtor = nodeRequire("buffer").Buffer;
    return BufferCtor.from(s, "utf8").toString("base64");
  }

  function licenseMakeMachineId() {
    var a = Math.floor(Math.random() * 0xFFFFFFFF).toString(16);
    var b = Math.floor(Math.random() * 0xFFFFFFFF).toString(16);
    return a + "-" + b + "-" + Date.now().toString(16);
  }

  var licenseCache = {
    key: "", machineId: "", token: "", lastValidAt: 0,
    timesActivated: 0, timesActivatedMax: 0
  };
  var licensed = false;

  function licenseLoadCache() {
    try {
      var raw = localStorage.getItem("cf.license");
      if (raw) {
        var parsed = JSON.parse(raw);
        for (var k in licenseCache) {
          if (parsed.hasOwnProperty(k)) licenseCache[k] = parsed[k];
        }
      }
    } catch (e) { /* corrupt or unavailable — start fresh, matches loadSettings() */ }
    if (!licenseCache.machineId) {
      licenseCache.machineId = licenseMakeMachineId();
      licenseSaveCache();
    }
  }
  function licenseSaveCache() {
    try { localStorage.setItem("cf.license", JSON.stringify(licenseCache)); }
    catch (e) { /* storage unavailable — non-fatal, matches saveSettings() */ }
  }

  /** Raw HTTPS GET with Basic Auth. cb(reached, statusCode, body). Uses
   *  Node's https module rather than the browser fetch() this panel could
   *  also reach for — a fetch() with a custom Authorization header from a
   *  file://-origin panel risks a CORS preflight the WordPress side isn't
   *  set up to answer; https.request has no origin-based restriction at
   *  all. */
  function licenseHttpsGet(urlStr, cb) {
    var https, urlMod, BufferCtor;
    try {
      https = nodeRequire("https");
      urlMod = nodeRequire("url");
      BufferCtor = nodeRequire("buffer").Buffer;
    } catch (e) { cb(false, 0, ""); return; }

    var parsed;
    try { parsed = urlMod.parse(urlStr); } catch (e) { cb(false, 0, ""); return; }

    var authHeader = "Basic " + licenseBase64Encode(licenseConsumerKey() + ":" + licenseConsumerSecret());
    var options = {
      hostname: parsed.hostname,
      port: parsed.port || 443,
      path: parsed.path,
      method: "GET",
      headers: { "Authorization": authHeader },
      timeout: 15000
    };

    var done = false;
    function finish(reached, statusCode, body) {
      if (done) return;
      done = true;
      cb(reached, statusCode, body);
    }

    var req;
    try {
      req = https.request(options, function (res) {
        var chunks = [];
        res.on("data", function (c) { chunks.push(c); });
        res.on("end", function () {
          finish(true, res.statusCode, BufferCtor.concat(chunks).toString("utf8"));
        });
      });
    } catch (e) { finish(false, 0, ""); return; }

    req.on("timeout", function () { req.destroy(); finish(false, 0, ""); });
    req.on("error", function () { finish(false, 0, ""); });
    req.end();
  }

  // Crude, dependency-free substring checks against the plugin's response
  // shape — matches the approach FilmForge's C++ side uses, ported directly.
  function licenseBodyOk(body) {
    if (body.indexOf('"success":true') === -1) return false;
    if (body.indexOf('"errors":{') !== -1) return false; // the LMFWC quirk
    return true;
  }

  function licenseExtractMessage(body) {
    var needle = '"message":"';
    var start = body.indexOf(needle);
    if (start !== -1) {
      start += needle.length;
      var end = body.indexOf('"', start);
      if (end !== -1) return body.substring(start, end);
    }
    // The "success:true but actually rejected" shape has no top-level
    // "message" — pull the first string out of data.errors.<code>[...]
    // instead, e.g. "License Key: ... reached maximum activation count."
    var errStart = body.indexOf('"errors":{');
    if (errStart === -1) return "";
    var arrStart = body.indexOf("[", errStart);
    if (arrStart === -1) return "";
    var strStart = body.indexOf('"', arrStart);
    if (strStart === -1) return "";
    strStart += 1;
    var strEnd = body.indexOf('"', strStart);
    if (strEnd === -1) return "";
    return body.substring(strStart, strEnd);
  }

  function licenseExtractToken(body) {
    var needle = '"token":"';
    var start = body.indexOf(needle);
    if (start === -1) return "";
    start += needle.length;
    var end = body.indexOf('"', start);
    if (end === -1) return "";
    return body.substring(start, end);
  }

  function licenseExtractIntField(body, fieldName) {
    var needle = '"' + fieldName + '":';
    var start = body.indexOf(needle);
    if (start === -1) return -1;
    start += needle.length;
    var end = start;
    while (end < body.length && body.charAt(end) !== "," && body.charAt(end) !== "}") end++;
    var n = parseInt(body.substring(start, end), 10);
    return isNaN(n) ? -1 : n;
  }

  /** Does the actual server round-trip for activate/validate/deactivate. */
  function licenseCallEndpoint(pathName, key, extraQuery, cb) {
    var url = LICENSE_BASE_URL + "/wp-json/lmfwc/v2/licenses/" + pathName + "/" +
      encodeURIComponent(key) + (extraQuery || "");
    licenseHttpsGet(url, function (reached, statusCode, body) {
      if (!reached) { cb({ reachable: false }); return; }
      var ok = (statusCode >= 200 && statusCode < 300) && licenseBodyOk(body);
      cb({
        reachable: true,
        success: ok,
        message: ok ? "Licensed." : (licenseExtractMessage(body) || "The server rejected this license key."),
        token: ok ? licenseExtractToken(body) : "",
        timesActivated: ok ? licenseExtractIntField(body, "timesActivated") : -1,
        timesActivatedMax: ok ? licenseExtractIntField(body, "timesActivatedMax") : -1
      });
    });
  }

  function licenseActivate(key, cb) {
    var query = "?label=" + encodeURIComponent(licenseCache.machineId);
    licenseCallEndpoint("activate", key, query, function (r) {
      if (!r.reachable) {
        cb({ ok: false, message: "Couldn't reach the license server. Check your internet connection and try again." });
        return;
      }
      if (!r.success) { cb({ ok: false, message: r.message }); return; }

      licenseCache.key = key;
      licenseCache.token = r.token;
      licenseCache.lastValidAt = Date.now();
      if (r.timesActivated >= 0) licenseCache.timesActivated = r.timesActivated;
      if (r.timesActivatedMax >= 0) licenseCache.timesActivatedMax = r.timesActivatedMax;
      licenseSaveCache();
      licensed = true;

      var seatNote = licenseCache.timesActivatedMax > 0
        ? (" Using " + licenseCache.timesActivated + " of " + licenseCache.timesActivatedMax + " seats.")
        : "";
      cb({ ok: true, message: "Licensed. Thanks for using YOINK!" + seatNote });
    });
  }

  function licenseDeactivate(cb) {
    if (!licenseCache.key) {
      cb({ ok: false, message: "No license is currently active on this machine." });
      return;
    }
    if (!licenseCache.token) {
      cb({ ok: false, message: "Can't deactivate just this machine (no saved activation record). " +
        "Re-activate your key here once, then Deactivate will work normally." });
      return;
    }
    var query = "?token=" + encodeURIComponent(licenseCache.token);
    licenseCallEndpoint("deactivate", licenseCache.key, query, function (r) {
      if (!r.reachable) {
        cb({ ok: false, message: "Couldn't reach the license server. Check your internet connection and try again." });
        return;
      }
      if (!r.success) { cb({ ok: false, message: r.message }); return; }

      licenseCache = {
        key: "", machineId: licenseCache.machineId, token: "", lastValidAt: 0,
        timesActivated: 0, timesActivatedMax: 0
      };
      licenseSaveCache();
      licensed = false;
      cb({ ok: true, message: "This machine has been deactivated. You can activate a different key here now, or use this seat on another computer." });
    });
  }

  function licenseRevalidateBackground() {
    if (!licenseCache.key) { licensed = false; updateLicenseUI(); return; }
    licenseCallEndpoint("validate", licenseCache.key, "", function (r) {
      if (r.reachable) {
        if (r.success) {
          licenseCache.lastValidAt = Date.now();
          if (r.timesActivated >= 0) licenseCache.timesActivated = r.timesActivated;
          if (r.timesActivatedMax >= 0) licenseCache.timesActivatedMax = r.timesActivatedMax;
          licenseSaveCache();
          licensed = true;
        } else {
          // Explicit rejection (revoked/refunded/expired) — don't
          // grace-period this, only offline gaps get the grace window.
          licensed = false;
        }
      } else {
        var daysSince = (Date.now() - licenseCache.lastValidAt) / 86400000;
        licensed = licenseCache.lastValidAt > 0 && daysSince <= LICENSE_GRACE_DAYS;
      }
      updateLicenseUI();
    });
  }

  /** Toggles the Settings > License card between its two states and gates
   *  goBtn — the single source of truth the hard-block decision reads from.
   *  Called on init, after every activate/deactivate attempt, and after
   *  every background revalidation. */
  function updateLicenseUI() {
    var chip = $("chipLicense");
    var inputBlock = $("licenseInputBlock");
    var activeBlock = $("licenseActiveBlock");
    var statusText = $("licenseStatusText");

    if (chip) {
      chip.classList.remove("wait", "ok", "bad");
      chip.classList.add(licensed ? "ok" : "bad");
      chip.textContent = licensed ? "licensed" : "unlicensed";
    }
    if (inputBlock) inputBlock.hidden = licensed;
    if (activeBlock) activeBlock.hidden = !licensed;
    if (licensed && statusText) {
      statusText.textContent = licenseCache.timesActivatedMax > 0
        ? ("Licensed — using " + licenseCache.timesActivated + " of " + licenseCache.timesActivatedMax + " seats.")
        : "Licensed.";
    }

    el.go.disabled = !licensed || state.running;
    if (!licensed && !state.running) {
      setBar(0, "License required — open Settings (gear) to activate.");
    }
  }

  function licenseInit() {
    licenseLoadCache();
    var daysSince = (Date.now() - licenseCache.lastValidAt) / 86400000;
    licensed = licenseCache.lastValidAt > 0 && daysSince <= LICENSE_GRACE_DAYS;
    updateLicenseUI();
    licenseRevalidateBackground();
  }

  // --------------------------------------------------------------- wiring ---
  el.go.addEventListener("click", go);
  el.url.addEventListener("keydown", function (e) {
    if (e.key === "Enter") go();
  });

  el.cancel.addEventListener("click", function () {
    log("Cancelling…", "note");
    cancelRun();
  });

  el.open.addEventListener("click", function () {
    // Always the folder from Settings > "Save downloads to" (default
    // Documents/Yoink). path.resolve normalises typed paths - explorer
    // silently falls back to Documents if it's handed forward slashes.
    var dir = path.resolve((el.outDir.value || "").trim() || DEFAULT_OUT);
    try { mkdirp(dir); } catch (e) { /* show whatever exists */ }
    try {
      cp.spawn(IS_WIN ? "explorer" : "open", [dir], { detached: true });
    } catch (e) { log("Could not open the folder: " + e.message, "err"); }
  });

  el.browse.addEventListener("click", function () {
    if (!(window.cep && window.cep.fs && window.cep.fs.showOpenDialogEx)) return;
    var res = window.cep.fs.showOpenDialogEx(
      false, true, "Choose the download folder",
      el.outDir.value || DEFAULT_OUT, []);
    if (res && res.data && res.data[0]) {
      el.outDir.value = res.data[0];
      saveSettings();
    }
  });

  el.convert.addEventListener("change", function () {
    el.preset.disabled = !el.convert.checked;
    resetRail(el.convert.checked);
  });

  (function () {
    var activateBtn = $("licenseActivateBtn");
    var deactivateBtn = $("licenseDeactivateBtn");
    var keyInput = $("licenseKeyInput");
    var msg = $("licenseMsg");

    if (activateBtn) {
      activateBtn.addEventListener("click", function () {
        var key = keyInput ? keyInput.value.trim() : "";
        if (!key) { if (msg) msg.textContent = "Enter a license key first."; return; }
        activateBtn.disabled = true;
        if (msg) msg.textContent = "Activating…";
        licenseActivate(key, function (result) {
          activateBtn.disabled = false;
          if (msg) msg.textContent = result.message;
          updateLicenseUI();
        });
      });
    }
    if (keyInput) {
      keyInput.addEventListener("keydown", function (e) {
        if (e.key === "Enter" && activateBtn) activateBtn.click();
      });
    }
    if (deactivateBtn) {
      deactivateBtn.addEventListener("click", function () {
        deactivateBtn.disabled = true;
        licenseDeactivate(function (result) {
          deactivateBtn.disabled = false;
          if (msg) msg.textContent = result.message;
          updateLicenseUI();
        });
      });
    }
  })();

  // ----------------------------------------------------------------- init ---
  licenseInit();
  loadSettings();
  el.preset.disabled = !el.convert.checked;
  resetRail(el.convert.checked);

  function checkAllTools() {
    checkTool("yt-dlp",       ["--version"], $("chipYtdlp"));
    checkTool("ffmpeg",       ["-version"],  $("chipFfmpeg"));
    checkTool("HandBrakeCLI", ["--version"], $("chipHb"));
  }
  updateSummary();
  checkAllTools();
  loadShellPath(function () { if (!IS_WIN) checkAllTools(); });

  // ------------------------------------------------------------ ui bits ---
  // Settings view toggle (gear) + in/out fields lighting up once filled.
  (function () {
    var gear = $("settingsBtn"), main = $("mainView"), settings = $("settingsView");
    if (gear && main && settings) {
      var rail = $("rail");
      var bar = document.querySelector(".bar");
      var barLabel = $("barLabel");
      gear.onclick = function () {
        var opening = settings.hasAttribute("hidden");
        if (opening) { settings.removeAttribute("hidden"); main.setAttribute("hidden", ""); }
        else { settings.setAttribute("hidden", ""); main.removeAttribute("hidden"); }
        if (rail) rail.hidden = opening;
        if (bar) bar.hidden = opening;
        if (barLabel) barLabel.hidden = opening;
        gear.classList.toggle("active", opening);
        gear.setAttribute("aria-expanded", opening ? "true" : "false");
        var tip = opening ? "Back to main" : "Settings";
        gear.title = tip;
        gear.setAttribute("aria-label", tip);
      };
    }

    // Digits-only timecodes group themselves from the right as you type:
    // 1 -> 15 -> 1:52 -> 15:20 -> 1:52:00 -> 15:20:00. Values containing
    // "." (fractional seconds) or anything but digits/colons are left alone.
    function formatTimecode(v) {
      if (v.indexOf(".") !== -1) return v;
      if (!/^[0-9:]*$/.test(v)) return v;
      var d = v.replace(/:/g, "");
      if (d.length > 7) d = d.slice(0, 7);
      if (d.length <= 2) return d;
      if (d.length <= 4) return d.slice(0, d.length - 2) + ":" + d.slice(-2);
      return d.slice(0, d.length - 4) + ":" + d.slice(-4, -2) + ":" + d.slice(-2);
    }
    function wireTimecode(id) {
      var input = $(id);
      if (!input) return;
      input.oninput = function () {
        var f = formatTimecode(this.value);
        if (f !== this.value) {
          this.value = f;
          try { this.setSelectionRange(f.length, f.length); } catch (e) {}
        }
      };
    }
    wireTimecode("timeIn");
    wireTimecode("timeOut");

    var clearTc = $("clearTcBtn");
    if (clearTc) {
      clearTc.onclick = function () {
        el.timeIn.value = "";
        el.timeOut.value = "";
      };
    }
    var clearUrl = $("clearUrlBtn");
    if (clearUrl) {
      clearUrl.onclick = function () {
        el.url.value = "";
        el.url.focus();
      };
    }
  })();

  log("YOINK! ready. Extension root: " + EXT_ROOT);
  log("Tools are used from bin/ when present, otherwise from PATH.", "note");
})();
