/* Minimal CSInterface shim for YOINK!.
 *
 * This implements only what the panel uses: evalScript() and getSystemPath().
 * It talks to the same window.__adobe_cep__ bridge that Adobe's official
 * CSInterface.js wraps. If you prefer the full library (events, theming,
 * host environment info), drop Adobe's CSInterface.js from the CEP-Resources
 * repository in place of this file — the API below is call-compatible.
 */

var SystemPath = {
  EXTENSION: "extension",
  USER_DATA: "userData",
  COMMON_FILES: "commonFiles",
  MY_DOCUMENTS: "myDocuments",
  HOST_APPLICATION: "hostApplication"
};

function CSInterface() {}

/** Result string CEP returns when ExtendScript throws before our own try/catch. */
CSInterface.EVAL_ERROR = "EvalScript error.";

/**
 * Run ExtendScript in the host app.
 * @param {string} script  ExtendScript source to evaluate.
 * @param {function(string)} [callback]  Receives the result as a string.
 */
CSInterface.prototype.evalScript = function (script, callback) {
  callback = callback || function () {};
  if (!window.__adobe_cep__) {
    callback(CSInterface.EVAL_ERROR);
    return;
  }
  window.__adobe_cep__.evalScript(script, callback);
};

/**
 * Resolve a CEP system path to a plain filesystem path.
 * CEP returns file:/// URLs; this strips the scheme and the stray leading
 * slash Windows drive letters end up with ("/C:/…" -> "C:/…").
 * @param {string} pathType  One of the SystemPath constants.
 * @returns {string}
 */
CSInterface.prototype.getSystemPath = function (pathType) {
  var raw = window.__adobe_cep__.getSystemPath(pathType);
  try { raw = decodeURI(raw); } catch (e) { /* keep raw */ }
  // Windows: file:///C:/x -> /C:/x -> C:/x     macOS: file:///Users/x -> /Users/x
  return raw
    .replace(/^file:\/\//, "")
    .replace(/^\/([A-Za-z]:)/, "$1");
};
