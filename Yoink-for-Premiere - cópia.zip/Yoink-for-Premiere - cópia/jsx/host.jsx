/* YOINK! — Premiere Pro host script.
 *
 * Runs inside Premiere's ExtendScript engine (ES3: var only, no modern JS).
 * Loaded automatically via <ScriptPath> in the manifest; the panel also
 * re-loads it with $.evalFile as a fallback.
 *
 * Entry point: CF_importAndInsert(filePath, mode, binName)
 *   mode: "playhead" | "append" | "bin"
 * Returns "OK|<detail>" or "ERR|<message>" (parsed by js/main.js).
 */

var CF_TICKS_PER_SECOND = 254016000000; // Premiere's internal ticks-per-second

function CF_norm(p) {
    return String(p).replace(/\//g, "\\").toLowerCase();
}

function CF_findItemByPath(container, target) {
    var i, it, hit;
    for (i = 0; i < container.children.numItems; i++) {
        it = container.children[i];
        if (it.type === ProjectItemType.BIN) {
            hit = CF_findItemByPath(it, target);
            if (hit) return hit;
        } else {
            try {
                var mp = it.getMediaPath();
                if (mp && CF_norm(mp) === target) return it;
            } catch (e) { /* some item types have no media path */ }
        }
    }
    return null;
}

function CF_getOrCreateBin(name) {
    var root = app.project.rootItem;
    var i, it;
    for (i = 0; i < root.children.numItems; i++) {
        it = root.children[i];
        if (it.type === ProjectItemType.BIN && it.name === name) return it;
    }
    return root.createBin(name);
}

function CF_firstUsableTrack(tracks) {
    var i, t;
    // 1) The track the editor has targeted (highlighted) in the timeline
    //    header wins. isTargeted() arrived around PPro 2018; fall through
    //    quietly where it doesn't exist.
    for (i = 0; i < tracks.numTracks; i++) {
        t = tracks[i];
        try {
            if (t.isTargeted() && !t.isLocked()) return t;
        } catch (eTarget) { break; }
    }
    // 2) Otherwise: the first unlocked track.
    for (i = 0; i < tracks.numTracks; i++) {
        t = tracks[i];
        try {
            if (!t.isLocked()) return t;
        } catch (e) {
            return t; // isLocked unavailable on very old versions
        }
    }
    return tracks.numTracks > 0 ? tracks[0] : null;
}

function CF_importAndInsert(filePath, mode, binName, audioFlag) {
    try {
        if (!app.project) return "ERR|No project is open in Premiere Pro.";

        var bin = CF_getOrCreateBin(binName || "Yoink");
        app.project.importFiles([filePath], true, bin, false);

        var target = CF_norm(filePath);
        var item = CF_findItemByPath(bin, target) ||
                   CF_findItemByPath(app.project.rootItem, target);
        if (!item) {
            return "ERR|The file was imported but its project item could not be located.";
        }

        if (mode === "bin") return "OK|bin";

        var seq = app.project.activeSequence;
        if (!seq) return "OK|bin-noseq"; // imported, nothing to insert into

        var seconds;
        if (mode === "append") {
            seconds = parseFloat(seq.end) / CF_TICKS_PER_SECOND; // seq.end is a tick string
            if (isNaN(seconds)) seconds = 0;
        } else {
            seconds = seq.getPlayerPosition().seconds;
        }

        var wantAudio = (audioFlag === "1");
        var track = CF_firstUsableTrack(wantAudio ? seq.audioTracks
                                                  : seq.videoTracks);
        if (!track) return "ERR|The active sequence has no usable " +
               (wantAudio ? "audio" : "video") + " track.";

        // insertClip performs an insert edit (downstream clips ripple later)
        // and brings the linked audio along automatically. Some Premiere
        // builds want seconds as a float, others accept a tick string — try
        // the float first and fall back.
        try {
            track.insertClip(item, seconds);
        } catch (e1) {
            try {
                track.insertClip(item, "" + Math.round(seconds * CF_TICKS_PER_SECOND));
            } catch (e2) {
                return "ERR|Timeline insert failed: " + e2 +
                       " (is video track 1 locked?)";
            }
        }

        return (mode === "append") ? "OK|append" : "OK|playhead";
    } catch (e) {
        return "ERR|" + e;
    }
}
