(function() {
    var __webpack_modules__ = {
        8708: function(module) {
            var JSON = {};
            var rx_one = /^[\],:{}\s]*$/;
            var rx_two = /\\(?:["\\\/bfnrt]|u[0-9a-fA-F]{4})/g;
            var rx_three = /"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g;
            var rx_four = /(?:^|:|,)(?:\s*\[)+/g;
            var rx_escapable = /[\\"\u0000-\u001f\u007f-\u009f\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g;
            var rx_dangerous = /[\u0000\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g;
            var gap;
            var indent;
            var meta;
            var rep;
            function quote(e) {
                rx_escapable.lastIndex = 0;
                return rx_escapable.test(e) ? '"' + e.replace(rx_escapable, function(e) {
                    var t = meta[e];
                    return typeof t === "string" ? t : "\\u" + ("0000" + e.charCodeAt(0).toString(16)).slice(-4);
                }) + '"' : '"' + e + '"';
            }
            function str(e, t) {
                var r;
                var n;
                var o;
                var i;
                var a = gap;
                var u;
                var s = t[e];
                if (s && typeof s === "object" && typeof s.toJSON === "function") {
                    s = s.toJSON(e);
                }
                if (typeof rep === "function") {
                    s = rep.call(t, e, s);
                }
                switch (typeof s) {
                  case "string":
                    return quote(s);

                  case "number":
                    return isFinite(s) ? String(s) : "null";

                  case "boolean":
                  case "null":
                    return String(s);

                  case "object":
                    if (!s) {
                        return "null";
                    }
                    gap += indent;
                    u = [];
                    if (Object.prototype.toString.apply(s) === "[object Array]") {
                        i = s.length;
                        for (r = 0; r < i; r += 1) {
                            u[r] = str(r, s) || "null";
                        }
                        o = u.length === 0 ? "[]" : (gap ? "[\n" + gap + u.join(",\n" + gap) + "\n" + a + "]" : "[" + u.join(",") + "]");
                        gap = a;
                        return o;
                    }
                    if (rep && typeof rep === "object") {
                        i = rep.length;
                        for (r = 0; r < i; r += 1) {
                            if (typeof rep[r] === "string") {
                                n = rep[r];
                                o = str(n, s);
                                if (o) {
                                    u.push(quote(n) + (gap ? ": " : ":") + o);
                                }
                            }
                        }
                    } else {
                        for (n in s) {
                            if (Object.prototype.hasOwnProperty.call(s, n)) {
                                o = str(n, s);
                                if (o) {
                                    u.push(quote(n) + (gap ? ": " : ":") + o);
                                }
                            }
                        }
                    }
                    o = u.length === 0 ? "{}" : (gap ? "{\n" + gap + u.join(",\n" + gap) + "\n" + a + "}" : "{" + u.join(",") + "}");
                    gap = a;
                    return o;
                }
            }
            meta = {
                "\b": "\\b",
                "\t": "\\t",
                "\n": "\\n",
                "\f": "\\f",
                "\r": "\\r",
                '"': '\\"',
                "\\": "\\\\"
            };
            JSON.stringify = function(e, t, r) {
                var n;
                gap = "";
                indent = "";
                if (typeof r === "number") {
                    for (n = 0; n < r; n += 1) {
                        indent += " ";
                    }
                } else if (typeof r === "string") {
                    indent = r;
                }
                rep = t;
                if (t && typeof t !== "function" && (typeof t !== "object" || typeof t.length !== "number")) {
                    throw new Error("JSON.stringify");
                }
                return str("", {
                    "": e
                });
            };
            JSON.parse = function(text, reviver) {
                var j;
                function walk(e, t) {
                    var r;
                    var n;
                    var o = e[t];
                    if (o && typeof o === "object") {
                        for (r in o) {
                            if (Object.prototype.hasOwnProperty.call(o, r)) {
                                n = walk(o, r);
                                if (n !== undefined) {
                                    o[r] = n;
                                } else {
                                    delete o[r];
                                }
                            }
                        }
                    }
                    return reviver.call(e, t, o);
                }
                text = String(text);
                rx_dangerous.lastIndex = 0;
                if (rx_dangerous.test(text)) {
                    text = text.replace(rx_dangerous, function(e) {
                        return "\\u" + ("0000" + e.charCodeAt(0).toString(16)).slice(-4);
                    });
                }
                if (rx_one.test(text.replace(rx_two, "@").replace(rx_three, "]").replace(rx_four, ""))) {
                    j = eval("(" + text + ")");
                    return typeof reviver === "function" ? walk({
                        "": j
                    }, "") : j;
                }
                throw new SyntaxError("JSON.parse");
            };
            module.exports = JSON;
        },
        5521: function(e, t) {
            var o = "useandom-26T198340PX75pxJACKVERYMINDBUSHWOLF_GQZbfghjklqvwyzrict";
            t.nanoid = function e(t) {
                if (t === void 0) {
                    t = 21;
                }
                var r = "";
                var n = t;
                while (n--) {
                    r += o[Math.random() * 64 | 0];
                }
                return r;
            };
        },
        9185: function(e) {
            var o = 0;
            var i = 1;
            var a = 2;
            function u(e) {
                this._state = o;
                this._value = undefined;
                var t = this;
                function r(e) {
                    if (t._state !== o) return;
                    if (e instanceof u) {
                        e.then(r, n);
                    } else {
                        t._state = i;
                        t._value = e;
                    }
                }
                function n(e) {
                    if (t._state !== o) return;
                    t._state = a;
                    t._value = e;
                }
                try {
                    e(r, n);
                } catch (e) {
                    n(e);
                }
                if (this._state === o) {
                    throw new Error("Promise was not resolved synchronously");
                }
            }
            u.resolve = function(t) {
                return new u(function(e) {
                    e(t);
                });
            };
            u.reject = function(r) {
                return new u(function(e, t) {
                    t(r);
                });
            };
            u.all = function(a) {
                return new u(function(r, e) {
                    var n = [];
                    var o = a.length;
                    if (o === 0) {
                        r(n);
                        return;
                    }
                    function t(t) {
                        u.resolve(a[t]).then(function(e) {
                            n[t] = e;
                            o--;
                            if (o === 0) {
                                r(n);
                            }
                        }, e);
                    }
                    for (var i = 0; i < a.length; i++) {
                        t(i);
                    }
                });
            };
            u.race = function() {
                throw new Error("Not implemented");
            };
            u.prototype.then = function(e, t) {
                if (this._state === o) {
                    throw new Error("Promise was not resolved synchronously");
                }
                if (this._state === a) {
                    if (t === undefined) {
                        return u.reject(this._value);
                    }
                    try {
                        return u.resolve(t(this._value));
                    } catch (e) {
                        return u.reject(e);
                    }
                }
                if (this._state === i) {
                    if (e === undefined) {
                        return u.resolve(this._value);
                    }
                    if (this._value instanceof u) {
                        return this._value.then(e, t);
                    } else {
                        try {
                            return u.resolve(e(this._value));
                        } catch (e) {
                            return u.reject(e);
                        }
                    }
                }
            };
            u.prototype.catch = function(e) {
                return this.then(null, e);
            };
            e.exports = u;
        },
        9091: function(e, t) {
            "use strict";
            t.__esModule = true;
            t.registerPlugin = t.loadPlugin = void 0;
            var o = $;
            function r(e, t) {
                var r = o[t];
                if (r != null) {
                    try {
                        r.destroy();
                    } catch (e) {
                        $.writeln("Failed to unload existing instance of " + t);
                    }
                }
                delete o[t];
                var n = new File(e);
                $.evalFile(n);
            }
            t.loadPlugin = r;
            function n(e, t) {
                if (o[e] != null) return;
                var r = t();
                o[e] = r;
            }
            t.registerPlugin = n;
        },
        8537: function(e, t, r) {
            "use strict";
            var n = r(8708);
            var o = this && this.__assign || function() {
                o = Object.assign || function(e) {
                    for (var t, r = 1, n = arguments.length; r < n; r++) {
                        t = arguments[r];
                        for (var o in t) if (Object.prototype.hasOwnProperty.call(t, o)) e[o] = t[o];
                    }
                    return e;
                };
                return o.apply(this, arguments);
            };
            t.__esModule = true;
            t.executeEventHandler = t.wrapApiImplementation = t.executeApiCall = void 0;
            var i = r(9008);
            function a(e) {
                try {
                    var t = e();
                    return n.stringify({
                        result: t
                    });
                } catch (e) {
                    return n.stringify({
                        error: c(e)
                    });
                }
            }
            t.executeApiCall = a;
            function u(n) {
                var t = {};
                var e = function(e) {
                    var r = n[e];
                    if (typeof r === "function") {
                        t[e] = function() {
                            var e = [];
                            for (var t = 0; t < arguments.length; t++) {
                                e[t] = arguments[t];
                            }
                            return a(function() {
                                return r.apply(n, e);
                            });
                        };
                    }
                };
                for (var r in n) {
                    e(r);
                }
                return t;
            }
            t.wrapApiImplementation = u;
            function s(e) {
                try {
                    e();
                } catch (e) {
                    p(e);
                }
            }
            t.executeEventHandler = s;
            function c(e) {
                if (e instanceof i.RetryableError) {
                    return o({
                        type: e.name,
                        retryOptions: e.retryParams
                    }, l(e));
                } else if (e instanceof i.UserError) {
                    return o({
                        type: e.name
                    }, l(e));
                } else if (e instanceof i.BaseError) {
                    return o({
                        type: e.name
                    }, l(e));
                } else if (e instanceof Error) {
                    return {
                        type: "UnhandledException",
                        message: e.description
                    };
                } else {
                    return {
                        type: "UnhandledException",
                        message: "Unknown error: ".concat(e)
                    };
                }
            }
            function l(e) {
                return {
                    message: e.message,
                    internalInfo: o({
                        jsxName: e.name,
                        jsxStack: e.stack
                    }, e.getExtraData())
                };
            }
            function p(e) {
                var t = new CSXSEvent();
                t.type = "com.misterhorse.pc.api.Error";
                t.data = n.stringify({
                    error: c(e)
                });
                t.dispatch();
            }
        },
        9008: function(e, t, r) {
            "use strict";
            var n = r(8708);
            var i = this && this.__extends || function() {
                var n = function(e, t) {
                    n = Object.setPrototypeOf || {
                        __proto__: []
                    } instanceof Array && function(e, t) {
                        e.__proto__ = t;
                    } || function(e, t) {
                        for (var r in t) if (Object.prototype.hasOwnProperty.call(t, r)) e[r] = t[r];
                    };
                    return n(e, t);
                };
                return function(e, t) {
                    if (typeof t !== "function" && t !== null) throw new TypeError("Class extends value " + String(t) + " is not a constructor or null");
                    n(e, t);
                    function r() {
                        this.constructor = e;
                    }
                    e.prototype = t === null ? Object.create(t) : (r.prototype = t.prototype, 
                    new r());
                };
            }();
            var o = this && this.__assign || function() {
                o = Object.assign || function(e) {
                    for (var t, r = 1, n = arguments.length; r < n; r++) {
                        t = arguments[r];
                        for (var o in t) if (Object.prototype.hasOwnProperty.call(t, o)) e[o] = t[o];
                    }
                    return e;
                };
                return o.apply(this, arguments);
            };
            t.__esModule = true;
            t.RetryableError = t.UserError = t.StaleTargetError = t.Exception = t.BaseError = void 0;
            var a = function() {
                function e(e, t, r) {
                    this.name = e;
                    this.message = t;
                    this.stack = $.stack;
                    this.extraData = r;
                }
                e.prototype.serialize = function() {
                    return n.stringify(o({
                        name: this.name,
                        message: this.message,
                        jsxStack: this.stack
                    }, this.getExtraData()));
                };
                e.prototype.toString = function() {
                    return "".concat(this.name, ": ").concat(this.message);
                };
                e.prototype.getExtraData = function() {
                    var e;
                    return (e = this.extraData) !== null && e !== void 0 ? e : {};
                };
                return e;
            }();
            t.BaseError = a;
            var u = function(r) {
                i(e, r);
                function e(e, t) {
                    if (t === void 0) {
                        t = {};
                    }
                    return r.call(this, "UnhandledException", e, t) || this;
                }
                return e;
            }(a);
            t.Exception = u;
            var s = function(r) {
                i(e, r);
                function e(e, t) {
                    return r.call(this, "StaleTargetError", e, t) || this;
                }
                return e;
            }(a);
            t.StaleTargetError = s;
            var c = function(r) {
                i(e, r);
                function e(e, t) {
                    return r.call(this, "Error", e, t) || this;
                }
                return e;
            }(a);
            t.UserError = c;
            var l = function(o) {
                i(e, o);
                function e(e, t, r) {
                    var n = o.call(this, "RetryableError", e, r) || this;
                    n.retryParams = t;
                    return n;
                }
                return e;
            }(a);
            t.RetryableError = l;
        },
        4428: function(e, t, r) {
            "use strict";
            var u = r(8708);
            var n = this && this.__extends || function() {
                var n = function(e, t) {
                    n = Object.setPrototypeOf || {
                        __proto__: []
                    } instanceof Array && function(e, t) {
                        e.__proto__ = t;
                    } || function(e, t) {
                        for (var r in t) if (Object.prototype.hasOwnProperty.call(t, r)) e[r] = t[r];
                    };
                    return n(e, t);
                };
                return function(e, t) {
                    if (typeof t !== "function" && t !== null) throw new TypeError("Class extends value " + String(t) + " is not a constructor or null");
                    n(e, t);
                    function r() {
                        this.constructor = e;
                    }
                    e.prototype = t === null ? Object.create(t) : (r.prototype = t.prototype, 
                    new r());
                };
            }();
            var s = this && this.__spreadArray || function(e, t, r) {
                if (r || arguments.length === 2) for (var n = 0, o = t.length, i; n < o; n++) {
                    if (i || !(n in t)) {
                        if (!i) i = Array.prototype.slice.call(t, 0, n);
                        i[n] = t[n];
                    }
                }
                return e.concat(i || Array.prototype.slice.call(t));
            };
            t.__esModule = true;
            t.MHExternalObject = void 0;
            var o = r(9008);
            var i = function() {
                function e(e) {
                    this.externalObject = null;
                    this.supportFiles = e;
                }
                e.prototype.load = function() {
                    try {
                        this.externalObject = new ExternalObject("lib:" + this.getLibPath());
                    } catch (e) {
                        throw new Error("Failed to load external object: " + e.message);
                    }
                };
                e.prototype.callMethod = function(e) {
                    var t;
                    var r = [];
                    for (var n = 1; n < arguments.length; n++) {
                        r[n - 1] = arguments[n];
                    }
                    if (this.externalObject === null) {
                        throw new Error("External object is not loaded");
                    }
                    var o = this.externalObject;
                    var i = (t = o[e]).call.apply(t, s([ o ], r, false));
                    var a = u.parse(i);
                    if ("error" in a) {
                        throw new c(a.error);
                    }
                    return a.result;
                };
                return e;
            }();
            t.MHExternalObject = i;
            var c = function(o) {
                n(e, o);
                function e(e) {
                    var t, r;
                    var n = o.call(this, (t = e.type) !== null && t !== void 0 ? t : "ExternalObjectError", (r = e.message) !== null && r !== void 0 ? r : "Unknown error") || this;
                    n.error = e;
                    return n;
                }
                e.prototype.getExtraData = function() {
                    return {
                        code: this.error.code,
                        data: this.error.data
                    };
                };
                return e;
            }(o.BaseError);
        },
        5842: function(e, t, r) {
            "use strict";
            t.__esModule = true;
            t.Plugin = void 0;
            var n = r(1008);
            var o = function() {
                function e() {
                    this.supportFiles = new n.SupportFiles();
                    this.initialized = false;
                }
                e.prototype.initPlugPlug = function() {
                    new ExternalObject("lib:PlugPlugExternalObject");
                };
                e.prototype.initPlugin = function() {};
                e.prototype.dispatchReadyEvent = function() {};
                e.prototype.initialize = function(e) {
                    if (this.initialized) return;
                    this.supportFiles.setExtensionPath(e);
                    this.initPlugPlug();
                    this.initPlugin();
                    this.dispatchReadyEvent();
                    this.initialized = true;
                };
                e.prototype.destroy = function() {};
                return e;
            }();
            t.Plugin = o;
        },
        1008: function(e, t, r) {
            "use strict";
            t.__esModule = true;
            t.SupportFiles = void 0;
            var n = r(9008);
            var o = function() {
                function e() {
                    this.extensionPath = "";
                }
                e.prototype.setExtensionPath = function(e) {
                    this.extensionPath = e;
                };
                e.prototype.getFilePath = function(e) {
                    return this.getPlatformFilePath({
                        windows: e,
                        macos: e
                    });
                };
                e.prototype.getPlatformFilePath = function(e) {
                    if (this.extensionPath === "") throw new n.Exception("Extension path not set");
                    switch (File.fs) {
                      case "Windows":
                        return "".concat(this.extensionPath, "\\support_files\\").concat(e.windows);

                      case "Macintosh":
                        return "".concat(this.extensionPath, "/support_files/").concat(e.macos);

                      default:
                        throw new n.Exception("Unsupported platform: ".concat(File.fs));
                    }
                };
                return e;
            }();
            t.SupportFiles = o;
        },
        9401: function(e, t, r) {
            "use strict";
            var a = r(9185);
            t.__esModule = true;
            t.EditorManager = void 0;
            var u = r(6408);
            var o = r(6280);
            var i = r(6085);
            var s = r(214);
            var c = r(4666);
            var n = r(633);
            var l = r(9008);
            var p = r(420);
            var f = r(6061);
            var d = r(2936);
            var h = function() {
                function e(e, t, r, n, o) {
                    this.currentSelectionEditor = null;
                    this.activeUndoGroup = null;
                    this.undoGroupTimer = null;
                    this.editorGeneration = 0;
                    this.graphics = t;
                    this.historyManager = new s.HistoryManager();
                    this.events = new i.CEPEvents();
                    this.corruptedClipsFixer = new p.CorruptedClipsFixer(this.events, e, r);
                    this.playbackManager = new f.PlaybackManager(e);
                    this.palettes = n;
                    this.presets = o;
                }
                e.prototype.updateSelectionEditor = function() {
                    var e, t;
                    var r = (e = app.project) === null || e === void 0 ? void 0 : e.activeSequence;
                    var n = r != null ? (0, c.getProjectBySequenceId)(r.sequenceID) : null;
                    if (r == null || n == null) {
                        this.editorGeneration++;
                        this.currentSelectionEditor = null;
                        return a.resolve();
                    }
                    if ((t = this.currentSelectionEditor) === null || t === void 0 ? void 0 : t.isEqualToSelection(n, r)) {
                        return this.currentSelectionEditor.update();
                    }
                    this.corruptedClipsFixer.detectCorruptedClips(r);
                    return this.createSelectionEditor();
                };
                e.prototype.updateProjectHistory = function(e) {
                    var t = this.historyManager.getHistory(e);
                    t.update();
                };
                e.prototype.clearProjectHistory = function(e) {
                    this.historyManager.clearHistory(e);
                };
                e.prototype.getSerializedState = function() {
                    if (this.currentSelectionEditor == null) {
                        return null;
                    }
                    return this.currentSelectionEditor.serialize();
                };
                e.prototype.getPropertyValues = function() {
                    if (this.currentSelectionEditor == null) {
                        return null;
                    }
                    var e = this.currentSelectionEditor.getPropertyTree();
                    var t = {};
                    e.getPropertyValues(t);
                    return t;
                };
                e.prototype.setPropertyValue = function(e, t, r) {
                    var n = this;
                    var o = this.getProperty(e);
                    return this.getBoundHistory().executeTransaction(function() {
                        return o.setValue(t, r);
                    }).then(function() {
                        var e;
                        return (e = n.currentSelectionEditor) === null || e === void 0 ? void 0 : e.update();
                    });
                };
                e.prototype.resetPropertyValue = function(e) {
                    var t = this;
                    var r = this.getProperty(e);
                    return this.getBoundHistory().executeTransaction(function() {
                        return r.resetValue();
                    }).then(function() {
                        var e;
                        return (e = t.currentSelectionEditor) === null || e === void 0 ? void 0 : e.update();
                    });
                };
                e.prototype.callPropertyAction = function(e, t, r) {
                    if (r === void 0) {
                        r = {};
                    }
                    return this.getProperty(e).callAction(t, r);
                };
                e.prototype.getCaptionClipInfo = function(e) {
                    var t = this.getProperty(e);
                    if (t instanceof d.TranscriptAggregateProperty) {
                        return t.getClipInfo();
                    }
                    throw new l.Exception("Property is not a TranscriptAggregateProperty");
                };
                e.prototype.getCaptionClipData = function(e) {
                    var t = this.getProperty(e);
                    if (t instanceof d.TranscriptAggregateProperty) {
                        return t.getClipData();
                    }
                    throw new l.Exception("Property is not a TranscriptAggregateProperty");
                };
                e.prototype.updateCaptionClipData = function(e, t) {
                    var r = this.getProperty(e);
                    if (!(r instanceof d.TranscriptAggregateProperty)) {
                        return a.reject(new l.Exception("Property is not a TranscriptAggregateProperty"));
                    }
                    return this.getBoundHistory().executeTransaction(function() {
                        r.updateClipData(t);
                        return a.resolve();
                    });
                };
                e.prototype.saveUserPalette = function(e, t) {
                    var r = this;
                    var n = this.getProperty(e);
                    if (!(n instanceof o.PaletteProperty)) {
                        throw new l.Exception("Property is not a palette");
                    }
                    return n.savePalette(t).then(function() {
                        return r.createSelectionEditor();
                    });
                };
                e.prototype.removeUserPalette = function(e) {
                    this.palettes.removeUserPalette(e);
                    return this.createSelectionEditor();
                };
                e.prototype.startUndoGroup = function(e) {
                    var t, r;
                    if (this.currentSelectionEditor == null) return;
                    var n = new y(e, this.getBoundHistory());
                    if ((t = this.activeUndoGroup) === null || t === void 0 ? void 0 : t.isEqual(n)) {
                        (r = this.undoGroupTimer) === null || r === void 0 ? void 0 : r.cancel();
                        this.startUndoGroupTimer(e);
                        return;
                    }
                    if (this.activeUndoGroup != null) {
                        this.endUndoGroup();
                    }
                    n.history.startEntry();
                    this.activeUndoGroup = n;
                    this.startUndoGroupTimer(e);
                };
                e.prototype.endUndoGroup = function(e) {
                    var t;
                    if (this.activeUndoGroup == null) return;
                    if (e != null && this.activeUndoGroup.undoGroupId !== e) {
                        throw new l.Exception("The undo group ID does not match the current undo group");
                    }
                    (t = this.undoGroupTimer) === null || t === void 0 ? void 0 : t.cancel();
                    this.undoGroupTimer = null;
                    var r = this.activeUndoGroup.history;
                    this.activeUndoGroup = null;
                    r.endEntry();
                };
                e.prototype.undo = function() {
                    this.endUndoGroup();
                    qe.project.undo();
                };
                e.prototype.fixCorruptedClips = function() {
                    var e = app.project;
                    var t = e === null || e === void 0 ? void 0 : e.activeSequence;
                    if (e == null || t == null) {
                        throw new l.UserError("No sequence is active");
                    }
                    this.corruptedClipsFixer.fixClips(e, t);
                };
                e.prototype.togglePlay = function() {
                    this.playbackManager.togglePlay();
                };
                e.prototype.getBoundHistory = function() {
                    if (this.currentSelectionEditor == null) {
                        throw new l.Exception("Editor not initialized");
                    }
                    return this.currentSelectionEditor.getHistory();
                };
                e.prototype.startUndoGroupTimer = function(e) {
                    var t = this;
                    this.undoGroupTimer = (0, n.createTimer)(function() {
                        t.endUndoGroup(e);
                    }, v);
                };
                e.prototype.createSelectionEditor = function() {
                    var e = this;
                    var t;
                    var r = (t = app.project) === null || t === void 0 ? void 0 : t.activeSequence;
                    var n = r != null ? (0, c.getProjectBySequenceId)(r.sequenceID) : null;
                    var o = ++this.editorGeneration;
                    if (r == null || n == null) {
                        this.currentSelectionEditor = null;
                        return a.resolve();
                    }
                    var i = new u.SequenceSelectionEditor(this.graphics, this.events, this.palettes, this.presets, this.historyManager.getHistory(n.documentID));
                    return i.initialize(n, r).then(function() {
                        if (o !== e.editorGeneration) return;
                        e.currentSelectionEditor = i;
                        e.events.notifyEditorReplaced();
                    });
                };
                e.prototype.getProperty = function(e) {
                    if (this.currentSelectionEditor == null) {
                        throw new l.Exception("Editor not initialized");
                    }
                    var t = this.currentSelectionEditor.getPropertyTree();
                    var r = t.findPropertyById(e);
                    if (r == null) {
                        throw new l.StaleTargetError("Property not found", {
                            propertyId: e
                        });
                    }
                    return r;
                };
                return e;
            }();
            t.EditorManager = h;
            var v = 1e3;
            var y = function() {
                function e(e, t) {
                    this.undoGroupId = e;
                    this.history = t;
                }
                e.prototype.isEqual = function(e) {
                    return e.undoGroupId === this.undoGroupId && e.history === this.history;
                };
                return e;
            }();
        },
        6258: function(e, t, r) {
            "use strict";
            var n = this && this.__extends || function() {
                var n = function(e, t) {
                    n = Object.setPrototypeOf || {
                        __proto__: []
                    } instanceof Array && function(e, t) {
                        e.__proto__ = t;
                    } || function(e, t) {
                        for (var r in t) if (Object.prototype.hasOwnProperty.call(t, r)) e[r] = t[r];
                    };
                    return n(e, t);
                };
                return function(e, t) {
                    if (typeof t !== "function" && t !== null) throw new TypeError("Class extends value " + String(t) + " is not a constructor or null");
                    n(e, t);
                    function r() {
                        this.constructor = e;
                    }
                    e.prototype = t === null ? Object.create(t) : (r.prototype = t.prototype, 
                    new r());
                };
            }();
            t.__esModule = true;
            t.ChangeSet = t.ParamTargetNotFoundException = void 0;
            var o = r(4666);
            var i = r(4530);
            var a = r(3066);
            var u = r(9008);
            var s = r(5474);
            var c = function(r) {
                n(e, r);
                function e(e, t) {
                    if (t === void 0) {
                        t = {};
                    }
                    return r.call(this, e, t) || this;
                }
                return e;
            }(u.Exception);
            t.ParamTargetNotFoundException = c;
            var l = function() {
                function e(e, t, r, n) {
                    this.sequenceId = e;
                    this.clipId = t;
                    this.paramIndex = r;
                    this.command = n;
                }
                e.prototype.mergeCommand = function(e) {
                    if (this.command instanceof a.ChangePlainValue && e instanceof a.ChangePlainValue) {
                        this.command.merge(e);
                    } else if (this.command instanceof a.ChangeColorValue && e instanceof a.ChangeColorValue) {
                        this.command.merge(e);
                    } else if (this.command instanceof a.ChangeDurationValue && e instanceof a.ChangeDurationValue) {
                        this.command.merge(e);
                    } else if (this.command instanceof a.ChangeTextValue && e instanceof a.ChangeTextValue) {
                        this.command.merge(e);
                    } else {
                        throw new u.Exception("Cannot merge values of different types");
                    }
                };
                e.prototype.apply = function(e, t, r) {
                    var n = this.getCommandContext(e, t, r);
                    this.command.apply(n);
                };
                e.prototype.revert = function(e) {
                    var t = this.getCommandContext(e);
                    this.command.revert(t);
                };
                e.prototype.getCommandContext = function(e, t, r) {
                    var n = this.getSequence(e, t);
                    if (n == null) throw new c("Sequence not found in param change", this.targetInfo());
                    var o = this.getClip(n, r);
                    if (o == null) throw new c("Clip not found in param change", this.targetInfo());
                    var i = this.getParam(o);
                    if (i == null) throw new c("Param not found in param change", this.targetInfo());
                    return {
                        project: e,
                        sequence: n,
                        clip: o,
                        param: i
                    };
                };
                e.prototype.targetInfo = function() {
                    return {
                        sequenceId: this.sequenceId,
                        clipId: this.clipId,
                        paramIndex: this.paramIndex
                    };
                };
                e.prototype.getSequence = function(e, t) {
                    if ((t === null || t === void 0 ? void 0 : t.sequenceID) === this.sequenceId) {
                        return t;
                    }
                    return (0, i.getSequenceById)(e, this.sequenceId);
                };
                e.prototype.getClip = function(e, t) {
                    if ((t === null || t === void 0 ? void 0 : t.nodeId) === this.clipId) {
                        return t;
                    }
                    for (var r = 0; r < e.videoTracks.length; r++) {
                        var n = e.videoTracks[r];
                        for (var o = 0; o < n.clips.length; o++) {
                            var i = n.clips[o];
                            if (i.nodeId === this.clipId) return i;
                        }
                    }
                    return null;
                };
                e.prototype.getParam = function(e) {
                    var t = e.getMGTComponent();
                    if (t == null) return null;
                    return t.properties[this.paramIndex];
                };
                return e;
            }();
            var p = function() {
                function e(e) {
                    this.changedValues = {};
                    this.projectId = e;
                }
                e.prototype.addChange = function(e, t, r, n) {
                    var o = this.getKey(e, t, r);
                    var i = this.changedValues[o];
                    if (i == null) {
                        i = new l(e, t, r, n);
                        this.changedValues[o] = i;
                    } else {
                        i.mergeCommand(n);
                    }
                    return i;
                };
                e.prototype.applyChange = function(e, t, r) {
                    var n = this.getProject();
                    if (n == null) throw new u.Exception("Project not found in changeset");
                    e.apply(n, t, r);
                };
                e.prototype.applyAll = function() {
                    var r = this.getProject();
                    if (r == null) throw new u.Exception("Project not found in changeset");
                    var e = function(e) {
                        var t = n.changedValues[e];
                        n.replayChange(function() {
                            return t.apply(r);
                        }, t);
                    };
                    var n = this;
                    for (var t in this.changedValues) {
                        e(t);
                    }
                };
                e.prototype.revertAll = function() {
                    var r = this.getProject();
                    if (r == null) throw new u.Exception("Project not found in changeset");
                    var e = function(e) {
                        var t = n.changedValues[e];
                        n.replayChange(function() {
                            return t.revert(r);
                        }, t);
                    };
                    var n = this;
                    for (var t in this.changedValues) {
                        e(t);
                    }
                };
                e.prototype.replayChange = function(e, t) {
                    try {
                        e();
                    } catch (e) {
                        if (e instanceof c) {
                            s.console.log("Skipping param change during replay:", e.message, t.targetInfo());
                            return;
                        }
                        throw e;
                    }
                };
                e.prototype.getProject = function() {
                    return (0, o.getProjectById)(this.projectId);
                };
                e.prototype.getKey = function(e, t, r) {
                    return "".concat(e, ":").concat(t, ":").concat(r);
                };
                return e;
            }();
            t.ChangeSet = p;
        },
        8711: function(e, t, r) {
            "use strict";
            var V = this && this.__assign || function() {
                V = Object.assign || function(e) {
                    for (var t, r = 1, n = arguments.length; r < n; r++) {
                        t = arguments[r];
                        for (var o in t) if (Object.prototype.hasOwnProperty.call(t, o)) e[o] = t[o];
                    }
                    return e;
                };
                return V.apply(this, arguments);
            };
            t.__esModule = true;
            t.ClipTreeBuilder = void 0;
            var n = r(2037);
            var I = r(3285);
            var v = r(3575);
            var _ = r(5802);
            var b = r(8852);
            var E = r(2971);
            var l = r(6280);
            var w = r(5645);
            var c = r(2936);
            var j = r(4559);
            var k = r(5938);
            var p = r(1137);
            var f = r(9388);
            var o = function() {
                function e(e, t, r, n) {
                    this.graphics = e;
                    this.events = t;
                    this.palettes = r;
                    this.history = n;
                }
                e.prototype.isClipEditable = function(e) {
                    if (e.projectItem == null) return false;
                    var t = e.projectItem.getMediaPath();
                    if (!/\.aegraphic$/.test(t)) return false;
                    var r = e.getMGTComponent();
                    if (r == null) return false;
                    return true;
                };
                e.prototype.buildClipTree = function(P, C) {
                    var T = this;
                    var e;
                    var t = _.PropertyTreeNode.createRootNode();
                    if (!this.isClipEditable(P)) return t;
                    var r = P.projectItem.getMediaPath();
                    var n = P.getMGTComponent();
                    var x;
                    try {
                        x = this.graphics.getGraphicParams(r);
                    } catch (e) {
                        return t;
                    }
                    var I = (0, v.getMetaPropertyValue)(n);
                    var w = C.getSettings();
                    if (x.controls.length !== n.properties.length) {
                        return t;
                    }
                    var o = (0, j.buildControlTree)(x.controls);
                    var S = (e = I === null || I === void 0 ? void 0 : I.pIgnC) !== null && e !== void 0 ? e : [];
                    var F = function(e) {
                        var t, r;
                        var n = e.control, o = e.originalIndex, i = e.parent, a = e.children;
                        if (n.type == j.ControlType.Group) {
                            var u = _.PropertyTreeNode.createGroupNode(n.name);
                            for (var s = 0, c = a; s < c.length; s++) {
                                var l = c[s];
                                var p = F(l);
                                for (var f = 0, d = p; f < d.length; f++) {
                                    var h = d[f];
                                    u.addChild(h);
                                }
                            }
                            return [ u ];
                        } else if (n.type === j.ControlType.Slider && (0, j.isDurationControl)(n, i)) {
                            var v = V(V({}, A(w)), {
                                defaultDuration: (t = I === null || I === void 0 ? void 0 : I.defDur) !== null && t !== void 0 ? t : n["default"],
                                maxDuration: (r = I === null || I === void 0 ? void 0 : I.maxDur) !== null && r !== void 0 ? r : 0
                            });
                            var y = new b.DurationProperty(T.events, T.history, C, P, o, v);
                            return [ _.PropertyTreeNode.createPropertyNode(y) ];
                        } else if (n.type == j.ControlType.Text) {
                            return T.createTextNodes(n, I, P, C, o);
                        } else {
                            var g = (0, k.createValueDefinitionFromControl)(n, i === null || i === void 0 ? void 0 : i.control);
                            if (g == null) return [];
                            var m = n.type === j.ControlType.Media;
                            var v = {
                                valueType: q(n.type),
                                defaultValue: M(n),
                                includeInPreset: !(0, j.isControlIgnored)(e, S) && !m,
                                graphicWidth: x.width,
                                graphicHeight: x.height
                            };
                            var y = new E.MogrtProperty(T.events, n.name, T.history, C, P, o, g, v);
                            return [ _.PropertyTreeNode.createPropertyNode(y) ];
                        }
                    };
                    var i = _.PropertyTreeNode.createSectionNode("Precomp Settings");
                    for (var a = 0, u = o; a < u.length; a++) {
                        var s = u[a];
                        var c = s.control;
                        if ((0, j.isCaptionGroup)(c)) {
                            var l = this.createCaptionNode(c, P, C);
                            t.addChild(l);
                        } else if (!(0, j.isMetadataGroup)(c)) {
                            var p = F(s);
                            for (var f = 0, d = p; f < d.length; f++) {
                                var h = d[f];
                                i.addChild(h);
                            }
                        }
                    }
                    t.addChild(i);
                    this.combineCheckboxGroups(t);
                    this.combineColorGroups(t);
                    this.combineTextProperties(t);
                    this.addPaletteProperty(t, x, I);
                    return t;
                };
                e.prototype.createTextNodes = function(e, t, r, n, o) {
                    var i;
                    var a = {
                        history: this.history,
                        sequence: n,
                        clip: r,
                        paramIndex: o,
                        defaultValue: e["default"]
                    };
                    var u = (i = t === null || t === void 0 ? void 0 : t.fontReuseGroupId) !== null && i !== void 0 ? i : null;
                    var s;
                    var c = [];
                    if ((0, I.isFontFamilyEditable)(e["default"])) {
                        var l = new w.FontFamilyProperty(this.events, "Font", a, u);
                        c.push(l);
                        s = l.id;
                    }
                    if ((0, I.isFontSizeEditable)(e["default"])) {
                        var p = new w.FontSizeProperty(this.events, "Font Size", a);
                        c.push(p);
                    }
                    if ((0, I.isStyleEditable)(e["default"])) {
                        var f = new w.FontBoldProperty(this.events, "Bold", a);
                        c.push(f);
                        var d = new w.FontItalicProperty(this.events, "Italic", a);
                        c.push(d);
                        var h = new w.FontVariantProperty(this.events, "Variant", a);
                        c.push(h);
                    }
                    var v = new w.TextGroupProperty(this.events, e.name, c);
                    var y = _.PropertyTreeNode.createTextPropertiesGroupNode(e.name, v);
                    var g = new w.TextProperty(this.events, e.name, a, s);
                    var m = _.PropertyTreeNode.createPropertyNode(g);
                    y.addChild(m);
                    for (var P = 0, C = c; P < C.length; P++) {
                        var T = C[P];
                        var x = _.PropertyTreeNode.createPropertyNode(T);
                        y.addChild(x);
                    }
                    return [ y ];
                };
                e.prototype.createCaptionNode = function(e, t, r) {
                    var n = (0, p.getCaptionProperties)(t);
                    var o = V(V({}, A(r.getSettings())), {
                        hashParamIndex: n.hash.propertyIndex,
                        captionParamIndices: (0, f.map)(n.caption, function(e) {
                            return e.propertyIndex;
                        }),
                        editorParamIndices: (0, f.map)(n.editor, function(e) {
                            return e.propertyIndex;
                        })
                    });
                    var i = new c.TranscriptProperty(this.events, this.history, r, t, o);
                    var a = new c.TranscriptAggregateProperty(this.events, this.history, r);
                    a.addProperty(i);
                    var u = _.PropertyTreeNode.createPropertyNode(a);
                    var s = _.PropertyTreeNode.createCaptionGroupNode(e.name);
                    s.addChild(u);
                    return s;
                };
                e.prototype.combineCheckboxGroups = function(e) {
                    function v(e) {
                        var t;
                        var r = e.findChildrenByType(_.PropertyTreeNodeType.Group);
                        var n = e.findChildrenByType(_.PropertyTreeNodeType.Property);
                        for (var o = 0, i = r; o < i.length; o++) {
                            var a = i[o];
                            var u = null;
                            for (var s = 0, c = n; s < c.length; s++) {
                                var l = c[s];
                                var p = (t = l.property) === null || t === void 0 ? void 0 : t.getValueDefinition().getName();
                                if (p === "Checkbox" && l.name == a.name) {
                                    u = l;
                                    break;
                                }
                            }
                            if (!u) continue;
                            e.removeChild(u);
                            a.property = u.property;
                        }
                        for (var f = 0, d = e.children; f < d.length; f++) {
                            var h = d[f];
                            v(h);
                        }
                    }
                    v(e);
                };
                e.prototype.combineColorGroups = function(e) {
                    function u(e) {
                        for (var t = 0; t < e.children.length; t++) {
                            var r = e.children[t];
                            if (d(r)) {
                                var n = e.children[t + 1];
                                if (n == null) continue;
                                var o = "".concat(r.name, " Enabled");
                                var i = "".concat(r.name, " Opacity");
                                if (n.name === i || n.name === o) {
                                    var a = _.PropertyTreeNode.createColorGroupNode(r.name);
                                    e.children.splice(t, 2, a);
                                    a.addChild(r);
                                    a.addChild(n);
                                }
                            } else {
                                u(r);
                            }
                        }
                    }
                    u(e);
                };
                e.prototype.combineTextProperties = function(e) {
                    var c = [ "Auto Leading", "Leading", "Tracking", "Paragraph" ];
                    function l(e) {
                        var t = e.children.slice();
                        for (var r = 0, n = t; r < n.length; r++) {
                            var o = n[r];
                            if (o.property instanceof w.TextGroupProperty) {
                                for (var i = 0, a = c; i < a.length; i++) {
                                    var u = a[i];
                                    var s = e.findChildByName("Text Properties - ".concat(o.name, " - ").concat(u));
                                    if (s == null || s.property == null) continue;
                                    e.removeChild(s);
                                    o.addChild(s);
                                    o.property.addProperty(s.property);
                                    s.name = u;
                                }
                            } else {
                                l(o);
                            }
                        }
                    }
                    l(e);
                };
                e.prototype.addPaletteProperty = function(e, t, r) {
                    var n, o, i;
                    var a = (i = (n = r === null || r === void 0 ? void 0 : r.paletteGroupId) !== null && n !== void 0 ? n : ((o = t.meta) === null || o === void 0 ? void 0 : o.paletteGroupId)) !== null && i !== void 0 ? i : null;
                    if (a == null) return;
                    var u = l.PaletteProperty.create(this.events, this.palettes, e, a);
                    if (u == null) return;
                    var s = _.PropertyTreeNode.createPropertyNode(u);
                    function c(e) {
                        for (var t = 0; t < e.children.length; t++) {
                            var r = e.children[t];
                            if (d(r) || r.type === _.PropertyTreeNodeType.ColorGroup) {
                                e.insertChild(s, t);
                                return true;
                            }
                            if (r.children.length > 0) {
                                if (c(r)) return true;
                            }
                        }
                        return false;
                    }
                    c(e);
                };
                return e;
            }();
            t.ClipTreeBuilder = o;
            function d(e) {
                var t;
                return ((t = e.property) === null || t === void 0 ? void 0 : t.getValueDefinition().getName()) === "Color";
            }
            function q(e) {
                switch (e) {
                  case j.ControlType.Color:
                    return E.MogrtValueType.Color;

                  case j.ControlType.Point2D:
                  case j.ControlType.Point2DExt:
                    return E.MogrtValueType.Point2D;

                  case j.ControlType.Dropdown:
                    return E.MogrtValueType.Dropdown;

                  case j.ControlType.Media:
                    return E.MogrtValueType.Media;

                  default:
                    return E.MogrtValueType.Default;
                }
            }
            function M(e) {
                switch (e.type) {
                  case j.ControlType.Checkbox:
                  case j.ControlType.Slider:
                  case j.ControlType.Angle:
                  case j.ControlType.Dropdown:
                    return e["default"];

                  case j.ControlType.Point2D:
                  case j.ControlType.Point2DExt:
                    return [ e["default"].x, e["default"].y ];

                  case j.ControlType.Color:
                    return (0, n.hexStringToColor)(e["default"]);
                }
            }
            function A(e) {
                var t;
                var r = e.videoFrameRate.seconds;
                var n = 30;
                var o = false;
                if (e.videoDisplayFormat in i) {
                    t = i[e.videoDisplayFormat], n = t[0], o = t[1];
                }
                return {
                    frameDuration: r,
                    displayFrameRate: n,
                    dropFrame: o
                };
            }
            var i = {
                100: [ 24, false ],
                101: [ 25, false ],
                102: [ 29.97, true ],
                103: [ 29.97, false ],
                104: [ 30, false ],
                105: [ 50, false ],
                106: [ 59.94, true ],
                107: [ 59.94, false ],
                108: [ 60, false ],
                110: [ 23.976, false ],
                113: [ 48, false ]
            };
        },
        1186: function(e, t, r) {
            "use strict";
            var n = this && this.__extends || function() {
                var n = function(e, t) {
                    n = Object.setPrototypeOf || {
                        __proto__: []
                    } instanceof Array && function(e, t) {
                        e.__proto__ = t;
                    } || function(e, t) {
                        for (var r in t) if (Object.prototype.hasOwnProperty.call(t, r)) e[r] = t[r];
                    };
                    return n(e, t);
                };
                return function(e, t) {
                    if (typeof t !== "function" && t !== null) throw new TypeError("Class extends value " + String(t) + " is not a constructor or null");
                    n(e, t);
                    function r() {
                        this.constructor = e;
                    }
                    e.prototype = t === null ? Object.create(t) : (r.prototype = t.prototype, 
                    new r());
                };
            }();
            t.__esModule = true;
            t.Clip = void 0;
            var o = r(4339);
            var i = function(r) {
                n(e, r);
                function e(e) {
                    var t = r.call(this) || this;
                    t.clip = e;
                    return t;
                }
                e.prototype.getName = function() {
                    return this.clip.name;
                };
                e.prototype.getSourceIdentifier = function() {
                    var e = this.clip.projectItem.getMediaPath();
                    return a(e);
                };
                return e;
            }(o.CompositionItem);
            t.Clip = i;
            function a(e) {
                var t = u.exec(e);
                if (!t) return "";
                return t[1];
            }
            var u = /([^\/\\]+?)(?: \d+x\d+)?\.aegraphic$/;
        },
        2171: function(e, t, r) {
            "use strict";
            var n = r(9185);
            t.__esModule = true;
            t.ColorEditor = void 0;
            var i = r(1598);
            var a = r(5802);
            var o = function() {
                function e(e, t, r, n, o) {
                    this.currentProperties = i.emptyColorProperties;
                    this.events = e;
                    this.history = t;
                    this.sequence = r;
                    this.clips = n;
                    this.propertyTree = o;
                }
                e.prototype.initialize = function() {
                    return this.updateColorsSection().then(function() {});
                };
                e.prototype.update = function() {
                    var t = this;
                    return this.updateColorsSection().then(function(e) {
                        if (e) {
                            t.events.notifyPropertyTreeChanged();
                        }
                    });
                };
                e.prototype.updateColorsSection = function() {
                    var e = i.SelectionColorProperty.createForClips(this.events, this.history, this.sequence, this.clips);
                    if (u(this.currentProperties, e)) {
                        return n.resolve(false);
                    }
                    this.removeColorsSection();
                    this.currentProperties = e;
                    var t = this.addColorsSection(e.instances);
                    return t.initializePropertyValues().then(function() {
                        return true;
                    });
                };
                e.prototype.removeColorsSection = function() {
                    var e = this.propertyTree.findChildByName("Colors");
                    if (e) this.propertyTree.removeChild(e);
                };
                e.prototype.addColorsSection = function(e) {
                    var t = a.PropertyTreeNode.createSectionNode("Colors");
                    this.propertyTree.addChild(t);
                    for (var r = 0, n = e; r < n.length; r++) {
                        var o = n[r];
                        t.addChild(a.PropertyTreeNode.createPropertyNode(o));
                    }
                    return t;
                };
                return e;
            }();
            t.ColorEditor = o;
            function u(e, t) {
                if (e.size !== t.size) return false;
                for (var r in e.colors) {
                    if (!(r in t.colors)) return false;
                }
                return true;
            }
        },
        3066: function(e, t, r) {
            "use strict";
            var n = this && this.__assign || function() {
                n = Object.assign || function(e) {
                    for (var t, r = 1, n = arguments.length; r < n; r++) {
                        t = arguments[r];
                        for (var o in t) if (Object.prototype.hasOwnProperty.call(t, o)) e[o] = t[o];
                    }
                    return e;
                };
                return n.apply(this, arguments);
            };
            t.__esModule = true;
            t.ChangeTextValue = t.ChangeDurationValue = t.ChangeColorValue = t.ChangePlainValue = void 0;
            var o = r(3285);
            var i = r(7811);
            var a = function() {
                function e(e, t) {
                    this.previousValue = e;
                    this.nextValue = t;
                }
                e.prototype.apply = function(e) {
                    e.param.setValue(this.nextValue, true);
                };
                e.prototype.revert = function(e) {
                    e.param.setValue(this.previousValue, true);
                };
                e.prototype.merge = function(e) {
                    this.nextValue = e.nextValue;
                };
                return e;
            }();
            t.ChangePlainValue = a;
            var u = function() {
                function e(e, t) {
                    this.previousValue = e;
                    this.nextValue = t;
                }
                e.prototype.apply = function(e) {
                    this.setValue(e.param, this.nextValue);
                };
                e.prototype.revert = function(e) {
                    this.setValue(e.param, this.previousValue);
                };
                e.prototype.merge = function(e) {
                    this.nextValue = e.nextValue;
                };
                e.prototype.setValue = function(e, t) {
                    (0, i.setPropertyColorValue)(e, t);
                };
                return e;
            }();
            t.ChangeColorValue = u;
            var s = function() {
                function e(e, t, r) {
                    this.maxDuration = e;
                    this.previousValue = t;
                    this.nextValue = r;
                }
                e.prototype.apply = function(e) {
                    this.resizeClip(e.clip, e.param, this.nextValue);
                };
                e.prototype.revert = function(e) {
                    this.resizeClip(e.clip, e.param, this.previousValue);
                };
                e.prototype.merge = function(e) {
                    this.nextValue = e.nextValue;
                };
                e.prototype.resizeClip = function(e, t, r) {
                    var n = e.inPoint.seconds;
                    var o = this.maxDuration > 0 ? this.maxDuration - e.outPoint.seconds : 0;
                    var i = r + n + o;
                    t.setValue(i, true);
                    var a = new Time();
                    a.seconds = e.start.seconds + r;
                    e.end = a;
                };
                return e;
            }();
            t.ChangeDurationValue = s;
            var c = function() {
                function e(e, t) {
                    this.previousValue = e;
                    this.nextValue = t;
                }
                e.prototype.apply = function(e) {
                    this.setValue(e.param, this.nextValue);
                };
                e.prototype.revert = function(e) {
                    this.setValue(e.param, this.previousValue);
                };
                e.prototype.merge = function(e) {
                    this.previousValue = n(n({}, e.previousValue), this.previousValue);
                    this.nextValue = n(n({}, this.nextValue), e.nextValue);
                };
                e.prototype.setValue = function(e, t) {
                    var r = (0, o.parseTextValue)(e.getValue());
                    if (t.textContent != null) r = (0, o.setEditText)(r, t.textContent);
                    if (t.fontName != null) r = (0, o.setFontFamily)(r, t.fontName);
                    if (t.fontSize != null) r = (0, o.setFontSize)(r, t.fontSize);
                    if (t.fontBold != null) r = (0, o.setFontFauxBold)(r, t.fontBold);
                    if (t.fontItalic != null) r = (0, o.setFontFauxItalic)(r, t.fontItalic);
                    if (t.fontVariant != null) r = (0, o.setFontFauxVariant)(r, t.fontVariant);
                    e.setValue((0, o.serializeTextValue)(r), true);
                };
                return e;
            }();
            t.ChangeTextValue = c;
        },
        420: function(e, t, r) {
            "use strict";
            t.__esModule = true;
            t.CorruptedClipsFixer = void 0;
            var f = r(5132);
            var d = r(1413);
            var h = r(4530);
            var n = r(5452);
            var o = function() {
                function e(e, t, r) {
                    this.events = e;
                    this.externalObject = t;
                    this.undoStackManager = r;
                }
                e.prototype.detectCorruptedClips = function(e) {
                    var t = (0, n.getLimitedSelection)(e);
                    if (this.hasCorruptedClips(t)) {
                        this.events.notifyCorruptedClipsDetected();
                    }
                };
                e.prototype.hasCorruptedClips = function(e) {
                    for (var t = 0, r = e; t < r.length; t++) {
                        var n = r[t];
                        if ((0, f.isMHAdjustmentClip)(n) && !n.isAdjustmentLayer()) {
                            return true;
                        }
                    }
                    return false;
                };
                e.prototype.fixClips = function(e, t) {
                    var r = this;
                    var n = t.getSelection();
                    var o = [];
                    var i = [];
                    for (var a = 0; a < t.videoTracks.numTracks; a++) {
                        var u = t.videoTracks[a];
                        for (var s = 0; s < u.clips.numItems; s++) {
                            var c = {
                                type: d.ClipType.Video,
                                trackIndex: a,
                                clipIndex: s
                            };
                            var l = u.clips[s];
                            if ((0, f.isMHAdjustmentClip)(l)) {
                                i.push(c);
                                if (!l.isAdjustmentLayer()) {
                                    o.push(c);
                                }
                            }
                        }
                    }
                    var p = (0, h.getQESequence)(t);
                    p.makeCurrent();
                    this.undoStackManager.executeUndoGroup(e.documentID, function() {
                        (0, f.selectClips)(t, o);
                        r.externalObject.doCommand("cmd.clip.adjustmentlayer");
                        (0, f.scaleAdjustmentLayersToCanvas)(t, i);
                    });
                    t.setSelection(n);
                };
                return e;
            }();
            t.CorruptedClipsFixer = o;
        },
        6085: function(e, t, r) {
            "use strict";
            var n = r(8708);
            var o = this && this.__extends || function() {
                var n = function(e, t) {
                    n = Object.setPrototypeOf || {
                        __proto__: []
                    } instanceof Array && function(e, t) {
                        e.__proto__ = t;
                    } || function(e, t) {
                        for (var r in t) if (Object.prototype.hasOwnProperty.call(t, r)) e[r] = t[r];
                    };
                    return n(e, t);
                };
                return function(e, t) {
                    if (typeof t !== "function" && t !== null) throw new TypeError("Class extends value " + String(t) + " is not a constructor or null");
                    n(e, t);
                    function r() {
                        this.constructor = e;
                    }
                    e.prototype = t === null ? Object.create(t) : (r.prototype = t.prototype, 
                    new r());
                };
            }();
            t.__esModule = true;
            t.CEPEvents = void 0;
            var i = r(9932);
            var a = function(e) {
                o(t, e);
                function t() {
                    return e !== null && e.apply(this, arguments) || this;
                }
                t.prototype.notifyEditorReplaced = function() {
                    var e = new CSXSEvent();
                    e.type = "com.misterhorse.pc.Editor.CurrentInstanceReplaced";
                    e.dispatch();
                };
                t.prototype.notifyPropertyTreeChanged = function() {
                    var e = new CSXSEvent();
                    e.type = "com.misterhorse.pc.Editor.PropertyTreeChanged";
                    e.dispatch();
                };
                t.prototype.notifyPropertyValueChanged = function(e, t) {
                    var r = new CSXSEvent();
                    r.type = "com.misterhorse.pc.Editor.PropertyValueChanged";
                    r.data = n.stringify({
                        id: e,
                        value: t
                    });
                    r.dispatch();
                };
                t.prototype.notifyCorruptedClipsDetected = function() {
                    var e = new CSXSEvent();
                    e.type = "com.misterhorse.pc.Editor.CorruptedClipsDetected";
                    e.dispatch();
                };
                return t;
            }(i.Events);
            t.CEPEvents = a;
        },
        214: function(e, t, r) {
            "use strict";
            var n = r(9185);
            var o = this && this.__extends || function() {
                var n = function(e, t) {
                    n = Object.setPrototypeOf || {
                        __proto__: []
                    } instanceof Array && function(e, t) {
                        e.__proto__ = t;
                    } || function(e, t) {
                        for (var r in t) if (Object.prototype.hasOwnProperty.call(t, r)) e[r] = t[r];
                    };
                    return n(e, t);
                };
                return function(e, t) {
                    if (typeof t !== "function" && t !== null) throw new TypeError("Class extends value " + String(t) + " is not a constructor or null");
                    n(e, t);
                    function r() {
                        this.constructor = e;
                    }
                    e.prototype = t === null ? Object.create(t) : (r.prototype = t.prototype, 
                    new r());
                };
            }();
            t.__esModule = true;
            t.HistoryManager = t.UndoStackHistory = void 0;
            var a = r(9008);
            var i = r(4666);
            var u = r(4530);
            var s = r(6258);
            var c = r(3149);
            var l = r(5474);
            var p = function(r) {
                o(e, r);
                function e(e) {
                    var t = r.call(this) || this;
                    t.undoStack = [];
                    t.redoStack = [];
                    t.pendingEntry = null;
                    t.lastIndex = -1;
                    t.maxIndex = -1;
                    t.projectId = e;
                    t.maxIndex = t.lastIndex = t.getUndoStackIndex();
                    return t;
                }
                e.prototype.isEntryStarted = function() {
                    return this.pendingEntry != null;
                };
                e.prototype.startEntry = function() {
                    if (!this.isProjectOpen()) return;
                    var e = this.createUndoStackEntry();
                    this.maxIndex = this.lastIndex = e;
                    this.pendingEntry = {
                        changes: new s.ChangeSet(this.projectId),
                        undoStackIndex: e
                    };
                    this.undoStack.push(this.pendingEntry);
                };
                e.prototype.endEntry = function() {
                    this.pendingEntry = null;
                };
                e.prototype.executeTransaction = function(e) {
                    var t = this;
                    if (!this.isProjectOpen()) {
                        return n.resolve();
                    }
                    if (this.pendingEntry != null) {
                        return e();
                    }
                    this.startEntry();
                    var r;
                    try {
                        r = e();
                    } catch (e) {
                        this.endEntry();
                        throw e;
                    }
                    return r.then(function() {
                        return t.endEntry();
                    }, function(e) {
                        t.endEntry();
                        throw e;
                    });
                };
                e.prototype.changeParam = function(e, t, r, n) {
                    if (this.pendingEntry == null) {
                        throw new a.Exception("History entry has not been started");
                    }
                    if (app.projects.numProjects > 1 && (0, u.getSequenceById)(this.getProject(), e.sequenceID) == null) {
                        throw new a.Exception("Sequence ".concat(e.sequenceID, " does not belong to the history project ").concat(this.projectId));
                    }
                    var o = this.pendingEntry.changes;
                    var i = o.addChange(e.sequenceID, t.nodeId, r, n);
                    o.applyChange(i, e, t);
                };
                e.prototype.update = function() {
                    if (!this.isProjectOpen()) return;
                    if (this.pendingEntry != null) {
                        l.console.log("Skipping history replay: an entry is still pending");
                        return;
                    }
                    var e = this.getUndoStackIndex();
                    if (e > this.maxIndex) {
                        this.maxIndex = e;
                        this.redoStack = [];
                    } else if (e > this.lastIndex) {
                        for (var t = this.redoStack.length - 1; t >= 0; t--) {
                            var r = this.redoStack[t];
                            if (r.undoStackIndex > e) break;
                            this.undoStack.push(r);
                            this.redoStack.splice(t, 1);
                            r.changes.applyAll();
                        }
                    } else if (e < this.lastIndex) {
                        for (var t = this.undoStack.length - 1; t >= 0; t--) {
                            var r = this.undoStack[t];
                            if (r.undoStackIndex <= e) break;
                            this.redoStack.push(r);
                            this.undoStack.splice(t, 1);
                            r.changes.revertAll();
                        }
                    }
                    this.lastIndex = e;
                };
                e.prototype.createUndoStackEntry = function() {
                    var e = (0, i.getOrCreateACBin)(this.getProject());
                    e.renameBin(e.name);
                    return this.getUndoStackIndex();
                };
                e.prototype.getUndoStackIndex = function() {
                    var e = (0, i.getQEProject)(this.getProject(), true);
                    return e.undoStackIndex();
                };
                e.prototype.getProject = function() {
                    var e = (0, i.getProjectById)(this.projectId);
                    if (e == null) throw new a.Exception("History project does not exist");
                    return e;
                };
                e.prototype.isProjectOpen = function() {
                    return (0, i.getProjectById)(this.projectId) != null;
                };
                return e;
            }(c.History);
            t.UndoStackHistory = p;
            var f = function() {
                function e() {
                    this.histories = {};
                }
                e.prototype.getHistory = function(e) {
                    if (this.histories[e] == null) {
                        this.histories[e] = new p(e);
                    }
                    return this.histories[e];
                };
                e.prototype.clearHistory = function(e) {
                    delete this.histories[e];
                };
                return e;
            }();
            t.HistoryManager = f;
        },
        6061: function(e, t) {
            "use strict";
            t.__esModule = true;
            t.PlaybackManager = void 0;
            var r = function() {
                function e(e) {
                    this.externalObject = e;
                }
                e.prototype.togglePlay = function() {
                    var e = qe.project.getActiveSequence();
                    e.makeCurrent();
                    this.externalObject.doCommand("cmd.transport.toggleplay");
                };
                return e;
            }();
            t.PlaybackManager = r;
        },
        2936: function(e, t, r) {
            "use strict";
            var i = r(9185);
            var u = this && this.__extends || function() {
                var n = function(e, t) {
                    n = Object.setPrototypeOf || {
                        __proto__: []
                    } instanceof Array && function(e, t) {
                        e.__proto__ = t;
                    } || function(e, t) {
                        for (var r in t) if (Object.prototype.hasOwnProperty.call(t, r)) e[r] = t[r];
                    };
                    return n(e, t);
                };
                return function(e, t) {
                    if (typeof t !== "function" && t !== null) throw new TypeError("Class extends value " + String(t) + " is not a constructor or null");
                    n(e, t);
                    function r() {
                        this.constructor = e;
                    }
                    e.prototype = t === null ? Object.create(t) : (r.prototype = t.prototype, 
                    new r());
                };
            }();
            t.__esModule = true;
            t.TranscriptAggregateProperty = t.TranscriptValueDefinition = t.TranscriptProperty = void 0;
            var n = r(7638);
            var o = r(5938);
            var a = r(3285);
            var s = r(8234);
            var c = r(9860);
            var l = r(9388);
            var p = r(9008);
            var f = r(1413);
            var d = r(3066);
            var h = r(4155);
            var v = r(4530);
            var y = r(5132);
            var g = function(a) {
                u(e, a);
                function e(e, t, r, n, o) {
                    var i = a.call(this, e, "Transcript") || this;
                    i.history = t;
                    i.sequence = r;
                    i.clip = n;
                    i.options = o;
                    i.registerAction("getPlayheadPosition", i.getPlayheadPosition);
                    i.registerAction("setPlayheadPosition", i.setPlayheadPosition);
                    i.registerAction("splitTranscript", i.splitTranscript);
                    return i;
                }
                e.prototype.getTrackId = function() {
                    return this.clip.nodeId;
                };
                e.prototype.getHash = function() {
                    var e = this.getParam(this.options.hashParamIndex);
                    return P(e);
                };
                e.prototype.getValueItem = function() {
                    return {
                        hash: this.getHash(),
                        start: this.clip.start.seconds,
                        end: this.clip.end.seconds
                    };
                };
                e.prototype.getClipInfo = function() {
                    return {
                        id: this.clip.nodeId,
                        startTime: this.clip.start.seconds,
                        endTime: this.clip.end.seconds,
                        inPoint: this.clip.inPoint.seconds,
                        frameDuration: this.getFrameDuration().seconds,
                        editorChunks: this.options.editorParamIndices.length,
                        captionChunks: this.options.captionParamIndices.length
                    };
                };
                e.prototype.getClipData = function() {
                    var e = this.options.editorParamIndices;
                    var t = [];
                    for (var r = 0; r < e.length; r++) {
                        var n = this.getParam(e[r]);
                        t[r] = n.getValue();
                    }
                    return {
                        hash: this.getHash(),
                        editorChunks: t,
                        captionChunks: []
                    };
                };
                e.prototype.updateClipData = function(e) {
                    var t, r;
                    this.clip.disabled = true;
                    var n = this.options, o = n.hashParamIndex, i = n.editorParamIndices, a = n.captionParamIndices;
                    this.setTextParamValue(o, e.hash);
                    for (var u = 0; u < i.length; u++) {
                        this.setRawParamValue(i[u], (t = e.editorChunks[u]) !== null && t !== void 0 ? t : "");
                    }
                    for (var u = 0; u < a.length; u++) {
                        this.setRawParamValue(a[u], (r = e.captionChunks[u]) !== null && r !== void 0 ? r : "");
                    }
                    this.clip.disabled = false;
                };
                e.prototype.getParam = function(e) {
                    var t = this.clip.getMGTComponent();
                    return t.properties[e];
                };
                e.prototype.setTextParamValue = function(e, t) {
                    var r = this.getParam(e);
                    var n = P(r);
                    var o = new d.ChangeTextValue({
                        textContent: n
                    }, {
                        textContent: t
                    });
                    this.history.changeParam(this.sequence, this.clip, e, o);
                };
                e.prototype.setRawParamValue = function(e, t) {
                    var r = this.getParam(e);
                    var n = new d.ChangePlainValue(r.getValue(), t);
                    this.history.changeParam(this.sequence, this.clip, e, n);
                };
                e.prototype.fetchValueFromSource = function() {
                    var r = this;
                    return new i(function(e) {
                        var t = [ r.getValueItem() ];
                        e(t);
                    });
                };
                e.prototype.getValueDefinition = function() {
                    return new m(this.options.displayFrameRate, this.options.dropFrame);
                };
                e.prototype.updateValueInSource = function(e, t) {
                    return i.reject(new p.Exception("Transcript value cannot be updated directly"));
                };
                e.prototype.getPlayheadPosition = function() {
                    var e = this.sequence.getPlayerPosition();
                    if (!this.isTimeInClipRange(e)) {
                        return i.resolve(null);
                    }
                    return i.resolve(e.seconds);
                };
                e.prototype.setPlayheadPosition = function(e) {
                    var t = (0, s.createTimeValue)(e.time);
                    if (!this.isTimeInClipRange(t)) {
                        throw new p.Exception("Playhead time is outside clip range");
                    }
                    this.sequence.setPlayerPosition(t.ticks);
                    return this.getPlayheadPosition();
                };
                e.prototype.splitTranscript = function(e) {
                    var t = this;
                    var r = (0, s.createTimeValue)(e.time);
                    return new i(function(e) {
                        t.splitClipAtTime(r);
                        e();
                    });
                };
                e.prototype.splitClipAtTime = function(e) {
                    if (!this.isTimeInClipRange(e)) {
                        throw new p.Exception("Time is outside clip range");
                    }
                    var t = (0, f.getClipLocation)(this.clip, this.sequence);
                    var r = (0, v.getSequenceFrameRate)(this.sequence);
                    var n = (0, s.roundToNextFrame)(e, r);
                    var o = (0, f.getSelectedClips)(this.sequence, f.ClipType.Video);
                    (0, h.razorSequenceTrack)(this.sequence, f.ClipType.Video, t.trackIndex, n);
                    var i = (0, f.splitClipLocation)(o, t);
                    (0, y.selectClips)(this.sequence, i);
                };
                e.prototype.getFrameDuration = function() {
                    return (0, s.timeFromTicks)(this.sequence.timebase);
                };
                e.prototype.isTimeInClipRange = function(e) {
                    var t = this.clip.start;
                    var r = this.clip.end;
                    return e.seconds >= t.seconds && e.seconds <= r.seconds;
                };
                return e;
            }(n.Property);
            t.TranscriptProperty = g;
            var m = function(n) {
                u(t, n);
                function t(e, t) {
                    var r = n.call(this) || this;
                    r.frameRate = e;
                    r.dropFrame = t;
                    return r;
                }
                t.prototype.getName = function() {
                    return "Transcript";
                };
                t.prototype.mergeWith = function(e) {
                    if (e instanceof t && e.frameRate === this.frameRate && e.dropFrame === this.dropFrame) {
                        return this;
                    }
                    return null;
                };
                t.prototype.isValueEqual = function(e, t) {
                    var r = e;
                    var n = t;
                    if (r.length !== n.length) return false;
                    for (var o = 0; o < r.length; o++) {
                        if (r[o].start !== n[o].start || r[o].end !== n[o].end || r[o].hash !== n[o].hash) {
                            return false;
                        }
                    }
                    return true;
                };
                t.prototype.serialize = function() {
                    return {
                        frameRate: this.frameRate,
                        dropFrame: this.dropFrame
                    };
                };
                return t;
            }(o.ValueDefinition);
            t.TranscriptValueDefinition = m;
            function P(e) {
                var t = (0, a.parseTextValue)(e.getValue());
                return (0, a.getEditText)(t);
            }
            var C = function(o) {
                u(e, o);
                function e(e, t, r) {
                    var n = o.call(this, e, "Transcript") || this;
                    n.history = t;
                    n.sequence = r;
                    n.registerAction("getPlayheadPosition", n.getPlayheadPosition);
                    n.registerAction("setPlayheadPosition", n.setPlayheadPosition);
                    n.registerAction("splitTranscript", n.splitTranscript);
                    return n;
                }
                e.prototype.fetchValueFromSource = function() {
                    var n = this;
                    return new i(function(e) {
                        var t = n.getTranscriptProperties();
                        var r = (0, l.map)(t, function(e) {
                            return e.getValueItem();
                        });
                        e(r);
                    });
                };
                e.prototype.getClipInfo = function() {
                    var e = {};
                    for (var t = 0, r = this.getTranscriptProperties(); t < r.length; t++) {
                        var n = r[t];
                        e[n.getTrackId()] = n.getClipInfo();
                    }
                    return e;
                };
                e.prototype.getClipData = function() {
                    var e = {};
                    for (var t = 0, r = this.getTranscriptProperties(); t < r.length; t++) {
                        var n = r[t];
                        e[n.getTrackId()] = n.getClipData();
                    }
                    return e;
                };
                e.prototype.updateClipData = function(e) {
                    for (var t = 0, r = this.getTranscriptProperties(); t < r.length; t++) {
                        var n = r[t];
                        var o = n.getTrackId();
                        if (e[o] == null) {
                            throw new p.Exception("Missing data for track ".concat(o));
                        }
                        n.updateClipData(e[o]);
                    }
                };
                e.prototype.getPlayheadPosition = function() {
                    var e = this.getTranscriptProperties();
                    var t = (0, l.map)(e, function(e) {
                        return e.getPlayheadPosition();
                    });
                    return i.all(t).then(function(e) {
                        var t;
                        return (t = (0, l.find)(e, function(e) {
                            return e != null;
                        })) !== null && t !== void 0 ? t : null;
                    });
                };
                e.prototype.setPlayheadPosition = function(e) {
                    var t = (0, s.createTimeValue)(e.time);
                    this.sequence.setPlayerPosition(t.ticks);
                    return this.getPlayheadPosition();
                };
                e.prototype.splitTranscript = function(e) {
                    var t = this.getTranscriptProperties();
                    for (var r = 0, n = t; r < n.length; r++) {
                        var o = n[r];
                        if (o.getTrackId() === e.trackId) {
                            return o.splitTranscript(e);
                        }
                    }
                    throw new p.Exception("Transcript track not found");
                };
                e.prototype.getTranscriptProperties = function() {
                    return (0, l.filter)(this.getAggregatedProperties(), function(e) {
                        return e instanceof g;
                    });
                };
                return e;
            }(c.AggregateProperty);
            t.TranscriptAggregateProperty = C;
        },
        8852: function(e, t, r) {
            "use strict";
            var n = r(9185);
            var o = this && this.__extends || function() {
                var n = function(e, t) {
                    n = Object.setPrototypeOf || {
                        __proto__: []
                    } instanceof Array && function(e, t) {
                        e.__proto__ = t;
                    } || function(e, t) {
                        for (var r in t) if (Object.prototype.hasOwnProperty.call(t, r)) e[r] = t[r];
                    };
                    return n(e, t);
                };
                return function(e, t) {
                    if (typeof t !== "function" && t !== null) throw new TypeError("Class extends value " + String(t) + " is not a constructor or null");
                    n(e, t);
                    function r() {
                        this.constructor = e;
                    }
                    e.prototype = t === null ? Object.create(t) : (r.prototype = t.prototype, 
                    new r());
                };
            }();
            t.__esModule = true;
            t.DurationProperty = void 0;
            var i = r(9008);
            var a = r(7638);
            var s = r(3066);
            var c = r(5938);
            var l = r(4425);
            var p = r(1413);
            var u = function(u) {
                o(e, u);
                function e(e, t, r, n, o, i) {
                    var a = u.call(this, e, "Duration") || this;
                    a.history = t;
                    a.sequence = r;
                    a.clip = n;
                    a.paramIndex = o;
                    a.spec = i;
                    a.registerAction("alignToPlayhead", a.alignToPlayhead);
                    return a;
                }
                e.prototype.shouldIncludeInPreset = function() {
                    return false;
                };
                e.prototype.isResetSupported = function() {
                    return true;
                };
                e.prototype.getValueDefinition = function() {
                    return new c.TimeValueDefinition(1 / this.spec.displayFrameRate, this.spec.dropFrame, 0, this.spec.maxDuration);
                };
                e.prototype.fetchValueFromSource = function() {
                    return n.resolve(this.clip.duration.seconds);
                };
                e.prototype.updateValueInSource = function(e, t) {
                    if (typeof e !== "number") return n.resolve();
                    if (t) {
                        e += this.clip.duration.seconds;
                    }
                    this.resizeClip(e);
                    return n.resolve();
                };
                e.prototype.resetValueInSource = function() {
                    this.resizeClip(this.spec.defaultDuration);
                    return n.resolve();
                };
                e.prototype.alignToPlayhead = function() {
                    var e = this;
                    var t = this.sequence.getPlayerPosition();
                    if (t.seconds <= this.clip.start.seconds) return n.resolve();
                    var r = t.seconds - this.clip.start.seconds;
                    return this.history.executeTransaction(function() {
                        e.resizeClip(r);
                        return n.resolve();
                    });
                };
                e.prototype.resizeClip = function(e) {
                    if (e <= 0) {
                        e = this.spec.frameDuration;
                    }
                    var t = this.getDurationLimit();
                    if (t >= 0 && e > t) {
                        e = t;
                    }
                    var r = this.clip.duration.seconds;
                    if (e === r) return;
                    var n = new s.ChangeDurationValue(this.spec.maxDuration, r, e);
                    this.history.changeParam(this.sequence, this.clip, this.paramIndex, n);
                };
                e.prototype.getDurationLimit = function() {
                    var e = this.getClipLocation();
                    var t = this.sequence.videoTracks[e.trackIndex];
                    if (t.clips.numItems === e.clipIndex + 1) {
                        return -1;
                    }
                    return t.clips[e.clipIndex + 1].start.seconds - this.clip.start.seconds;
                };
                e.prototype.getClipLocation = function() {
                    var e;
                    if (this.clipLocation != null) {
                        try {
                            var t = (0, p.getClip)(this.sequence, this.clipLocation);
                            if (t !== this.clip) this.clipLocation = undefined;
                        } catch (e) {
                            this.clipLocation = undefined;
                        }
                    }
                    (e = this.clipLocation) !== null && e !== void 0 ? e : this.clipLocation = (0, 
                    p.getClipLocation)(this.clip, this.sequence);
                    if (this.clipLocation.type !== l.ClipType.Video) {
                        throw new i.Exception("Invalid clip type for duration property");
                    }
                    return this.clipLocation;
                };
                return e;
            }(a.Property);
            t.DurationProperty = u;
        },
        2971: function(e, t, r) {
            "use strict";
            var o = r(9185);
            var n = this && this.__extends || function() {
                var n = function(e, t) {
                    n = Object.setPrototypeOf || {
                        __proto__: []
                    } instanceof Array && function(e, t) {
                        e.__proto__ = t;
                    } || function(e, t) {
                        for (var r in t) if (Object.prototype.hasOwnProperty.call(t, r)) e[r] = t[r];
                    };
                    return n(e, t);
                };
                return function(e, t) {
                    if (typeof t !== "function" && t !== null) throw new TypeError("Class extends value " + String(t) + " is not a constructor or null");
                    n(e, t);
                    function r() {
                        this.constructor = e;
                    }
                    e.prototype = t === null ? Object.create(t) : (r.prototype = t.prototype, 
                    new r());
                };
            }();
            t.__esModule = true;
            t.MogrtValueType = t.MogrtProperty = void 0;
            var u = r(9008);
            var i = r(7638);
            var a = r(7811);
            var s = r(3066);
            var c = function(c) {
                n(e, c);
                function e(e, t, r, n, o, i, a, u) {
                    var s = c.call(this, e, t) || this;
                    s.history = r;
                    s.sequence = n;
                    s.clip = o;
                    s.paramIndex = i;
                    s.definition = a;
                    s.spec = u;
                    return s;
                }
                e.prototype.isResetSupported = function() {
                    return this.spec.defaultValue != null;
                };
                e.prototype.shouldIncludeInPreset = function() {
                    return this.spec.includeInPreset;
                };
                e.prototype.fetchValueFromSource = function() {
                    if (this.spec.valueType == l.Color) {
                        return this.getColorValue();
                    } else if (this.spec.valueType == l.Point2D) {
                        return this.getPoint2DValue();
                    } else if (this.spec.valueType == l.Dropdown) {
                        return this.getDropdownValue();
                    } else if (this.spec.valueType == l.Media) {
                        return this.getMediaValue();
                    } else {
                        return this.getPlainValue();
                    }
                };
                e.prototype.updateValueInSource = function(e, t) {
                    if (!this.definition.isValueValid(e)) {
                        return o.reject(new Error("Invalid value"));
                    }
                    if (this.spec.valueType == l.Color) {
                        return this.setColorValue(e, t);
                    } else if (this.spec.valueType == l.Point2D) {
                        return this.setPoint2DValue(e, t);
                    } else if (this.spec.valueType == l.Dropdown) {
                        return this.setDropdownValue(e, t);
                    } else {
                        return this.setPlainValue(e, t);
                    }
                };
                e.prototype.resetValueInSource = function() {
                    var e = this.spec.defaultValue;
                    if (e == null) return o.resolve();
                    if (this.spec.valueType == l.Color) {
                        return this.setColorValue(e, false);
                    } else if (this.spec.valueType == l.Point2D) {
                        return this.setPoint2DValue(e, false);
                    } else {
                        return this.setPlainValue(e, false);
                    }
                };
                e.prototype.getPlainValue = function() {
                    var e = this.getParam().getValue();
                    return o.resolve(e);
                };
                e.prototype.setPlainValue = function(r, e) {
                    var n = this;
                    if (e) {
                        r += this.getParam().getValue();
                    }
                    return this.getPlainValue().then(function(e) {
                        var t = new s.ChangePlainValue(e, r);
                        n.changeParam(t);
                    });
                };
                e.prototype.getColorValue = function() {
                    var e = (0, a.getPropertyColorValue)(this.getParam());
                    if (e == null) return o.reject(new Error("Invalid color value"));
                    return o.resolve(e);
                };
                e.prototype.setColorValue = function(n, o) {
                    var i = this;
                    return this.getColorValue().then(function(e) {
                        var t = p(e, n, o);
                        var r = new s.ChangeColorValue(e, t);
                        i.changeParam(r);
                    });
                };
                e.prototype.getPoint2DValue = function() {
                    var e = this.getParam().getValue(), t = e[0], r = e[1];
                    var n = [ t * this.spec.graphicWidth, r * this.spec.graphicHeight ];
                    return o.resolve(n);
                };
                e.prototype.setPoint2DValue = function(n, o) {
                    var i = this;
                    return this.getPoint2DValue().then(function(e) {
                        var t = p(e, n, o);
                        var r = new s.ChangePlainValue(i.convertPointToParamValue(e), i.convertPointToParamValue(t));
                        i.changeParam(r);
                    });
                };
                e.prototype.getDropdownValue = function() {
                    var e = this.getParam().getValue() + 1;
                    return o.resolve(e);
                };
                e.prototype.setDropdownValue = function(r, e) {
                    var n = this;
                    if (e) {
                        return o.reject(new Error("Relative value is not supported for dropdown property"));
                    }
                    return this.getDropdownValue().then(function(e) {
                        var t = new s.ChangePlainValue(e - 1, r - 1);
                        n.changeParam(t);
                    });
                };
                e.prototype.getMediaValue = function() {
                    return o.resolve({
                        id: 0,
                        name: ""
                    });
                };
                e.prototype.getValueDefinition = function() {
                    return this.definition;
                };
                e.prototype.getParam = function() {
                    return this.clip.getMGTComponent().properties[this.paramIndex];
                };
                e.prototype.changeParam = function(e) {
                    this.history.changeParam(this.sequence, this.clip, this.paramIndex, e);
                };
                e.prototype.convertPointToParamValue = function(e) {
                    var t = e[0], r = e[1];
                    return [ t / this.spec.graphicWidth, r / this.spec.graphicHeight ];
                };
                return e;
            }(i.Property);
            t.MogrtProperty = c;
            var l;
            (function(e) {
                e[e["Default"] = 0] = "Default";
                e[e["Color"] = 1] = "Color";
                e[e["Point2D"] = 2] = "Point2D";
                e[e["Dropdown"] = 3] = "Dropdown";
                e[e["Media"] = 4] = "Media";
            })(l || (t.MogrtValueType = l = {}));
            function p(e, t, r) {
                if (e.length !== t.length) {
                    throw new u.Exception("Array sizes do not match");
                }
                var n = e.slice();
                for (var o = 0; o < t.length; o++) {
                    var i = e[o];
                    var a = t[o];
                    if (a == null) continue;
                    if (r) {
                        n[o] = i + a;
                    } else {
                        n[o] = a;
                    }
                }
                return n;
            }
        },
        1598: function(e, t, r) {
            "use strict";
            var n = r(9185);
            var o = this && this.__extends || function() {
                var n = function(e, t) {
                    n = Object.setPrototypeOf || {
                        __proto__: []
                    } instanceof Array && function(e, t) {
                        e.__proto__ = t;
                    } || function(e, t) {
                        for (var r in t) if (Object.prototype.hasOwnProperty.call(t, r)) e[r] = t[r];
                    };
                    return n(e, t);
                };
                return function(e, t) {
                    if (typeof t !== "function" && t !== null) throw new TypeError("Class extends value " + String(t) + " is not a constructor or null");
                    n(e, t);
                    function r() {
                        this.constructor = e;
                    }
                    e.prototype = t === null ? Object.create(t) : (r.prototype = t.prototype, 
                    new r());
                };
            }();
            t.__esModule = true;
            t.SelectionColorProperty = t.emptyColorProperties = void 0;
            var i = r(7638);
            var p = r(2037);
            var f = r(7811);
            var d = r(3066);
            var u = r(5938);
            t.emptyColorProperties = {
                size: 0,
                colors: {},
                instances: []
            };
            var a = function(a) {
                o(c, a);
                function c(e, t, r, n, o) {
                    var i = a.call(this, e, (0, p.colorToHexString)(t)) || this;
                    i.color = t;
                    i.history = r;
                    i.sequence = n;
                    i.clips = o;
                    i.valueDefinition = new u.ColorValueDefinition();
                    return i;
                }
                c.createForClips = function(e, t, r, n) {
                    var o = l(n);
                    var i = [];
                    var a = 0;
                    for (var u in o) {
                        var s = o[u];
                        i.push(new c(e, s, t, r, n));
                        a++;
                    }
                    return {
                        size: a,
                        colors: o,
                        instances: i
                    };
                };
                c.prototype.shouldIncludeInPreset = function() {
                    return false;
                };
                c.prototype.fetchValueFromSource = function() {
                    return n.resolve(this.color);
                };
                c.prototype.getValueDefinition = function() {
                    return this.valueDefinition;
                };
                c.prototype.updateValueInSource = function(e, t) {
                    if (t) return n.reject(new Error("Relative updates not supported"));
                    if (!this.valueDefinition.isValueValid(e)) {
                        return n.reject(new Error("Invalid value"));
                    }
                    var r = e;
                    this.updateColor(this.clips, this.color, r);
                    return n.resolve();
                };
                c.prototype.wantsRevealEditTab = function() {
                    return false;
                };
                c.prototype.updateColor = function(e, t, r) {
                    for (var n = 0, o = e; n < o.length; n++) {
                        var i = o[n];
                        var a = i.getMGTComponent();
                        if (!a) continue;
                        for (var u = 0; u < a.properties.length; u++) {
                            var s = a.properties[u];
                            var c = void 0;
                            try {
                                c = (0, f.getPropertyColorValue)(s);
                            } catch (e) {
                                continue;
                            }
                            if (c == null || !(0, p.isColorValueEqual)(c, t)) continue;
                            var l = new d.ChangeColorValue(c, r);
                            this.history.changeParam(this.sequence, i, u, l);
                        }
                    }
                };
                return c;
            }(i.Property);
            t.SelectionColorProperty = a;
            function l(e) {
                var t = {};
                for (var r = 0, n = e; r < n.length; r++) {
                    var o = n[r];
                    var i = o.getMGTComponent();
                    if (!i) continue;
                    for (var a = 0; a < i.properties.length; a++) {
                        var u = i.properties[a];
                        var s = void 0;
                        try {
                            s = (0, f.getPropertyColorValue)(u);
                        } catch (e) {
                            continue;
                        }
                        if (s == null) continue;
                        var c = (0, p.colorToHexString)(s);
                        t[c] = s;
                    }
                }
                return t;
            }
        },
        5645: function(e, t, r) {
            "use strict";
            var i = r(9185);
            var n = this && this.__extends || function() {
                var n = function(e, t) {
                    n = Object.setPrototypeOf || {
                        __proto__: []
                    } instanceof Array && function(e, t) {
                        e.__proto__ = t;
                    } || function(e, t) {
                        for (var r in t) if (Object.prototype.hasOwnProperty.call(t, r)) e[r] = t[r];
                    };
                    return n(e, t);
                };
                return function(e, t) {
                    if (typeof t !== "function" && t !== null) throw new TypeError("Class extends value " + String(t) + " is not a constructor or null");
                    n(e, t);
                    function r() {
                        this.constructor = e;
                    }
                    e.prototype = t === null ? Object.create(t) : (r.prototype = t.prototype, 
                    new r());
                };
            }();
            t.__esModule = true;
            t.FontVariantProperty = t.FontItalicProperty = t.FontBoldProperty = t.FontFamilyProperty = t.FontSizeProperty = t.TextValueDefinition = t.TextProperty = t.TextGroupProperty = void 0;
            var a = r(9008);
            var o = r(7638);
            var u = r(3285);
            var s = r(3066);
            var c = r(5938);
            var l = r(9388);
            var p = function(o) {
                n(e, o);
                function e(e, t, r) {
                    var n = o.call(this, e, t) || this;
                    n.properties = r;
                    return n;
                }
                e.prototype.getValueDefinition = function() {
                    return new c.NoValueDefinition();
                };
                e.prototype.isResetSupported = function() {
                    return true;
                };
                e.prototype.shouldIncludeInPreset = function() {
                    return false;
                };
                e.prototype.fetchValueFromSource = function() {
                    return i.resolve(undefined);
                };
                e.prototype.updateValueInSource = function(e, t) {
                    return i.resolve();
                };
                e.prototype.resetValueInSource = function() {
                    var e = (0, l.map)(this.properties, function(e) {
                        return e.resetValueInSource();
                    });
                    return i.all(e).then(function() {});
                };
                e.prototype.addProperty = function(e) {
                    this.properties.push(e);
                };
                return e;
            }(o.Property);
            t.TextGroupProperty = p;
            var f = function(o) {
                n(e, o);
                function e(e, t, r) {
                    var n = o.call(this, e, t) || this;
                    n.options = r;
                    return n;
                }
                e.prototype.fetchValueFromSource = function() {
                    var e = this.getParam().getValue();
                    var t = (0, u.parseTextValue)(e);
                    var r = this.getValueFromText(t);
                    return i.resolve(r);
                };
                e.prototype.updateValueInSource = function(e, t) {
                    var r = this.getParam().getValue();
                    var n = (0, u.parseTextValue)(r);
                    var o = this.setValueToText(n, e, t);
                    this.changeParam(o);
                    return i.resolve();
                };
                e.prototype.isResetSupported = function() {
                    return this.options.defaultValue != null;
                };
                e.prototype.resetValueInSource = function() {
                    var e = this.options.defaultValue;
                    if (e == null) {
                        return i.reject(new Error("Default text value not set"));
                    }
                    try {
                        var t = this.getValueFromText(e);
                        var r = this.setValueToText(e, t, false);
                        this.changeParam(r);
                    } catch (e) {
                        return i.reject(e);
                    }
                    return i.resolve();
                };
                e.prototype.getParam = function() {
                    var e = this.options, t = e.clip, r = e.paramIndex;
                    return t.getMGTComponent().properties[r];
                };
                e.prototype.changeParam = function(e) {
                    var t = this.options, r = t.history, n = t.sequence, o = t.clip, i = t.paramIndex;
                    r.changeParam(n, o, i, e);
                };
                return e;
            }(o.Property);
            var d = function(i) {
                n(e, i);
                function e(e, t, r, n) {
                    var o = i.call(this, e, t, r) || this;
                    o.fontPropertyId = n;
                    return o;
                }
                e.prototype.getValueDefinition = function() {
                    return new h();
                };
                e.prototype.getValueFromText = function(e) {
                    return (0, u.getEditText)(e);
                };
                e.prototype.setValueToText = function(e, t, r) {
                    if (typeof t !== "string") throw new a.Exception("Invalid text value");
                    if (r) throw new a.Exception("Relative value is not supported for text property");
                    var n = (0, u.getEditText)(e);
                    return new s.ChangeTextValue({
                        textContent: n
                    }, {
                        textContent: t
                    });
                };
                e.prototype.getAttributes = function() {
                    return {
                        fontPropertyId: this.fontPropertyId
                    };
                };
                return e;
            }(f);
            t.TextProperty = d;
            var h = function(e) {
                n(t, e);
                function t() {
                    return e !== null && e.apply(this, arguments) || this;
                }
                t.prototype.getName = function() {
                    return "Text";
                };
                t.prototype.isValueValid = function(e) {
                    return typeof e === "string";
                };
                return t;
            }(c.ValueDefinition);
            t.TextValueDefinition = h;
            var v = function(e) {
                n(t, e);
                function t() {
                    return e !== null && e.apply(this, arguments) || this;
                }
                t.prototype.getValueDefinition = function() {
                    return new c.SliderValueDefinition(0, 1e3, false);
                };
                t.prototype.getValueFromText = function(e) {
                    return (0, u.getFontSize)(e);
                };
                t.prototype.setValueToText = function(e, t, r) {
                    if (typeof t !== "number") throw new a.Exception("Invalid font size value");
                    var n = (0, u.getFontSize)(e);
                    if (r) t += n;
                    return new s.ChangeTextValue({
                        fontSize: n
                    }, {
                        fontSize: t
                    });
                };
                return t;
            }(f);
            t.FontSizeProperty = v;
            var y = function(i) {
                n(e, i);
                function e(e, t, r, n) {
                    var o = i.call(this, e, t, r) || this;
                    o.fontGroupId = n;
                    return o;
                }
                e.prototype.getValueDefinition = function() {
                    return new g();
                };
                e.prototype.getAttributes = function() {
                    return {
                        fontGroupId: this.fontGroupId
                    };
                };
                e.prototype.getValueFromText = function(e) {
                    return (0, u.getFontFamily)(e);
                };
                e.prototype.setValueToText = function(e, t, r) {
                    if (typeof t !== "string") throw new a.Exception("Invalid font size value");
                    if (r) throw new a.Exception("Relative value is not supported for font family property");
                    var n = (0, u.getFontFamily)(e);
                    return new s.ChangeTextValue({
                        fontName: n
                    }, {
                        fontName: t
                    });
                };
                return e;
            }(f);
            t.FontFamilyProperty = y;
            var g = function(e) {
                n(t, e);
                function t() {
                    return e !== null && e.apply(this, arguments) || this;
                }
                t.prototype.getName = function() {
                    return "Font";
                };
                t.prototype.isValueValid = function(e) {
                    return typeof e === "string";
                };
                return t;
            }(c.ValueDefinition);
            var m = function(e) {
                n(t, e);
                function t() {
                    return e !== null && e.apply(this, arguments) || this;
                }
                t.prototype.getValueDefinition = function() {
                    return new c.CheckboxValueDefinition();
                };
                t.prototype.getValueFromText = function(e) {
                    return (0, u.isFontFauxBold)(e);
                };
                t.prototype.setValueToText = function(e, t, r) {
                    if (typeof t !== "boolean") throw new a.Exception("Invalid font bold value");
                    if (r) throw new a.Exception("Relative value is not supported for font bold property");
                    var n = (0, u.isFontFauxBold)(e);
                    return new s.ChangeTextValue({
                        fontBold: n
                    }, {
                        fontBold: t
                    });
                };
                return t;
            }(f);
            t.FontBoldProperty = m;
            var P = function(e) {
                n(t, e);
                function t() {
                    return e !== null && e.apply(this, arguments) || this;
                }
                t.prototype.getValueDefinition = function() {
                    return new c.CheckboxValueDefinition();
                };
                t.prototype.getValueFromText = function(e) {
                    return (0, u.isFontFauxItalic)(e);
                };
                t.prototype.setValueToText = function(e, t, r) {
                    if (typeof t !== "boolean") throw new a.Exception("Invalid font italic value");
                    if (r) throw new a.Exception("Relative value is not supported for font italic property");
                    var n = (0, u.isFontFauxItalic)(e);
                    return new s.ChangeTextValue({
                        fontItalic: n
                    }, {
                        fontItalic: t
                    });
                };
                return t;
            }(f);
            t.FontItalicProperty = P;
            var C = [ u.FontVariant.normal, u.FontVariant.allCaps, u.FontVariant.smallCaps ];
            var T = function(o) {
                n(e, o);
                function e(e, t, r) {
                    var n = o.call(this, e, t, r) || this;
                    n.definition = new c.DropdownValueDefinition(C);
                    return n;
                }
                e.prototype.getValueDefinition = function() {
                    return this.definition;
                };
                e.prototype.getValueFromText = function(e) {
                    var t = (0, u.getFontFauxVariant)(e);
                    for (var r = 0; r < C.length; r++) {
                        if (t === C[r]) {
                            return r + 1;
                        }
                    }
                    throw new a.Exception("Font variant value is not in options");
                };
                e.prototype.setValueToText = function(e, t, r) {
                    if (!this.definition.isValueValid(t)) throw new a.Exception("Invalid font variant value");
                    if (r) throw new a.Exception("Relative value is not supported for font variant property");
                    var n = (0, u.getFontFauxVariant)(e);
                    var o = t - 1;
                    var i = C[o];
                    return new s.ChangeTextValue({
                        fontVariant: n
                    }, {
                        fontVariant: i
                    });
                };
                return e;
            }(f);
            t.FontVariantProperty = T;
        },
        6408: function(e, t, r) {
            "use strict";
            var d = r(9185);
            t.__esModule = true;
            t.SequenceSelectionEditor = void 0;
            var h = r(9008);
            var f = r(5802);
            var c = r(5526);
            var n = r(1115);
            var v = r(7521);
            var y = r(2171);
            var i = r(924);
            var a = r(8711);
            var o = r(1186);
            var l = r(9860);
            var u = r(9388);
            var s = function() {
                function e(e, t, r, n, o) {
                    this.projectId = "";
                    this.sequenceId = 0;
                    this.itemNodeIds = [];
                    this.editors = null;
                    this.clipTreeBuilder = new a.ClipTreeBuilder(e, t, r, o);
                    this.events = t;
                    this.presets = n;
                    this.history = o;
                }
                e.prototype.initialize = function(e, t) {
                    var r = this;
                    this.projectId = e.documentID;
                    this.sequenceId = t.id;
                    var n = t.getSelection();
                    var o = this.getEditableClips(t, n);
                    this.itemNodeIds = [];
                    for (var i = 0, a = n; i < a.length; i++) {
                        var u = a[i];
                        this.itemNodeIds.push(u.nodeId);
                    }
                    if (o.length > g) {
                        this.editors = {
                            valid: false,
                            error: new h.UserError("Too many clips selected. Select ".concat(g, " or less."))
                        };
                        return d.resolve();
                    }
                    var s = this.buildSingleEditor(o);
                    var c = this.buildPropertyTree(t, o, s);
                    var l = this.buildEditorState(t, n, o, c);
                    var p = new v.SelectionEditor(l, c, s);
                    var f = new y.ColorEditor(this.events, this.history, t, o, c);
                    return p.initialize().then(function() {
                        return f.initialize();
                    }).then(function() {
                        r.editors = {
                            valid: true,
                            selectionEditor: p,
                            colorEditor: f
                        };
                    });
                };
                e.prototype.getHistory = function() {
                    return this.history;
                };
                e.prototype.isEqualToSelection = function(e, t) {
                    if (this.projectId !== e.documentID) return false;
                    if (this.sequenceId !== t.id) return false;
                    var r = t.getSelection();
                    if (this.itemNodeIds.length !== r.length) return false;
                    for (var n = 0; n < this.itemNodeIds.length; n++) {
                        if (this.itemNodeIds[n] !== r[n].nodeId) return false;
                    }
                    return true;
                };
                e.prototype.serialize = function() {
                    var e = this.getEditors();
                    if (!e.valid) throw e.error;
                    return e.selectionEditor.serialize();
                };
                e.prototype.update = function() {
                    var e = this.getEditors();
                    if (!e.valid) return d.resolve();
                    var t = e.selectionEditor, r = e.colorEditor;
                    return t.update().then(function() {
                        return r.update();
                    });
                };
                e.prototype.getPropertyTree = function() {
                    var e = this.getEditors();
                    if (!e.valid) throw e.error;
                    return e.selectionEditor.getPropertyTree();
                };
                e.prototype.getEditableClips = function(e, t) {
                    var r = [];
                    for (var n = 0, o = t; n < o.length; n++) {
                        var i = o[n];
                        if (this.clipTreeBuilder.isClipEditable(i)) {
                            r.push(i);
                        }
                    }
                    return r;
                };
                e.prototype.buildPropertyTree = function(e, t, r) {
                    var n = null;
                    if (t.length == 0) return f.PropertyTreeNode.createRootNode();
                    for (var o = 0; o < t.length; o++) {
                        var i = t[o];
                        var a = this.clipTreeBuilder.buildClipTree(i, e);
                        if (n == null) {
                            n = a;
                        } else {
                            var u = (0, c.getPropertyTreeIntersection)(n, a);
                            if (u) n = u;
                        }
                    }
                    if (n == null) return f.PropertyTreeNode.createRootNode();
                    this.linkAggregatedTextProperties(n);
                    this.addPresetProperty(n, r);
                    return n;
                };
                e.prototype.addPresetProperty = function(e, t) {
                    var r;
                    var n = e.findChildByName("Precomp Settings");
                    if (!n) return;
                    var o = (r = t === null || t === void 0 ? void 0 : t.getSourceIdentifier()) !== null && r !== void 0 ? r : "";
                    n.property = new i.PresetProperty(this.events, n.name, this.history, this.presets, e, o);
                };
                e.prototype.linkAggregatedTextProperties = function(e) {
                    function s(e, t) {
                        var r;
                        if (t != null && e.property instanceof l.AggregateProperty) {
                            var n = p(e.property);
                            if (n.length === 0) return;
                            var o = (0, c.findPropertyTreeNode)(t, function(e) {
                                if (e.property instanceof l.AggregateProperty) {
                                    return m(e.property, n);
                                } else {
                                    return false;
                                }
                            });
                            if (o != null) {
                                e.property.setAttributes({
                                    fontPropertyId: (r = o.property) === null || r === void 0 ? void 0 : r.id
                                });
                            }
                            return;
                        }
                        for (var i = 0, a = e.children; i < a.length; i++) {
                            var u = a[i];
                            s(u, e);
                        }
                    }
                    s(e, null);
                };
                e.prototype.buildSingleEditor = function(e) {
                    if (e.length === 0) return null;
                    var t = new o.Clip(e[0]);
                    return new n.SingleItemEditor(this.events, t);
                };
                e.prototype.buildEditorState = function(e, t, r, n) {
                    var o = t.length > 0;
                    for (var i = 0, a = t; i < a.length; i++) {
                        var u = a[i];
                        if (u.mediaType !== "Audio") {
                            o = false;
                            break;
                        }
                    }
                    var s = false;
                    for (var c = 0, l = n.children; c < l.length; c++) {
                        var p = l[c];
                        if (p.type === f.PropertyTreeNodeType.CaptionGroup) {
                            s = true;
                            break;
                        }
                    }
                    return {
                        numSelectedItems: r.length,
                        activeFrameSize: [ e.frameSizeHorizontal, e.frameSizeVertical ],
                        soundApplyOptions: {
                            replaceable: o
                        },
                        captionsApplyOptions: {
                            replaceable: s
                        }
                    };
                };
                e.prototype.getEditors = function() {
                    if (this.editors == null) {
                        throw new h.Exception("Selection editor is not initialized");
                    }
                    return this.editors;
                };
                return e;
            }();
            t.SequenceSelectionEditor = s;
            var g = 8;
            function p(e) {
                var t = [];
                for (var r = 0, n = e.getAggregatedProperties(); r < n.length; r++) {
                    var o = n[r];
                    var i = o.getAttributes();
                    var a = i === null || i === void 0 ? void 0 : i.fontPropertyId;
                    if (typeof a === "string") {
                        t.push(a);
                    }
                }
                return t;
            }
            function m(e, r) {
                return (0, u.every)(e.getAggregatedProperties(), function(t) {
                    return (0, u.some)(r, function(e) {
                        return e === t.id;
                    });
                });
            }
        },
        5452: function(e, t) {
            "use strict";
            t.__esModule = true;
            t.getLimitedSelection = void 0;
            var n = 8;
            function r(e) {
                var t = e.getSelection();
                var r = Math.min(n, t.length);
                return t.slice(0, r);
            }
            t.getLimitedSelection = r;
        },
        2613: function(e, t, r) {
            "use strict";
            t.__esModule = true;
            t.AppEvents = void 0;
            var n = r(8537);
            var o = r(3547);
            var i = r(5897);
            var a = r(3745);
            var u = function() {
                function e(e, t) {
                    var r = this;
                    this.initialized = false;
                    this.selectionScheduler = new s();
                    this.projectScheduler = new s();
                    this.sequenceScheduler = new s();
                    this.onSelectionChanged = function() {
                        r.selectionScheduler.schedule();
                        o.globalLock.wait(function() {
                            if (!r.selectionScheduler.isPending()) return;
                            r.selectionScheduler.execute();
                            (0, n.executeEventHandler)(function() {
                                r.openProjects.update();
                                (0, a.settleSync)(r.editorManager.updateSelectionEditor());
                            });
                        });
                    };
                    this.onProjectChanged = function(e) {
                        var t = e.projectID;
                        r.projectScheduler.schedule();
                        o.globalLock.wait(function() {
                            if (!r.projectScheduler.isPending()) return;
                            r.projectScheduler.execute();
                            (0, n.executeEventHandler)(function() {
                                r.openProjects.update();
                                if (r.openProjects.isOpen(t)) {
                                    r.undoStackManager.updateProject(t);
                                    r.editorManager.updateProjectHistory(t);
                                }
                                (0, a.settleSync)(r.editorManager.updateSelectionEditor());
                            });
                        });
                    };
                    this.onSequenceActivated = function() {
                        r.sequenceScheduler.schedule();
                        o.globalLock.wait(function() {
                            if (!r.sequenceScheduler.isPending()) return;
                            r.sequenceScheduler.execute();
                            (0, n.executeEventHandler)(function() {
                                var e;
                                var t = (e = app.project) === null || e === void 0 ? void 0 : e.documentID;
                                if (t == null) return;
                                r.openProjects.update();
                                if (r.openProjects.isOpen(t)) {
                                    r.undoStackManager.updateProject(t);
                                    r.editorManager.updateProjectHistory(t);
                                }
                                (0, a.settleSync)(r.editorManager.updateSelectionEditor());
                            });
                        });
                    };
                    this.onProjectClosed = function(e) {
                        var t = e.projectID;
                        r.undoStackManager.closeProject(t);
                        r.editorManager.clearProjectHistory(t);
                    };
                    this.openProjects = new c(this.onProjectClosed);
                    this.editorManager = e;
                    this.undoStackManager = t;
                }
                e.prototype.subscribe = function() {
                    if (this.initialized) return;
                    this.initialized = true;
                    app.addEventListener("onActiveSequenceSelectionChanged", this.onSelectionChanged);
                    app.addEventListener("onProjectChanged", this.onProjectChanged);
                    app.addEventListener("onSequenceActivated", this.onSequenceActivated);
                };
                e.prototype.unsubscribe = function() {
                    if (!this.initialized) return;
                    this.initialized = false;
                    app.removeEventListener("onActiveSequenceSelectionChanged", this.onSelectionChanged);
                    app.removeEventListener("onProjectChanged", this.onProjectChanged);
                    app.removeEventListener("onSequenceActivated", this.onSequenceActivated);
                };
                return e;
            }();
            t.AppEvents = u;
            var s = function() {
                function e() {
                    this.scheduledAt = 0;
                    this.executedAt = 0;
                }
                e.prototype.schedule = function() {
                    this.scheduledAt = new Date().getTime();
                };
                e.prototype.execute = function() {
                    this.executedAt = new Date().getTime();
                };
                e.prototype.isPending = function() {
                    return this.scheduledAt > this.executedAt;
                };
                return e;
            }();
            var c = function() {
                function e(e) {
                    this.onClose = e;
                    this.openProjectIds = new i.Set();
                    this.update();
                }
                e.prototype.isOpen = function(e) {
                    return this.openProjectIds.has(e);
                };
                e.prototype.update = function() {
                    var e = l();
                    for (var t = 0, r = this.openProjectIds.values(); t < r.length; t++) {
                        var n = r[t];
                        if (!e.has(n)) {
                            this.onClose({
                                projectID: n
                            });
                        }
                    }
                    this.openProjectIds = e;
                };
                return e;
            }();
            function l() {
                var e = new i.Set();
                for (var t = 0; t < app.projects.numProjects; t++) {
                    e.add(app.projects[t].documentID);
                }
                return e;
            }
        },
        1955: function(e, t, r) {
            "use strict";
            var n = r(8708);
            var o = this && this.__extends || function() {
                var n = function(e, t) {
                    n = Object.setPrototypeOf || {
                        __proto__: []
                    } instanceof Array && function(e, t) {
                        e.__proto__ = t;
                    } || function(e, t) {
                        for (var r in t) if (Object.prototype.hasOwnProperty.call(t, r)) e[r] = t[r];
                    };
                    return n(e, t);
                };
                return function(e, t) {
                    if (typeof t !== "function" && t !== null) throw new TypeError("Class extends value " + String(t) + " is not a constructor or null");
                    n(e, t);
                    function r() {
                        this.constructor = e;
                    }
                    e.prototype = t === null ? Object.create(t) : (r.prototype = t.prototype, 
                    new r());
                };
            }();
            var i = this && this.__assign || function() {
                i = Object.assign || function(e) {
                    for (var t, r = 1, n = arguments.length; r < n; r++) {
                        t = arguments[r];
                        for (var o in t) if (Object.prototype.hasOwnProperty.call(t, o)) e[o] = t[o];
                    }
                    return e;
                };
                return i.apply(this, arguments);
            };
            t.__esModule = true;
            t.PCExternalObject = void 0;
            var a = r(4428);
            var u = function(e) {
                o(t, e);
                function t() {
                    return e !== null && e.apply(this, arguments) || this;
                }
                t.prototype.getAeGraphicParams = function(e) {
                    return this.callApi("Content.getAeGraphicParams", {
                        file: e
                    });
                };
                t.prototype.getMogrtInfoFromItem = function(e) {
                    return this.callApi("Content.getMogrtInfo", {
                        id: e
                    });
                };
                t.prototype.normalizeString = function(e) {
                    return this.callApi("Content.normalizeString", {
                        string: e,
                        normalizationForm: "NFC"
                    });
                };
                t.prototype.normalizeFilePath = function(e) {
                    return this.callApi("Content.normalizeFilePath", {
                        filePath: e
                    });
                };
                t.prototype.doCommand = function(e) {
                    return this.callApi("ControlSurface.doCommand", {
                        command: e
                    });
                };
                t.prototype.createMogrtInstance = function(e) {
                    var t = e.itemNodeId, r = e.width, n = e.height, o = e.duration;
                    return this.callApi("Content.createMogrtInstance", {
                        id: t,
                        width: r,
                        height: n,
                        duration: o
                    });
                };
                t.prototype.createAnimatedFontInstance = function(e) {
                    var t = e.itemNodeId, r = e.text, n = e.width, o = e.height;
                    return this.callApi("Content.createAnimatedFontInstance", {
                        id: t,
                        text: r,
                        width: n,
                        height: o
                    });
                };
                t.prototype.createAnimatedCaptionInstance = function(e) {
                    var t = e.itemNodeId, r = e.width, n = e.height, o = e.duration;
                    return this.callApi("Content.createAnimatedCaptionInstance", {
                        id: t,
                        width: r,
                        height: n,
                        duration: o
                    });
                };
                t.prototype.ensureFootageForItem = function(e, t) {
                    return this.callApi("Content.ensureFootageForItem", {
                        id: e,
                        projectPath: t
                    });
                };
                t.prototype.ensureAdditionalFootageForItem = function(e, t, r) {
                    return this.callApi("Content.ensureAdditionalFootageForItem", {
                        id: e,
                        projectPath: t,
                        name: r
                    });
                };
                t.prototype.prepareSequenceForImport = function(e) {
                    return this.callApi("Content.prepareSequenceForImport", e);
                };
                t.prototype.getItemImportMeta = function(e) {
                    return this.callApi("Content.getItemImportMeta", {
                        id: e
                    });
                };
                t.prototype.createPreviewFile = function(e) {
                    return this.callApi("Preview.createPreviewFile", e);
                };
                t.prototype.getTempFile = function(e) {
                    return this.callApi("Content.getTempFile", {
                        extension: e
                    });
                };
                t.prototype.deleteTempFiles = function(e) {
                    this.callApi("Content.deleteTempFiles", {
                        files: e
                    });
                };
                t.prototype.getPalettes = function(e, t) {
                    return this.callApi("Palette.getAllForGroup", {
                        groupId: e,
                        colorIds: t
                    });
                };
                t.prototype.savePalette = function(e) {
                    this.callApi("Palette.save", e);
                };
                t.prototype.deletePalette = function(e) {
                    this.callApi("Palette.delete", {
                        id: e
                    });
                };
                t.prototype.getPropertyTreePresets = function() {
                    return this.callApi("UserData.getPropertyTreePresets");
                };
                t.prototype.savePropertyTreePreset = function(e) {
                    this.callApi("UserData.savePropertyTreePreset", {
                        id: e.id,
                        preset: e.value
                    });
                };
                t.prototype.deletePropertyTreePreset = function(e) {
                    this.callApi("UserData.deletePropertyTreePreset", {
                        id: e
                    });
                };
                t.prototype.transcribeSource = function(e, t, r, n) {
                    this.callApi("Captions.transcribeSource", i(i({
                        sourceFilePath: e,
                        transcriptId: t
                    }, r), n));
                };
                t.prototype.requestTranscript = function(e, t, r) {
                    this.callApi("Captions.requestTranscript", {
                        transcriptId: e,
                        workArea: t,
                        layout: r
                    });
                };
                t.prototype.releaseTranscript = function(e) {
                    return this.callApi("Captions.releaseTranscript", {
                        transcriptId: e
                    });
                };
                t.prototype.updateTranscriptLayout = function(e, t) {
                    return this.callApi("Captions.updateLayout", {
                        transcript: e,
                        layout: t
                    });
                };
                t.prototype.checkDependencies = function() {
                    this.callMethod("checkDependencies");
                };
                t.prototype.callApi = function(e, t) {
                    return this.callMethod("callSync", e, l(t !== null && t !== void 0 ? t : {}));
                };
                t.prototype.getLibPath = function() {
                    return this.supportFiles.getPlatformFilePath({
                        windows: "MHPC_ExternalObject.dll",
                        macos: "MHPC_ExternalObject.bundle"
                    });
                };
                return t;
            }(a.MHExternalObject);
            t.PCExternalObject = u;
            var s = /[^\u0000-\u007F]/g;
            var c = function(e) {
                return "\\u" + ("0000" + e.charCodeAt(0).toString(16)).slice(-4);
            };
            function l(e) {
                return n.stringify(e).replace(s, c);
            }
        },
        4965: function(e, t) {
            "use strict";
            t.__esModule = true;
            t.parseCaptionClipData = t.serializeCaptionClipData = void 0;
            function u(e, t) {
                for (var r = 0, n = t; r < n.length; r++) {
                    var o = n[r];
                    e.push(o.length + "\n" + o + "\n");
                }
            }
            function r(e) {
                var t = [];
                for (var r in e) {
                    t.push(r);
                }
                var n = [ t.length + "\n" ];
                for (var o = 0, i = t; o < i.length; o++) {
                    var r = i[o];
                    var a = e[r];
                    n.push(r + "\n");
                    n.push(a.hash + "\n");
                    n.push(a.editorChunks.length + "\n");
                    n.push(a.captionChunks.length + "\n");
                    u(n, a.editorChunks);
                    u(n, a.captionChunks);
                }
                return n.join("");
            }
            t.serializeCaptionClipData = r;
            function n(o) {
                var e = {};
                var i = 0;
                function a() {
                    var e = o.indexOf("\n", i);
                    if (e === -1) throw new Error("Unexpected end of input");
                    var t = o.substring(i, e);
                    i = e + 1;
                    return t;
                }
                function t(e) {
                    var t = [];
                    for (var r = 0; r < e; r++) {
                        var n = parseInt(a(), 10);
                        t.push(o.substr(i, n));
                        i += n + 1;
                    }
                    return t;
                }
                var r = parseInt(a(), 10);
                for (var n = 0; n < r; n++) {
                    var u = a();
                    var s = a();
                    var c = parseInt(a(), 10);
                    var l = parseInt(a(), 10);
                    e[u] = {
                        hash: s,
                        editorChunks: t(c),
                        captionChunks: t(l)
                    };
                }
                return e;
            }
            t.parseCaptionClipData = n;
        },
        6265: function(e, t) {
            "use strict";
            t.__esModule = true;
            t.GraphicParams = void 0;
            var r = function() {
                function e(e) {
                    this.externalObject = e;
                    this.graphicParamsCache = {};
                }
                e.prototype.getGraphicParams = function(e) {
                    if (this.graphicParamsCache[e] == null) {
                        var t = this.externalObject.getAeGraphicParams(e);
                        this.graphicParamsCache[e] = t;
                    }
                    return this.graphicParamsCache[e];
                };
                return e;
            }();
            t.GraphicParams = r;
        },
        9144: function(e, t, r) {
            "use strict";
            var n = this && this.__extends || function() {
                var n = function(e, t) {
                    n = Object.setPrototypeOf || {
                        __proto__: []
                    } instanceof Array && function(e, t) {
                        e.__proto__ = t;
                    } || function(e, t) {
                        for (var r in t) if (Object.prototype.hasOwnProperty.call(t, r)) e[r] = t[r];
                    };
                    return n(e, t);
                };
                return function(e, t) {
                    if (typeof t !== "function" && t !== null) throw new TypeError("Class extends value " + String(t) + " is not a constructor or null");
                    n(e, t);
                    function r() {
                        this.constructor = e;
                    }
                    e.prototype = t === null ? Object.create(t) : (r.prototype = t.prototype, 
                    new r());
                };
            }();
            t.__esModule = true;
            t.CaptionsImporter = void 0;
            var o = r(4559);
            var i = r(1009);
            var u = r(9008);
            var p = r(8234);
            var d = r(3285);
            var h = r(1137);
            var f = r(3575);
            var s = r(4155);
            var c = r(4425);
            var v = r(1413);
            var y = r(5132);
            var a = function(a) {
                n(l, a);
                function l(e, t, r, n, o) {
                    var i = a.call(this, e, t, r) || this;
                    i.project = app.project;
                    i.sequence = i.project.activeSequence;
                    i.insertTime = (0, p.createTimeValue)(0);
                    i.videoTrackIndex = 0;
                    i.selectedLocations = [];
                    i.insertedClips = [];
                    i.propertyValues = null;
                    i.graphics = n;
                    i.transcriber = o;
                    return i;
                }
                l.prototype.getCaptionTemplateInfo = function(e) {
                    var t, r, n, o, i;
                    var a = e.itemNodeId;
                    var u = this.externalObject.getMogrtInfoFromItem(a);
                    var s = this.externalObject.getItemImportMeta(a);
                    return {
                        maxDuration: (t = u.duration) !== null && t !== void 0 ? t : 30,
                        editorChunks: (n = (r = s.caption) === null || r === void 0 ? void 0 : r.editorChunks) !== null && n !== void 0 ? n : 1,
                        captionChunks: (i = (o = s.caption) === null || o === void 0 ? void 0 : o.captionChunks) !== null && i !== void 0 ? i : 1
                    };
                };
                l.prototype.getReplacedClipInfo = function() {
                    this.useContext();
                    this.captureSelectedClips();
                    return this.getSelectedClipInfo();
                };
                l.prototype.getReplacedClipData = function() {
                    this.useContext();
                    this.captureSelectedClips();
                    return this.getSelectedClipData();
                };
                l.prototype.prepareCaptions = function(e) {
                    var t = e.workArea, r = e.transcriptId, n = e.transcriptParams;
                    this.useContext();
                    this.transcribeSequence(t, r, n);
                };
                l.prototype.finishCaptions = function(e) {
                    var t = this;
                    var r = e.itemNodeId, n = e.transcriptId, o = e.blueprints;
                    var i = this.useContext();
                    this.usePendingTranscript(n);
                    this.createTempFileContext().execute(function(e) {
                        t.executeUndoGroup(i, function() {
                            t.findFreeTracks(o);
                            t.insertCaptionClips(e, r, o);
                            t.selectClips();
                        });
                    });
                };
                l.prototype.cleanCaptions = function(e) {
                    var t = e.transcriptId;
                    this.cleanPendingTranscript(t);
                };
                l.prototype.replaceCaptions = function(t) {
                    var r = this;
                    var n = t.itemNodeId, o = t.blueprints;
                    var i = this.useContext();
                    this.captureSelectedClips();
                    this.captureClipProperties();
                    this.createTempFileContext().execute(function(e) {
                        r.executeUndoGroup(i, function() {
                            r.removeSelectedClips();
                            r.insertCaptionClips(e, n, o);
                            r.applyCapturedProperties(t);
                            r.selectClips();
                        });
                    });
                };
                l.prototype.useContext = function() {
                    var e = this.getContext();
                    if (e == null) throw new u.UserError("No sequence is currently open");
                    this.project = e.project;
                    this.sequence = e.sequence;
                    return e;
                };
                l.prototype.transcribeSequence = function(e, t, r) {
                    var n = g(this.sequence, e)[0];
                    var o = this.createTempFileContext();
                    if (r.model != null) {
                        var i = o.getTempFile("mp3");
                        var a = this.getEncoderPresetPath();
                        var u = e === "inOut" ? app.encoder.ENCODE_IN_TO_OUT : app.encoder.ENCODE_ENTIRE;
                        this.sequence.exportAsMediaDirect(i, a, u);
                        this.transcriber.transcribeSource(i, t, r.model, r.layout);
                    } else {
                        this.transcriber.requestTranscript(t, e, r.layout);
                    }
                    var s = this.sequence.sequenceID;
                    var c = {
                        transcriptId: t,
                        sequenceId: s,
                        baseTime: n,
                        tempFileContext: o
                    };
                    l.pendingTranscripts[t] = c;
                };
                l.prototype.usePendingTranscript = function(e) {
                    var t = l.pendingTranscripts[e];
                    if (t == null) throw new u.Exception("Pending transcript not found");
                    if (this.sequence.sequenceID !== t.sequenceId) {
                        throw new u.Exception("Sequence has changed");
                    }
                    this.insertTime = t.baseTime;
                };
                l.prototype.cleanPendingTranscript = function(e) {
                    var t = l.pendingTranscripts[e];
                    if (t == null) return;
                    t.tempFileContext.deleteTempFiles();
                    delete l.pendingTranscripts[e];
                };
                l.prototype.captureSelectedClips = function() {
                    this.selectedLocations = (0, v.getSelectedClips)(this.sequence);
                    var e = (0, y.findFirstClip)(this.selectedLocations, c.ClipType.Video);
                    if (e == null) throw new u.Exception("No video clip is selected");
                    this.videoTrackIndex = e.trackIndex;
                };
                l.prototype.captureClipProperties = function() {
                    var e = (0, y.findFirstClip)(this.selectedLocations, c.ClipType.Video);
                    if (e == null) throw new u.Exception("No video clip is selected");
                    var t = (0, v.getClip)(this.sequence, e);
                    var r = this.getClipControlTree(t);
                    if (r != null) {
                        this.propertyValues = (0, f.captureClipProperties)(t, r);
                    }
                };
                l.prototype.removeSelectedClips = function() {
                    (0, v.removeClips)(this.sequence, this.selectedLocations);
                };
                l.prototype.findFreeTracks = function(e) {
                    var t = m(e), r = t[0], n = t[1];
                    var o = (0, p.createTimeValue)(this.insertTime.seconds + r);
                    var i = n - r;
                    this.videoTrackIndex = (0, s.getFreeTracks)(this.sequence, o.seconds, i, 1, 0, true)[0];
                };
                l.prototype.insertCaptionClips = function(e, t, r) {
                    for (var n = 0, o = r; n < o.length; n++) {
                        var i = o[n];
                        var a = (0, p.createTimeValue)(this.insertTime.seconds + i.startTime);
                        var u = (0, p.addTimeValues)(a, (0, p.createTimeValue)(i.duration));
                        var s = (0, p.subtractTimeValues)(u, a);
                        var c = e.addTempFile(this.createMogrt(t, s.seconds));
                        var l = (0, f.importMgtOrThrow)(this.sequence, c, a.ticks, this.videoTrackIndex, 0);
                        l.disabled = true;
                        l.end = u;
                        C(l, i.data);
                        l.disabled = false;
                        this.insertedClips.push(l);
                    }
                };
                l.prototype.applyCapturedProperties = function(e) {
                    if (this.propertyValues == null) return;
                    for (var t = 0, r = this.insertedClips; t < r.length; t++) {
                        var n = r[t];
                        var o = this.getClipControlTree(n);
                        if (o == null) continue;
                        (0, f.copyClipProperties)(n, o, this.propertyValues, e);
                    }
                };
                l.prototype.getClipControlTree = function(e) {
                    var t = e.projectItem.getMediaPath();
                    if (!/\.aegraphic$/.test(t)) return null;
                    var r = this.graphics.getGraphicParams(t);
                    var n = e.getMGTComponent();
                    if (r.controls.length !== n.properties.length) return null;
                    return (0, o.buildControlTree)(r.controls);
                };
                l.prototype.selectClips = function() {
                    this.sequence.setSelection(this.insertedClips);
                };
                l.prototype.getSelectedClipInfo = function() {
                    var e = (0, p.timeFromTicks)(this.sequence.timebase);
                    var t = {};
                    for (var r = 0, n = this.selectedLocations; r < n.length; r++) {
                        var o = n[r];
                        var i = (0, v.getClip)(this.sequence, o);
                        t[i.nodeId] = P(i, e);
                    }
                    return t;
                };
                l.prototype.getSelectedClipData = function() {
                    var e = {};
                    for (var t = 0, r = this.selectedLocations; t < r.length; t++) {
                        var n = r[t];
                        var o = (0, v.getClip)(this.sequence, n);
                        e[o.nodeId] = T(o);
                    }
                    return e;
                };
                l.prototype.createMogrt = function(e, t) {
                    return this.externalObject.createAnimatedCaptionInstance({
                        itemNodeId: e,
                        width: this.sequence.frameSizeHorizontal,
                        height: this.sequence.frameSizeVertical,
                        duration: t !== null && t !== void 0 ? t : 0
                    });
                };
                l.prototype.getEncoderPresetPath = function() {
                    var e = new File(this.supportFiles.getFilePath("MH Captions Compressed.epr"));
                    if (!e.exists) throw new u.Exception("Media encoder preset file is missing");
                    return e.fsName;
                };
                l.pendingTranscripts = {};
                return l;
            }(i.Importer);
            t.CaptionsImporter = a;
            function g(e, t) {
                var r = (0, p.createTimeValue)(0);
                var n = (0, p.timeFromTicks)(e.end);
                if (t === "inOut") {
                    var o = e.getInPointAsTime();
                    var i = e.getOutPointAsTime();
                    if (o.seconds < 0) {
                        o = r;
                    }
                    if (i.seconds < 0) {
                        i = n;
                    }
                    return [ o, i ];
                } else {
                    return [ r, n ];
                }
            }
            function m(e) {
                var t = null;
                var r = null;
                for (var n = 0, o = e; n < o.length; n++) {
                    var i = o[n];
                    t = Math.min(t !== null && t !== void 0 ? t : Infinity, i.startTime);
                    r = Math.max(r !== null && r !== void 0 ? r : -Infinity, i.startTime + i.duration);
                }
                return [ t !== null && t !== void 0 ? t : 0, r !== null && r !== void 0 ? r : 0 ];
            }
            function P(e, t) {
                return {
                    id: e.nodeId,
                    startTime: e.start.seconds,
                    endTime: e.end.seconds,
                    inPoint: e.inPoint.seconds,
                    frameDuration: t.seconds,
                    editorChunks: 0,
                    captionChunks: 0
                };
            }
            function C(e, t) {
                var r = (0, h.getCaptionProperties)(e);
                x(r.hash.property, t.hash);
                for (var n = 0, o = r.caption; n < o.length; n++) {
                    var i = o[n], a = i.property, u = i.chunkIndex;
                    if (t.captionChunks.length <= u) continue;
                    a.setValue(t.captionChunks[u]);
                }
                for (var s = 0, c = r.editor; s < c.length; s++) {
                    var l = c[s], a = l.property, u = l.chunkIndex;
                    if (t.editorChunks.length <= u) continue;
                    a.setValue(t.editorChunks[u]);
                }
            }
            function T(e) {
                var t = (0, h.getCaptionProperties)(e);
                var r = (0, d.getEditText)((0, d.parseTextValue)(t.hash.property.getValue()));
                var n = [];
                for (var o = 0, i = t.caption; o < i.length; o++) {
                    var a = i[o], u = a.property, s = a.chunkIndex;
                    n[s] = u.getValue();
                }
                var c = [];
                for (var l = 0, p = t.editor; l < p.length; l++) {
                    var f = p[l], u = f.property, s = f.chunkIndex;
                    c[s] = u.getValue();
                }
                return {
                    hash: r,
                    editorChunks: c,
                    captionChunks: n
                };
            }
            function x(e, t) {
                var r = (0, d.parseTextValue)(e.getValue());
                r = (0, d.setEditText)(r, t);
                e.setValue((0, d.serializeTextValue)(r));
            }
        },
        870: function(e, t, r) {
            "use strict";
            var n = this && this.__extends || function() {
                var n = function(e, t) {
                    n = Object.setPrototypeOf || {
                        __proto__: []
                    } instanceof Array && function(e, t) {
                        e.__proto__ = t;
                    } || function(e, t) {
                        for (var r in t) if (Object.prototype.hasOwnProperty.call(t, r)) e[r] = t[r];
                    };
                    return n(e, t);
                };
                return function(e, t) {
                    if (typeof t !== "function" && t !== null) throw new TypeError("Class extends value " + String(t) + " is not a constructor or null");
                    n(e, t);
                    function r() {
                        this.constructor = e;
                    }
                    e.prototype = t === null ? Object.create(t) : (r.prototype = t.prototype, 
                    new r());
                };
            }();
            t.__esModule = true;
            t.FontImporter = void 0;
            var o = r(4530);
            var l = r(4155);
            var p = r(3575);
            var f = r(5132);
            var d = r(9008);
            var h = r(8234);
            var i = r(1009);
            var a = function(e) {
                n(t, e);
                function t() {
                    return e !== null && e.apply(this, arguments) || this;
                }
                t.prototype.insertFont = function(e) {
                    var t = this;
                    if (e.text.length === 0) throw new d.UserError("Text is empty");
                    var a = this.getContext();
                    if (!a) throw new d.UserError("No sequence is currently open");
                    var r = a.sequence.getPlayerPosition();
                    var u = e.itemNodeId, n = e.startTime, s = n === void 0 ? r.seconds : n, c = e.text;
                    this.createTempFileContext().execute(function(e) {
                        var n = t.createFontMogrt(a, u, c);
                        var o = e.addTempFile(n.file);
                        var i = n.mogrtInfo.duration;
                        if (i == null) throw new d.Exception("Mogrt duration is not set");
                        t.executeUndoGroup(a, function() {
                            var e = (0, l.getFreeTracks)(a.sequence, s, i, 1, 0, true)[0];
                            var t = (0, h.createTimeValue)(s);
                            var r = (0, p.importMgtOrThrow)(a.sequence, o, t.ticks, e, 0);
                            if (n.mogrtInfo.meta) {
                                (0, p.fixClipOutPoint)(r, n.mogrtInfo.meta);
                            }
                            (0, p.addBrandName)(r);
                            (0, p.ensureCorrectMogrtScale)(r);
                            (0, f.selectClip)(a.sequence, r);
                        });
                    });
                    (0, o.getQESequence)(a.sequence).makeCurrent();
                };
                t.prototype.createFontMogrt = function(e, t, r) {
                    var n = e.sequence.frameSizeHorizontal;
                    var o = e.sequence.frameSizeVertical;
                    return this.externalObject.createAnimatedFontInstance({
                        itemNodeId: t,
                        text: r,
                        width: n,
                        height: o
                    });
                };
                return t;
            }(i.Importer);
            t.FontImporter = a;
        },
        2184: function(e, t, r) {
            "use strict";
            var n = this && this.__extends || function() {
                var n = function(e, t) {
                    n = Object.setPrototypeOf || {
                        __proto__: []
                    } instanceof Array && function(e, t) {
                        e.__proto__ = t;
                    } || function(e, t) {
                        for (var r in t) if (Object.prototype.hasOwnProperty.call(t, r)) e[r] = t[r];
                    };
                    return n(e, t);
                };
                return function(e, t) {
                    if (typeof t !== "function" && t !== null) throw new TypeError("Class extends value " + String(t) + " is not a constructor or null");
                    n(e, t);
                    function r() {
                        this.constructor = e;
                    }
                    e.prototype = t === null ? Object.create(t) : (r.prototype = t.prototype, 
                    new r());
                };
            }();
            t.__esModule = true;
            t.FootageImporter = void 0;
            var o = r(1009);
            var f = r(4155);
            var d = r(4530);
            var h = r(9008);
            var i = function(e) {
                n(t, e);
                function t() {
                    return e !== null && e.apply(this, arguments) || this;
                }
                t.prototype.insertFootageFile = function(e) {
                    var t = e.itemNodeId;
                    var r = this.externalObject.getItemImportMeta(t);
                    if ("sourceFilePath" in r) {
                        this.insertVideoFootage(t);
                    } else {
                        this.insertImageSequence(t);
                    }
                };
                t.prototype.dropFootageFile = function(e) {
                    var t = e.itemNodeId;
                    var r = this.externalObject.getItemImportMeta(t);
                    if ("sourceFilePath" in r) {
                        throw new h.Exception("Video footage files cannot be dropped");
                    } else {
                        this.dropImageSequence(t);
                    }
                };
                t.prototype.openFootageFile = function(e) {
                    var t = e.itemNodeId;
                    var r = this.externalObject.getItemImportMeta(t);
                    if ("sourceFilePath" in r) {
                        this.openVideoFootage(r);
                    } else {
                        throw new h.UserError("Image sequence files cannot be opened in source monitor");
                    }
                };
                t.prototype.insertVideoFootage = function(s) {
                    var c = this;
                    var l = this.getContext();
                    if (!l) throw new h.UserError("No sequence is currently open");
                    var p = l.sequence.getPlayerPosition();
                    this.executeUndoGroup(l, function() {
                        var e = c.getProjectAssets(l.project).importItem(s);
                        var t = e.getMediaPath();
                        var r = false;
                        if (!v(t)) {
                            e.clearInPoint();
                            e.clearOutPoint();
                            r = e.getOutPoint(2).seconds > 0;
                        }
                        var n = e.getOutPoint().seconds - e.getInPoint().seconds;
                        var o = (0, f.getFreeTracks)(l.sequence, p.seconds, n, 1, r ? 1 : 0, false);
                        var i = o[0], a = o[1];
                        var u = l.sequence.insertClip(e, p, i, r ? a : 0);
                        if (!u) throw new h.Exception("Failed to import the file");
                    });
                    (0, d.getQESequence)(l.sequence).makeCurrent();
                };
                t.prototype.insertImageSequence = function(o) {
                    var i = this;
                    var a = this.getContext();
                    if (!a) throw new h.UserError("No sequence is currently open");
                    var u = a.sequence.getPlayerPosition();
                    this.executeUndoGroup(a, function() {
                        var e = i.getProjectAssets(a.project).importImageSequence(o);
                        var t = e.getOutPoint().seconds - e.getInPoint().seconds;
                        var r = (0, f.getFreeTracks)(a.sequence, u.seconds, t, 1, 0, false)[0];
                        var n = a.sequence.insertClip(e, u, r, 0);
                        if (!n) throw new h.Exception("Failed to import the file");
                    });
                    (0, d.getQESequence)(a.sequence).makeCurrent();
                };
                t.prototype.dropImageSequence = function(n) {
                    var o = this;
                    this.checkWrongBricksDrop();
                    this.replacePreviewBricks(function(e) {
                        if (e.videoTrackIndex == null) return;
                        var t = o.getProjectAssets(e.project).importImageSequence(n);
                        var r = e.sequence.insertClip(t, e.startTime, e.videoTrackIndex, 0);
                        if (!r) throw new h.Exception("Failed to import the file");
                        (0, d.getQESequence)(e.sequence).makeCurrent();
                    });
                };
                t.prototype.openVideoFootage = function(e) {
                    app.sourceMonitor.openFilePath(e.sourceFilePath);
                };
                return t;
            }(o.Importer);
            t.FootageImporter = i;
            function v(e) {
                return e.match(/\.(ai|eps|bmp|dib|rle|dpx|gif|ico|jpeg|jpg|jpe|jfif|png|psd|ptl|prtl|tga|tiff?)$/i);
            }
        },
        1009: function(e, t, r) {
            "use strict";
            t.__esModule = true;
            t.Importer = void 0;
            var l = r(4666);
            var c = r(4155);
            var p = r(9008);
            var f = r(5194);
            var d = r(1413);
            var n = r(492);
            var o = r(5998);
            var i = function() {
                function e(e, t, r) {
                    this.externalObject = e;
                    this.supportFiles = t;
                    this.undo = r;
                }
                e.prototype.getProjectAssets = function(e) {
                    return new o.ProjectAssets(e, this.externalObject);
                };
                e.prototype.removeProjectItem = function(e, t) {
                    var r = this.undo.getTempBin(e.documentID);
                    if (r == null) {
                        throw new p.Exception("Temporary bin is not available outside of an undo group");
                    }
                    t.moveBin(r);
                };
                e.prototype.executeUndoGroup = function(e, t) {
                    this.undo.executeUndoGroup(e.project.documentID, t);
                };
                e.prototype.checkWrongBricksDrop = function() {
                    this.checkBricksFileInSourceMonitor();
                    this.checkBricksInEmptyTimeline();
                    this.checkBricksFileInProjects();
                };
                e.prototype.replacePreviewBricks = function(e) {
                    var t = this.getContext();
                    if (t == null) return;
                    var r = this.findBricksClipsInSequence(t.sequence);
                    if (r == null) return;
                    var n = r.videoTrackIndex, o = r.audioTrackIndex, i = r.startTime;
                    var a = this.removeBricksClips(t.project, t.sequence), u = a[0], s = a[1];
                    this.executeUndoGroup(t, function() {
                        (0, c.addSequenceTracks)(t.sequence, {
                            videoTracks: u,
                            audioTracks: s
                        });
                        e({
                            project: t.project,
                            sequence: t.sequence,
                            videoTrackIndex: n,
                            audioTrackIndex: o,
                            startTime: i
                        });
                    });
                };
                e.prototype.getContext = function() {
                    var e;
                    var t = (e = app.project) === null || e === void 0 ? void 0 : e.activeSequence;
                    if (t == null) return null;
                    var r = (0, l.getProjectBySequenceId)(t.sequenceID);
                    if (r == null) return null;
                    return {
                        project: r,
                        sequence: t
                    };
                };
                e.prototype.createTempFileContext = function() {
                    return new n.TempFileContext(this.externalObject);
                };
                e.prototype.isBricksFileInSourceMonitor = function() {
                    var e = app.sourceMonitor.getProjectItem();
                    if (e == null) return false;
                    return a(e);
                };
                e.prototype.checkBricksFileInSourceMonitor = function() {
                    var e = false;
                    while (this.isBricksFileInSourceMonitor()) {
                        app.sourceMonitor.closeClip();
                        e = true;
                    }
                    if (e) {
                        throw new p.UserError('Dragging an item to the source monitor is not supported. Please drag it to the Timeline, or use the "Add" button.');
                    }
                };
                e.prototype.checkBricksInEmptyTimeline = function() {
                    var e = this.getContext();
                    if (e == null) return;
                    var t = true;
                    var r = false;
                    var n = f.SequenceSnapshot.create(e.sequence);
                    for (var o = 0, i = n.getClipLocations(); o < i.length; o++) {
                        var a = i[o];
                        var u = (0, d.getClip)(e.sequence, a);
                        t && (t = h(u));
                        r || (r = u.name === e.sequence.name);
                    }
                    if (!t || !r) return;
                    var s = (0, l.getQEProject)(e.project);
                    for (var c = 0; c < 3; c++) {
                        s.undo();
                    }
                    this.undo.preventRedo(e.project.documentID);
                    throw new p.UserError("Please, drag the item to an existing sequence timeline.");
                };
                e.prototype.checkBricksFileInProjects = function() {
                    var e = this.getContext();
                    if (e == null) return;
                    var t = this.findBricksClipsInSequence(e.sequence);
                    if (t != null) return;
                    var r = false;
                    for (var n = 0; n < app.projects.numProjects; n++) {
                        var o = app.projects[n];
                        var i = (0, l.findProjectItemRecursive)(o.rootItem, a);
                        if (i != null) {
                            (0, l.getQEProject)(o, true).undo();
                            this.undo.preventRedo(o.documentID);
                            r = true;
                            break;
                        }
                    }
                    if (r) {
                        throw new p.UserError('It seems that you are dragging the item to a project. Please drag it to the Timeline, or use the "Add" button.');
                    }
                };
                e.prototype.findBricksClipsInSequence = function(e) {
                    var t = null;
                    var r = null;
                    var n = null;
                    var o = f.SequenceSnapshot.create(e);
                    for (var i = 0, a = o.getClipLocations(); i < a.length; i++) {
                        var u = a[i];
                        var s = (0, d.getClip)(e, u);
                        if (!h(s)) continue;
                        if (u.type === d.ClipType.Video) {
                            t !== null && t !== void 0 ? t : t = u.trackIndex;
                        } else if (u.type === d.ClipType.Audio) {
                            r !== null && r !== void 0 ? r : r = u.trackIndex;
                        }
                        n !== null && n !== void 0 ? n : n = s.start;
                    }
                    if (n == null) return null;
                    return {
                        videoTrackIndex: t,
                        audioTrackIndex: r,
                        startTime: n
                    };
                };
                e.prototype.removeBricksClips = function(e, t) {
                    var r = t.videoTracks.numTracks;
                    var n = t.audioTracks.numTracks;
                    (0, l.getQEProject)(e).undo();
                    var o = t.videoTracks.numTracks;
                    var i = t.audioTracks.numTracks;
                    return [ Math.max(0, r - o), Math.max(0, n - i) ];
                };
                return e;
            }();
            t.Importer = i;
            function h(e) {
                if (e.projectItem == null) return false;
                return a(e.projectItem);
            }
            function a(e) {
                return /\.mhbricks$/.test(e.getMediaPath());
            }
        },
        3840: function(e, t, r) {
            "use strict";
            var n = this && this.__extends || function() {
                var n = function(e, t) {
                    n = Object.setPrototypeOf || {
                        __proto__: []
                    } instanceof Array && function(e, t) {
                        e.__proto__ = t;
                    } || function(e, t) {
                        for (var r in t) if (Object.prototype.hasOwnProperty.call(t, r)) e[r] = t[r];
                    };
                    return n(e, t);
                };
                return function(e, t) {
                    if (typeof t !== "function" && t !== null) throw new TypeError("Class extends value " + String(t) + " is not a constructor or null");
                    n(e, t);
                    function r() {
                        this.constructor = e;
                    }
                    e.prototype = t === null ? Object.create(t) : (r.prototype = t.prototype, 
                    new r());
                };
            }();
            var o = this && this.__assign || function() {
                o = Object.assign || function(e) {
                    for (var t, r = 1, n = arguments.length; r < n; r++) {
                        t = arguments[r];
                        for (var o in t) if (Object.prototype.hasOwnProperty.call(t, o)) e[o] = t[o];
                    }
                    return e;
                };
                return o.apply(this, arguments);
            };
            t.__esModule = true;
            t.getMogrtTrackCount = t.MogrtImporter = void 0;
            var a = r(4559);
            var u = r(4155);
            var y = r(4530);
            var s = r(3575);
            var g = r(1413);
            var c = r(5132);
            var l = r(3285);
            var m = r(9008);
            var P = r(8234);
            var i = r(1009);
            var p = r(9388);
            var f = function(i) {
                n(e, i);
                function e(e, t, r, n) {
                    var o = i.call(this, t, r, n) || this;
                    o.project = app.project;
                    o.sequence = o.project.activeSequence;
                    o.importMeta = {
                        name: "",
                        itemId: "",
                        inUserLibrary: false
                    };
                    o.mogrtInfo = {};
                    o.insertTime = (0, P.createTimeValue)(0);
                    o.importFilePath = "";
                    o.videoTrackIndex = 0;
                    o.audioTrackIndex = 0;
                    o.selectedLocations = [];
                    o.insertedLocations = [];
                    o.insertedClip = null;
                    o.propertyValues = null;
                    o.graphics = e;
                    return o;
                }
                e.prototype.insertMogrt = function(e) {
                    var t = this;
                    var r = e.itemNodeId, n = e.withAudio, o = n === void 0 ? true : n, i = e.usedFonts;
                    var a = this.useContext();
                    this.getImportMeta(r);
                    this.getMogrtInfo(r);
                    var u = this.getCutTime();
                    var s = this.sequence.getPlayerPosition();
                    if (u != null) {
                        if (s.seconds >= u.seconds) {
                            this.insertTime = (0, P.subtractTimeValues)(s, u);
                        } else {
                            this.insertTime = (0, P.createTimeValue)(0);
                        }
                    } else {
                        this.insertTime = s;
                    }
                    this.createTempFileContext().execute(function(e) {
                        t.prepareMogrtFile(e, r);
                        t.executeUndoGroup(a, function() {
                            t.findFreeTracks(o);
                            t.insertMogrtClip(o);
                            t.processInsertedClip(i);
                            t.splitInsertedClip();
                            t.insertAdditionalFootage(r, o);
                            t.selectSequence();
                            t.selectClips();
                            t.groupClips();
                        });
                    });
                };
                e.prototype.replaceMogrt = function(t) {
                    var r = this;
                    var e;
                    var n = t.itemNodeId, o = t.withAudio, i = o === void 0 ? true : o, a = t.unsafeReplace, u = a === void 0 ? false : a, s = t.usedFonts;
                    var c = this.useContext();
                    this.getImportMeta(n);
                    this.getMogrtInfo(n);
                    this.captureSelectedClips();
                    var l = this.getCutTime();
                    var p = T(this.sequence, this.selectedLocations);
                    var f = C(this.sequence, this.selectedLocations), d = f[0], h = f[1];
                    this.insertTime = p && l ? (0, P.subtractTimeValues)(p, l) : d;
                    var v = this.mogrtInfo.durationControl != null && ((e = this.mogrtInfo.meta) === null || e === void 0 ? void 0 : e.maxDur) != null;
                    var y = v ? h.seconds - d.seconds : undefined;
                    if (!u && !v && !this.isSafelyReplaceable()) {
                        throw new m.RetryableError("The new clip is longer than the clip you are replacing. If you replace it, the new clip will overwrite clips after it. Do you want to replace the clip anyway?", {
                            unsafeReplace: true
                        });
                    }
                    this.createTempFileContext().execute(function(e) {
                        r.prepareMogrtFile(e, n, y);
                        r.executeUndoGroup(c, function() {
                            r.removeSelectedClips();
                            r.insertMogrtClip(i);
                            r.processInsertedClip(s, t);
                            r.splitInsertedClip();
                            r.insertAdditionalFootage(n, i);
                            r.selectSequence();
                            r.selectClips();
                            r.groupClips();
                        });
                    });
                };
                e.prototype.dropMogrt = function(e) {
                    var r = this;
                    var n = e.itemNodeId, t = e.withAudio, o = t === void 0 ? true : t, i = e.usedFonts;
                    this.checkWrongBricksDrop();
                    this.getImportMeta(n);
                    this.getMogrtInfo(n);
                    this.createTempFileContext().execute(function(t) {
                        r.replacePreviewBricks(function(e) {
                            if (e.videoTrackIndex == null) return;
                            r.usePreviewContext(e);
                            r.prepareMogrtFile(t, n);
                            r.insertMogrtClip(o);
                            r.processInsertedClip(i);
                            r.splitInsertedClip();
                            r.insertAdditionalFootage(n, o);
                            r.selectSequence();
                            r.selectClips();
                            r.groupClips();
                        });
                    });
                };
                e.prototype.useContext = function() {
                    var e = this.getContext();
                    if (e == null) throw new m.UserError("No sequence is currently open");
                    this.project = e.project;
                    this.sequence = e.sequence;
                    return e;
                };
                e.prototype.usePreviewContext = function(e) {
                    var t, r;
                    this.project = e.project;
                    this.sequence = e.sequence;
                    this.insertTime = e.startTime;
                    this.videoTrackIndex = (t = e.videoTrackIndex) !== null && t !== void 0 ? t : 0;
                    this.audioTrackIndex = (r = e.audioTrackIndex) !== null && r !== void 0 ? r : 0;
                };
                e.prototype.getImportMeta = function(e) {
                    this.importMeta = this.externalObject.getItemImportMeta(e);
                };
                e.prototype.getMogrtInfo = function(e) {
                    this.mogrtInfo = this.externalObject.getMogrtInfoFromItem(e);
                };
                e.prototype.captureSelectedClips = function() {
                    var e;
                    this.selectedLocations = (0, g.getSelectedClips)(this.sequence);
                    var t = (0, c.findFirstClip)(this.selectedLocations, g.ClipType.Video);
                    var r = (0, c.findFirstClip)(this.selectedLocations, g.ClipType.Audio);
                    if (t == null) throw new m.Exception("No video clip is selected");
                    this.videoTrackIndex = t.trackIndex;
                    this.audioTrackIndex = (e = r === null || r === void 0 ? void 0 : r.trackIndex) !== null && e !== void 0 ? e : t.trackIndex;
                    var n = (0, g.getClip)(this.sequence, t);
                    var o = this.getClipControlTree(n);
                    if (o == null) return;
                    this.propertyValues = (0, s.captureClipProperties)(n, o);
                };
                e.prototype.prepareMogrtFile = function(e, t, r) {
                    var n = this.createMogrt(this.sequence, t, r);
                    if (n.tempFile === true) e.addTempFile(n.path);
                    this.importFilePath = n.path;
                };
                e.prototype.createMogrt = function(e, t, r) {
                    return this.externalObject.createMogrtInstance({
                        itemNodeId: t,
                        width: e.frameSizeHorizontal,
                        height: e.frameSizeVertical,
                        duration: r !== null && r !== void 0 ? r : 0
                    });
                };
                e.prototype.removeSelectedClips = function() {
                    (0, g.removeClips)(this.sequence, this.selectedLocations);
                };
                e.prototype.findFreeTracks = function(e) {
                    var t = this.mogrtInfo.duration;
                    if (t == null) {
                        throw new m.Exception("Mogrt duration is not set");
                    }
                    var r = this.insertTime.seconds;
                    var n = h(this.mogrtInfo, this.importMeta.additionalFootage);
                    var o = (0, u.getFreeTracks)(this.sequence, r, t, n.video, n.audio, !e);
                    this.videoTrackIndex = o[0], this.audioTrackIndex = o[1];
                };
                e.prototype.insertMogrtClip = function(e) {
                    if (this.importFilePath.length === 0) {
                        throw new m.Exception("No mogrt file has been prepared");
                    }
                    var t;
                    if (e) {
                        t = (0, s.importMgtOrThrow)(this.sequence, this.importFilePath, this.insertTime.ticks, this.videoTrackIndex, this.audioTrackIndex);
                    } else {
                        var r = (0, u.addSequenceTracks)(this.sequence, {
                            audioTracks: 1
                        }), n = r[1];
                        try {
                            t = (0, s.importMgtOrThrow)(this.sequence, this.importFilePath, this.insertTime.ticks, this.videoTrackIndex, n);
                        } finally {
                            (0, y.getQESequence)(this.sequence).removeAudioTrack(n);
                        }
                    }
                    this.insertedClip = t;
                    this.insertedLocations = [ (0, g.getClipLocation)(t, this.sequence) ];
                };
                e.prototype.processInsertedClip = function(e, t) {
                    if (t === void 0) {
                        t = {};
                    }
                    var r = this.getInsertedClip();
                    if (this.mogrtInfo.meta) {
                        (0, s.fixClipOutPoint)(r, this.mogrtInfo.meta);
                        (0, s.setMogrtBlendingMode)(r, this.mogrtInfo.meta);
                    }
                    if (!this.importMeta.inUserLibrary) {
                        (0, s.addBrandName)(r);
                    }
                    var n = this.getClipControlTree(r);
                    if (n != null) {
                        this.applyUsedFonts(n, e);
                        if (this.propertyValues != null) {
                            (0, s.copyClipProperties)(r, n, this.propertyValues, t);
                        }
                    }
                    (0, s.ensureCorrectMogrtScale)(r);
                };
                e.prototype.getClipControlTree = function(e) {
                    var t = e.projectItem.getMediaPath();
                    if (!/\.aegraphic$/.test(t)) return null;
                    var r;
                    try {
                        r = this.graphics.getGraphicParams(t);
                    } catch (e) {
                        return null;
                    }
                    var n = e.getMGTComponent();
                    if (r.controls.length !== n.properties.length) return null;
                    return (0, a.buildControlTree)(r.controls);
                };
                e.prototype.applyUsedFonts = function(e, t) {
                    var r;
                    var n = this.getInsertedClip();
                    var o = (r = this.mogrtInfo.meta) === null || r === void 0 ? void 0 : r.fontReuseGroupId;
                    if (o == null) return;
                    var i = t === null || t === void 0 ? void 0 : t[o];
                    if (i == null) return;
                    var a = n.getMGTComponent();
                    (0, s.traverseControlTree)(e, function(e) {
                        if (!(0, s.isTextProperty)(e)) return;
                        var t = a.properties[e.originalIndex];
                        var r = t.getValue();
                        var n = (0, l.parseTextValue)(r);
                        n = (0, l.setFontFamily)(n, i);
                        r = (0, l.serializeTextValue)(n);
                        t.setValue(r);
                    });
                };
                e.prototype.splitInsertedClip = function() {
                    var e = this.getCutTime();
                    if (e == null || e.seconds === 0) return;
                    var t = (0, P.addTimeValues)(this.insertTime, e);
                    (0, u.razorSequenceTrack)(this.sequence, g.ClipType.Video, this.videoTrackIndex, t);
                    this.insertedLocations = d(this.insertedLocations);
                };
                e.prototype.insertAdditionalFootage = function(e, t) {
                    if (!t) return;
                    var r = this.importMeta, n = r.itemId, o = r.additionalFootage;
                    if (o == null || o.length === 0) return;
                    if (n == null || n.length === 0) {
                        throw new m.Exception("Mogrt item ID is not set");
                    }
                    var i = this.getProjectAssets(this.project);
                    var a = (0, y.getSequenceFrameRate)(this.sequence);
                    for (var u = 0, s = o; u < s.length; u++) {
                        var c = s[u];
                        var l = i.importAdditionalFootage(e, c.file);
                        var p = (0, P.timeFromFraction)(c.startTime);
                        var f = (0, P.roundToNextFrame)((0, P.addTimeValues)(this.insertTime, p), a);
                        var d = this.audioTrackIndex + (c.track - 1);
                        var h = this.sequence.insertClip(l, f, 0, d);
                        if (!h) throw new m.Exception("Failed to insert additional footage");
                        var v = (0, g.findClipLocationAtTime)(this.sequence, g.ClipType.Audio, d, f);
                        if (v == null) throw new m.Exception("Failed to find inserted additional footage");
                        this.insertedLocations.push(v);
                    }
                };
                e.prototype.selectClips = function() {
                    (0, c.selectClips)(this.sequence, this.insertedLocations);
                };
                e.prototype.groupClips = function() {
                    this.externalObject.doCommand("cmd.clip.group");
                };
                e.prototype.selectSequence = function() {
                    (0, y.getQESequence)(this.sequence).makeCurrent();
                };
                e.prototype.getInsertedClip = function() {
                    if (this.insertedClip == null) {
                        throw new m.Exception("No mogrt clip has been inserted");
                    }
                    return this.insertedClip;
                };
                e.prototype.getCutTime = function() {
                    var e = this.importMeta.transitionInfo;
                    if (e == null) return null;
                    var t = (0, y.getSequenceFrameRate)(this.sequence);
                    var r = (0, P.timeFromFraction)(e.cutTime);
                    return (0, P.roundToNextFrame)(r, t);
                };
                e.prototype.isSafelyReplaceable = function() {
                    if (this.mogrtInfo.duration == null) return false;
                    var e = (0, c.findFirstClip)(this.selectedLocations, g.ClipType.Video);
                    if (e == null) return false;
                    var o = e.trackIndex;
                    var i = this.sequence.videoTracks[o];
                    var a = this.insertTime.seconds + this.mogrtInfo.duration - .035;
                    var t = function(t) {
                        var e = i.clips[t];
                        var r = (0, p.every)(u.selectedLocations, function(e) {
                            return e.trackIndex !== o || e.clipIndex !== t;
                        });
                        var n = e.start.seconds < u.insertTime.seconds || e.start.seconds > a;
                        if (r && !n) return {
                            value: false
                        };
                    };
                    var u = this;
                    for (var r = 0; r < i.clips.numItems; r++) {
                        var n = t(r);
                        if (typeof n === "object") return n.value;
                    }
                    return true;
                };
                return e;
            }(i.Importer);
            t.MogrtImporter = f;
            function d(e) {
                if (e.length !== 1) throw new m.Exception("Expected a single clip location");
                var t = e[0];
                var r = o(o({}, t), {
                    clipIndex: t.clipIndex + 1
                });
                return [ t, r ];
            }
            function C(e, t) {
                var r = null;
                var n = null;
                for (var o = 0, i = t; o < i.length; o++) {
                    var a = i[o];
                    var u = (0, g.getClip)(e, a);
                    if (r == null || u.start.seconds < r.seconds) r = u.start;
                    if (n == null || u.end.seconds > n.seconds) n = u.end;
                }
                if (r == null || n == null) {
                    throw new m.Exception("No video clips found");
                }
                return [ r, n ];
            }
            function T(t, e) {
                var r = (0, p.filter)(e, function(e) {
                    return e.type === g.ClipType.Video;
                });
                if (r.length !== 2) return null;
                var n = (0, p.map)(r, function(e) {
                    return (0, g.getClip)(t, e);
                }), o = n[0], i = n[1];
                if (!(0, P.isTimeEqual)(o.end, i.start)) return null;
                return o.end;
            }
            function h(e, t) {
                if (t === void 0) {
                    t = [];
                }
                var r = 1;
                var n = e.hasAudio ? 1 : 0;
                var o = 0;
                for (var i = 0, a = t; i < a.length; i++) {
                    var u = a[i];
                    o = Math.max(o, u.track);
                }
                n += o;
                return {
                    video: r,
                    audio: n
                };
            }
            t.getMogrtTrackCount = h;
        },
        987: function(e, t, r) {
            "use strict";
            var d = this && this.__spreadArray || function(e, t, r) {
                if (r || arguments.length === 2) for (var n = 0, o = t.length, i; n < o; n++) {
                    if (i || !(n in t)) {
                        if (!i) i = Array.prototype.slice.call(t, 0, n);
                        i[n] = t[n];
                    }
                }
                return e.concat(i || Array.prototype.slice.call(t));
            };
            t.__esModule = true;
            t.Preview = void 0;
            var f = r(3840);
            var u = r(9923);
            var h = r(9008);
            var v = r(8234);
            var y = r(9388);
            var n = function() {
                function e(e) {
                    this.externalObject = e;
                    this.cache = null;
                }
                e.prototype.getSoundPreviewFiles = function(e) {
                    var o = this;
                    var i = e.itemNodeId, a = e.speed;
                    var t = "".concat(i, "-").concat(a);
                    return this.getPreviewFiles(t, function() {
                        var e = o.externalObject.getItemImportMeta(i);
                        var t = e.sourceFileDuration / a;
                        var r = Math.ceil(t * 30);
                        var n = new u.FrameRate(30, 1);
                        return new C(e.name, [ r ], n, {
                            video: 0,
                            audio: 1
                        });
                    });
                };
                e.prototype.getMogrtPreviewFiles = function(e) {
                    var c = this;
                    var l = e.itemNodeId, p = e.withAudio;
                    var t = "".concat(l, "-").concat(p);
                    return this.getPreviewFiles(t, function(e) {
                        var t = c.externalObject.getItemImportMeta(l);
                        var r = t.transitionInfo ? (0, v.timeFromFraction)(t.transitionInfo.cutTime) : null;
                        var n = c.externalObject.getMogrtInfoFromItem(l);
                        if (n.duration == null) throw new h.Exception("Mogrt has no duration");
                        var o = (0, v.createTimeValue)(n.duration);
                        var i = e.getSequenceFrameRate();
                        var a = r ? [ r, o ] : [ o ];
                        var u = (0, y.map)(a, function(e) {
                            return P(e.seconds, g, i);
                        });
                        var s = (0, f.getMogrtTrackCount)(n, t.additionalFootage);
                        if (!p) s.audio = 0;
                        return new C(t.name, u, i, s);
                    });
                };
                e.prototype.getFootagePreviewFiles = function(e) {
                    var o = this;
                    var i = e.itemNodeId;
                    return this.getPreviewFiles(i, function(e) {
                        var t = o.externalObject.getItemImportMeta(i);
                        if ("sourceFilePath" in t) {
                            return new T([ t.sourceFilePath ]);
                        }
                        var r = e.getDefaultFrameRate();
                        var n = t.filePaths.length;
                        return new C(t.name, [ n ], r, {
                            video: 1,
                            audio: 0
                        });
                    });
                };
                e.prototype.getSequencePreviewFiles = function(e) {
                    var l = this;
                    var p = e.itemNodeId, f = e.withAudio;
                    var t = "".concat(p, "-").concat(f);
                    return this.getPreviewFiles(t, function(e) {
                        var t = l.externalObject.getItemImportMeta(p);
                        var r = t.sequenceMeta, n = r.duration, o = r.splitPoints, i = r.videoTracks, a = r.audioTracks;
                        var u = e.getSequenceFrameRate();
                        var s = o ? d(d([], o, true), [ n ], false) : [ n ];
                        var c = (0, y.map)(s, function(e) {
                            return P(e, m, u);
                        });
                        return new C(t.name, c, u, {
                            video: i,
                            audio: f ? a : 0
                        });
                    });
                };
                e.prototype.getCurrentSequence = function() {
                    var e = app.project;
                    if (e == null) return null;
                    var t = e.activeSequence;
                    if (t == null) return null;
                    return t;
                };
                e.prototype.getSequenceFrameRate = function() {
                    var e = this.getCurrentSequence();
                    if (e == null) return new u.FrameRate(30, 1);
                    return u.FrameRate.fromTimebase(e.timebase);
                };
                e.prototype.getDefaultFrameRate = function() {
                    var e = app.properties.getProperty("BE.Prefs.StillImages.DefaultFramerate");
                    return u.FrameRate.fromTimebase(e);
                };
                e.prototype.getCache = function() {
                    var e;
                    var t = new o(this.getDefaultFrameRate(), this.getSequenceFrameRate());
                    var r = (e = this.cache) === null || e === void 0 ? void 0 : e.getKey();
                    if (r === null || r === void 0 ? void 0 : r.isEqual(t)) {
                        return this.cache;
                    }
                    this.cache = new x(t);
                    return this.cache;
                };
                e.prototype.getPreviewFiles = function(e, t) {
                    var r;
                    var n = this.getCache();
                    var o = (r = n.getItem(e)) !== null && r !== void 0 ? r : t(n.getKey());
                    if (o != null) n.setItem(e, o);
                    return this.createPreviewFilesFromParams(o);
                };
                e.prototype.createPreviewFilesFromParams = function(e) {
                    if (e == null) return {
                        filePaths: []
                    };
                    if (e instanceof T) {
                        return {
                            filePaths: e.filePaths
                        };
                    }
                    if (e instanceof C) {
                        return this.externalObject.createPreviewFile(e.serialize());
                    }
                    return {
                        filePaths: []
                    };
                };
                return e;
            }();
            t.Preview = n;
            var i = new u.FrameRate(24e3, 1001);
            var a = new u.FrameRate(24, 1);
            var s = new u.FrameRate(25, 1);
            var c = new u.FrameRate(3e4, 1001);
            var l = new u.FrameRate(30, 1);
            var p = new u.FrameRate(50, 1);
            var g = c;
            var m = c;
            function P(e, t, r) {
                if (t.isEqual(c) || t.isEqual(l)) {
                    var n = t.getFramesPerSecond();
                    if (r.isEqual(a) || r.isEqual(i)) {
                        return Math.round(e * n * .7986062718 + .02787456446);
                    } else if (r.isEqual(s) || r.isEqual(p)) {
                        var o = Math.round(e * n * .8329268293 + .09756097561);
                        if (r.isEqual(p)) o *= 2;
                        return o;
                    }
                }
                return Math.round(e * r.getFramesPerSecond());
            }
            var C = function() {
                function e(e, t, r, n) {
                    this.label = e;
                    this.boundaries = t;
                    this.frameRate = r;
                    this.trackCounts = n;
                }
                e.prototype.serialize = function() {
                    var e = this.frameRate.getFraction(), t = e[0], r = e[1];
                    return {
                        label: this.label,
                        boundaries: this.boundaries,
                        videoTrackCount: this.trackCounts.video,
                        audioTrackCount: this.trackCounts.audio,
                        frameRateNumerator: t,
                        frameRateDenominator: r
                    };
                };
                return e;
            }();
            var T = function() {
                function e(e) {
                    this.filePaths = e;
                }
                return e;
            }();
            var o = function() {
                function e(e, t) {
                    this.defaultFrameRate = e;
                    this.sequenceFrameRate = t;
                }
                e.prototype.getDefaultFrameRate = function() {
                    return this.defaultFrameRate;
                };
                e.prototype.getSequenceFrameRate = function() {
                    return this.sequenceFrameRate;
                };
                e.prototype.isEqual = function(e) {
                    return this.defaultFrameRate.isEqual(e.defaultFrameRate) && this.sequenceFrameRate.isEqual(e.sequenceFrameRate);
                };
                return e;
            }();
            var x = function() {
                function e(e) {
                    this.key = e;
                    this.cache = {};
                }
                e.prototype.getKey = function() {
                    return this.key;
                };
                e.prototype.getItem = function(e) {
                    if (e in this.cache) {
                        return this.cache[e];
                    }
                    return null;
                };
                e.prototype.setItem = function(e, t) {
                    this.cache[e] = t;
                };
                return e;
            }();
        },
        4406: function(e, t, r) {
            "use strict";
            var n = this && this.__extends || function() {
                var n = function(e, t) {
                    n = Object.setPrototypeOf || {
                        __proto__: []
                    } instanceof Array && function(e, t) {
                        e.__proto__ = t;
                    } || function(e, t) {
                        for (var r in t) if (Object.prototype.hasOwnProperty.call(t, r)) e[r] = t[r];
                    };
                    return n(e, t);
                };
                return function(e, t) {
                    if (typeof t !== "function" && t !== null) throw new TypeError("Class extends value " + String(t) + " is not a constructor or null");
                    n(e, t);
                    function r() {
                        this.constructor = e;
                    }
                    e.prototype = t === null ? Object.create(t) : (r.prototype = t.prototype, 
                    new r());
                };
            }();
            t.__esModule = true;
            t.SequenceImporter = void 0;
            var o = r(1009);
            var h = r(4155);
            var F = r(4530);
            var V = r(5194);
            var _ = r(5132);
            var b = r(1413);
            var s = r(4666);
            var E = r(9008);
            var i = function(e) {
                n(t, e);
                function t() {
                    return e !== null && e.apply(this, arguments) || this;
                }
                t.prototype.insertSequence = function(e) {
                    var o = this;
                    var t = e.itemNodeId, i = e.withAudio;
                    var r = this.externalObject.getItemImportMeta(t);
                    var n = r.sequenceMeta, a = n.duration, u = n.videoTracks, s = n.audioTracks, c = n.splitPoints;
                    var l = this.getContext();
                    if (!l) throw new E.UserError("No sequence is currently open");
                    var p = this.getNonexistentSequenceBinName([ "Animation Composer", "Packs", "Sequences", r.name ], l.project);
                    var f = this.prepareSequence(t, l.project, l.sequence, p);
                    var d = l.sequence.getPlayerPosition();
                    if (c != null && c.length > 0) {
                        d.seconds = d.seconds - c[0];
                    }
                    this.executeUndoGroup(l, function() {
                        P(l.project);
                        var e = (0, h.getFreeTracks)(l.sequence, d.seconds, a, u, i ? s : 0, true), t = e[0], r = e[1];
                        var n = v(l.sequence);
                        g(l.sequence, t, r);
                        try {
                            o.copySequenceClips(l.project, l.sequence, f, d, i);
                        } finally {
                            y(l.sequence, n);
                        }
                    });
                };
                t.prototype.dropSequence = function(e) {
                    var o = this;
                    this.checkWrongBricksDrop();
                    var t = e.itemNodeId, i = e.withAudio;
                    var r = this.externalObject.getItemImportMeta(t);
                    var n = this.getContext();
                    if (n == null) return;
                    var a = this.getNonexistentSequenceBinName([ "Animation Composer", "Packs", "Sequences", r.name ], n.project);
                    var u = this.prepareSequence(t, n.project, n.sequence, a);
                    this.replacePreviewBricks(function(e) {
                        var t, r;
                        P(e.project);
                        var n = v(e.sequence);
                        g(e.sequence, (t = e.videoTrackIndex) !== null && t !== void 0 ? t : 0, (r = e.audioTrackIndex) !== null && r !== void 0 ? r : 0);
                        try {
                            o.copySequenceClips(e.project, e.sequence, u, e.startTime, i);
                        } finally {
                            y(e.sequence, n);
                        }
                    });
                };
                t.prototype.getNonexistentSequenceBinName = function(e, t) {
                    var r = t.rootItem;
                    for (var n = 0; n < e.length - 1; n++) {
                        var o = (0, s.findBinByName)(e[n], r);
                        if (o == null) return e[e.length - 1];
                        r = o;
                    }
                    var i = e[e.length - 1];
                    if ((0, s.findBinByName)(i, r) == null) return i;
                    for (var a = 2; ;a++) {
                        var u = "".concat(i, " (").concat(a, ")");
                        if ((0, s.findBinByName)(u, r) == null) return u;
                    }
                };
                t.prototype.prepareSequence = function(e, t, r, n) {
                    return this.externalObject.prepareSequenceForImport({
                        id: e,
                        projectPath: t.path,
                        frameWidth: r.frameSizeHorizontal,
                        frameHeight: r.frameSizeVertical,
                        sequenceBinName: n
                    });
                };
                t.prototype.copySequenceClips = function(e, t, r, n, o) {
                    var i = (0, F.getQESequence)(t);
                    var a = j(e);
                    q(function() {
                        e.importFiles([ r ], true, e.rootItem, false);
                    });
                    var u = t.getPlayerPosition().ticks;
                    t.setPlayerPosition(n.ticks);
                    var s = j(e);
                    var c = k(a, s);
                    if (c === null) {
                        throw new E.Exception("Unable to import the sequence");
                    }
                    var l = (0, F.getSequenceById)(e, c);
                    if (l == null) {
                        throw new E.Exception("Unable to find the imported sequence");
                    }
                    var p = M(l, o);
                    for (var f = 0, d = p; f < d.length; f++) {
                        var h = d[f];
                        if ((0, b.isClipType)(h, b.ClipType.Video)) h.disabled = true;
                    }
                    e.openSequence(l.sequenceID);
                    l.setSelection(p);
                    this.externalObject.doCommand("cmd.edit.copy");
                    e.openSequence(t.sequenceID);
                    i.makeCurrent();
                    var v = V.SequenceSnapshot.create(t);
                    this.externalObject.doCommand("cmd.edit.paste");
                    this.externalObject.doCommand("cmd.clip.group");
                    var y = V.SequenceSnapshot.create(t);
                    var g = y.getAddedClips(v);
                    if (g.getFirstClip(b.ClipType.Video) == null) {
                        throw new E.Exception("No items were copied into the sequence. This shouldn't happen. If the problem persists, try restarting Premiere.");
                    }
                    var m = A(l);
                    var P = (0, F.getSequenceFrameSize)(l);
                    var C = O(e, r);
                    l.close();
                    if (C) {
                        D(e, C);
                        C.deleteBin();
                    } else {
                        this.removeProjectItem(e, l.projectItem);
                    }
                    e.openSequence(t.sequenceID);
                    i.makeCurrent();
                    var T = g.getClipLocations(b.ClipType.Video);
                    (0, b.sortClipLocations)(T);
                    for (var x = 0, I = T; x < I.length; x++) {
                        var w = I[x];
                        (0, b.getClip)(t, w).disabled = false;
                    }
                    var S = this.fixAdjustmentLayerClips(t, T, m);
                    (0, _.scaleAdjustmentLayersToCanvas)(t, T);
                    (0, _.scaleClipsToCanvas)(t, T, P);
                    t.setPlayerPosition(u);
                    (0, _.selectClips)(t, g.getClipLocations());
                    if (!S) {
                        throw new E.UserError("Failed to convert clips to adjustment layers.");
                    }
                };
                t.prototype.fixAdjustmentLayerClips = function(e, t, r) {
                    if (t.length === 0) throw new E.Exception("Imported clips array is empty");
                    var n = [];
                    for (var o = 0, i = r; o < i.length; o++) {
                        var a = i[o];
                        var u = m(t, a);
                        var s = (0, b.getClip)(e, u);
                        if (s.isAdjustmentLayer()) continue;
                        n.push(s);
                    }
                    if (n.length === 0) return true;
                    e.setSelection(n);
                    this.externalObject.doCommand("cmd.clip.adjustmentlayer");
                    var c = 0;
                    for (var l = 0, p = t; l < p.length; l++) {
                        var f = p[l];
                        var d = (0, b.getClip)(e, f);
                        if (d.isAdjustmentLayer()) c++;
                    }
                    return c > 0;
                };
                return t;
            }(o.Importer);
            t.SequenceImporter = i;
            function v(e) {
                var t = {
                    audio: [],
                    video: []
                };
                for (var r = 0; r < e.audioTracks.numTracks; r++) {
                    t.audio[r] = e.audioTracks[r].isTargeted();
                }
                for (var r = 0; r < e.videoTracks.numTracks; r++) {
                    t.video[r] = e.videoTracks[r].isTargeted();
                }
                return t;
            }
            function y(e, t) {
                for (var r = 0; r < e.audioTracks.numTracks; r++) {
                    var n = t.audio[r];
                    var o = e.audioTracks[r];
                    o.setTargeted(n !== null && n !== void 0 ? n : true, true);
                }
                for (var r = 0; r < e.videoTracks.numTracks; r++) {
                    var n = t.video[r];
                    var o = e.videoTracks[r];
                    o.setTargeted(n !== null && n !== void 0 ? n : true, true);
                }
            }
            function g(e, t, r) {
                for (var n = 0; n < e.videoTracks.numTracks; n++) {
                    var o = e.videoTracks[n];
                    o.setTargeted(n >= t, true);
                }
                for (var n = 0; n < e.audioTracks.numTracks; n++) {
                    var o = e.audioTracks[n];
                    o.setTargeted(n >= r, true);
                }
            }
            function j(e) {
                var t = {
                    sequences: {}
                };
                for (var r = 0; r < e.sequences.numSequences; r++) {
                    var n = e.sequences[r];
                    t.sequences[n.sequenceID] = {
                        id: n.sequenceID,
                        name: n.name
                    };
                }
                return t;
            }
            var a = "Import Sequence";
            function k(e, t) {
                var r = null;
                var n = null;
                for (var o in t.sequences) {
                    if (e.sequences[o] != null) continue;
                    if (r == null) {
                        r = o;
                    }
                    if (t.sequences[o].name === a) {
                        n = o;
                    }
                    if (r != null && n != null) break;
                }
                return n !== null && n !== void 0 ? n : r;
            }
            var u = "BE.Project.CreateDupesOnImportPropertyKey";
            function q(e) {
                var t = false;
                if (app.properties.doesPropertyExist(u) && !app.properties.isPropertyReadOnly(u)) {
                    var r = app.properties.getProperty(u);
                    if (r === true || r === "true") {
                        app.properties.setProperty(u, "false", false, false);
                        t = true;
                    }
                }
                try {
                    e();
                } finally {
                    if (t) {
                        app.properties.setProperty(u, "true", false, false);
                    }
                }
            }
            function M(e, t) {
                var r = [];
                for (var n = 0; n < e.videoTracks.numTracks; n++) {
                    var o = e.videoTracks[n];
                    for (var i = 0; i < o.clips.numItems; i++) {
                        r.push(o.clips[i]);
                    }
                }
                if (t) {
                    for (var n = 0; n < e.audioTracks.numTracks; n++) {
                        var o = e.audioTracks[n];
                        for (var i = 0; i < o.clips.numItems; i++) {
                            r.push(o.clips[i]);
                        }
                    }
                }
                return r;
            }
            function A(e) {
                var t = [];
                for (var r = 0; r < e.videoTracks.numTracks; r++) {
                    var n = e.videoTracks[r];
                    for (var o = 0; o < n.clips.numItems; o++) {
                        var i = n.clips[o];
                        if (i.isAdjustmentLayer()) {
                            t.push({
                                trackIndex: r,
                                clipIndex: o,
                                type: b.ClipType.Video
                            });
                        }
                    }
                }
                return t;
            }
            function m(e, t) {
                var r = e[0].trackIndex;
                var n = e[0].clipIndex;
                var o = 0;
                var i = 0;
                for (var a = 0, u = e; a < u.length; a++) {
                    var s = u[a];
                    if (s.trackIndex > r) {
                        o++;
                        i = 0;
                    } else if (s.clipIndex > n) {
                        i++;
                    }
                    if (o === t.trackIndex && i === t.clipIndex) {
                        return s;
                    }
                    r = s.trackIndex;
                    n = s.clipIndex;
                }
                throw new E.Exception("Failed to find clip by relative location");
            }
            function O(e, t) {
                var r = new File(t);
                return (0, s.findBinByName)(r.displayName, e.rootItem);
            }
            function c(e, t) {
                var r = [];
                for (var n = 0; n < e.children.numItems; n++) {
                    r.push(e.children[n]);
                }
                for (var o = 0, i = r; o < i.length; o++) {
                    var a = i[o];
                    if (a.type === ProjectItemType.BIN) {
                        var u = (0, s.findBinByName)(a.name, t);
                        if (u != null) {
                            c(a, u);
                        } else {
                            a.moveBin(t);
                        }
                    } else {
                        a.moveBin(t);
                    }
                }
            }
            function D(e, t) {
                var r = (0, s.findACBin)(t);
                if (r == null) return;
                var n = (0, s.getOrCreateACBin)(e);
                c(r, n);
            }
            function P(e) {
                var t = (0, s.findACBin)(e.rootItem);
                if (t == null) return;
                var r = [];
                for (var n = 0; n < t.children.numItems; n++) {
                    var o = t.children[n];
                    if (!o.isSequence()) continue;
                    var i = (0, h.getSequenceByProjectItem)(e, o);
                    if (i == null) continue;
                    r.push(i);
                }
                for (var a = 0, u = r; a < u.length; a++) {
                    var i = u[a];
                    e.deleteSequence(i);
                }
            }
        },
        580: function(e, t, r) {
            "use strict";
            var n = this && this.__extends || function() {
                var n = function(e, t) {
                    n = Object.setPrototypeOf || {
                        __proto__: []
                    } instanceof Array && function(e, t) {
                        e.__proto__ = t;
                    } || function(e, t) {
                        for (var r in t) if (Object.prototype.hasOwnProperty.call(t, r)) e[r] = t[r];
                    };
                    return n(e, t);
                };
                return function(e, t) {
                    if (typeof t !== "function" && t !== null) throw new TypeError("Class extends value " + String(t) + " is not a constructor or null");
                    n(e, t);
                    function r() {
                        this.constructor = e;
                    }
                    e.prototype = t === null ? Object.create(t) : (r.prototype = t.prototype, 
                    new r());
                };
            }();
            t.__esModule = true;
            t.SoundImporter = void 0;
            var o = r(1009);
            var h = r(5194);
            var v = r(4155);
            var y = r(4530);
            var g = r(5132);
            var m = r(1413);
            var P = r(9008);
            var i = function(e) {
                n(t, e);
                function t() {
                    return e !== null && e.apply(this, arguments) || this;
                }
                t.prototype.insertSound = function(e) {
                    var n = this;
                    var o = e.itemNodeId, i = e.speed, a = e.reverse;
                    var t = this.getImportMeta(o);
                    var r = this.getContext();
                    if (!r) throw new P.UserError("No sequence is currently open");
                    var u = r.project, s = r.sequence;
                    var c = s.getPlayerPosition();
                    var l = t.sourceFileDuration / i;
                    this.executeUndoGroup(r, function() {
                        var e = (0, v.getFreeTracks)(s, c.seconds, l, 0, 1), t = e[1];
                        var r = n.importSound(u, o);
                        n.insertSoundClip(s, r, t, c, i, a);
                    });
                    (0, y.getQESequence)(s).makeCurrent();
                };
                t.prototype.replaceSound = function(e) {
                    var n = this;
                    if (l()) {
                        throw new P.UserError("Current version of Premiere Pro (".concat(app.version, ") contains critical bug for this functionality."));
                    }
                    var o = e.itemNodeId, i = e.speed, a = e.reverse;
                    var t = this.getContext();
                    if (!t) throw new P.UserError("No sequence is currently open");
                    var u = t.project, s = t.sequence;
                    var c = (0, m.getSelectedClips)(s, m.ClipType.Audio);
                    if (c.length === 0) throw new P.UserError("An audio clip must be selected");
                    this.executeUndoGroup(t, function() {
                        var e = c[0];
                        var t = (0, m.getClip)(s, e).start;
                        var r = n.importSound(u, o);
                        (0, m.removeClips)(s, c);
                        n.insertSoundClip(s, r, e.trackIndex, t, i, a);
                    });
                    (0, y.getQESequence)(s).makeCurrent();
                };
                t.prototype.dropSound = function(e) {
                    var a = this;
                    this.checkWrongBricksDrop();
                    var u = e.itemNodeId, s = e.speed, c = e.reverse;
                    this.replacePreviewBricks(function(e) {
                        var t = e.project, r = e.sequence, n = e.audioTrackIndex, o = e.startTime;
                        if (n == null) return;
                        var i = a.importSound(t, u);
                        a.insertSoundClip(r, i, n, o, s, c);
                    });
                };
                t.prototype.openSound = function(e) {
                    var t = e.itemNodeId;
                    var r = this.getImportMeta(t);
                    app.sourceMonitor.openFilePath(r.sourceFilePath);
                };
                t.prototype.importSound = function(e, t) {
                    return this.getProjectAssets(e).importItem(t);
                };
                t.prototype.insertSoundClip = function(e, t, r, n, o, i) {
                    var a;
                    var u = h.SequenceSnapshot.create(e);
                    var s = null;
                    if (o > 1) {
                        a = (0, v.addSequenceTracks)(e, {
                            audioTracks: 1
                        }), s = a[1];
                    }
                    var c = e.audioTracks[s !== null && s !== void 0 ? s : r];
                    c.overwriteClip(t, n);
                    var l = h.SequenceSnapshot.create(e);
                    var p = l.getAddedClips(u);
                    var f = p.getFirstClip(m.ClipType.Audio);
                    if (!f) throw new P.Exception("Failed to find added audio clip");
                    if (o != 1 || i) {
                        (0, g.setAudioClipSpeed)(e, f.location, o, i);
                    }
                    if (s != null) {
                        var d = (0, m.getQEClip)(e, f.location);
                        d.moveToTrack(0, r - s, "");
                        (0, y.getQESequence)(e).removeAudioTrack(s);
                    }
                };
                t.prototype.getImportMeta = function(e) {
                    return this.externalObject.getItemImportMeta(e);
                };
                return t;
            }(o.Importer);
            t.SoundImporter = i;
            function l() {
                return app.version === "24.2.1";
            }
        },
        9921: function(e, t, r) {
            "use strict";
            t.__esModule = true;
            t.EditorImpl = void 0;
            var a = r(3745);
            var u = r(3547);
            var n = r(4965);
            var o = function() {
                function e(e) {
                    this.editor = e;
                }
                e.prototype.getSerializedState = function() {
                    return this.editor.getSerializedState();
                };
                e.prototype.getPropertyValues = function() {
                    return this.editor.getPropertyValues();
                };
                e.prototype.setPropertyValue = function(e, t, r, n) {
                    var o = this;
                    u.globalLock.require(function() {
                        if (n != null) {
                            o.editor.startUndoGroup(n);
                        }
                        (0, a.settleSync)(o.editor.setPropertyValue(e, t, r));
                    });
                };
                e.prototype.resetPropertyValue = function(e) {
                    var t = this;
                    u.globalLock.require(function() {
                        (0, a.settleSync)(t.editor.resetPropertyValue(e));
                    });
                };
                e.prototype.callPropertyAction = function(e, t, r, n) {
                    var o = this;
                    var i;
                    u.globalLock.require(function() {
                        if (n != null) {
                            o.editor.startUndoGroup(n);
                        }
                        i = (0, a.settleSync)(o.editor.callPropertyAction(e, t, r));
                    });
                    return i;
                };
                e.prototype.getCaptionClipInfo = function(e) {
                    return this.editor.getCaptionClipInfo(e);
                };
                e.prototype.getRawCaptionClipData = function(e) {
                    var t = this.editor.getCaptionClipData(e);
                    return (0, n.serializeCaptionClipData)(t);
                };
                e.prototype.updateCaptionClipData = function(e, t) {
                    var r = this;
                    u.globalLock.require(function() {
                        (0, a.settleSync)(r.editor.updateCaptionClipData(e, t));
                    });
                };
                e.prototype.saveUserPalette = function(e, t) {
                    (0, a.settleSync)(this.editor.saveUserPalette(e, t));
                };
                e.prototype.removeUserPalette = function(e) {
                    (0, a.settleSync)(this.editor.removeUserPalette(e));
                };
                e.prototype.endUndoGroup = function(e) {
                    this.editor.endUndoGroup(e);
                };
                e.prototype.undo = function() {
                    var e = this;
                    u.globalLock.require(function() {
                        e.editor.undo();
                    });
                };
                e.prototype.fixCorruptedClips = function() {
                    var e = this;
                    u.globalLock.require(function() {
                        e.editor.fixCorruptedClips();
                    });
                };
                e.prototype.togglePlay = function() {
                    var e = this;
                    u.globalLock.require(function() {
                        e.editor.togglePlay();
                    });
                };
                return e;
            }();
            t.EditorImpl = o;
        },
        4628: function(e, t, r) {
            "use strict";
            t.__esModule = true;
            t.ImportsImpl = void 0;
            var n = r(3840);
            var o = r(580);
            var i = r(2184);
            var a = r(4406);
            var u = r(870);
            var s = r(9144);
            var c = r(987);
            var l = r(3547);
            var p = r(4965);
            var f = function() {
                function e(e, t, r, n, o) {
                    this.externalObject = e;
                    this.supportFiles = t;
                    this.graphics = r;
                    this.undo = n;
                    this.transcriber = o;
                    this.preview = new c.Preview(this.externalObject);
                }
                e.prototype.insertMogrt = function(e) {
                    var t = this;
                    l.globalLock.require(function() {
                        new n.MogrtImporter(t.graphics, t.externalObject, t.supportFiles, t.undo).insertMogrt(e);
                    });
                };
                e.prototype.replaceMogrt = function(e) {
                    var t = this;
                    l.globalLock.require(function() {
                        new n.MogrtImporter(t.graphics, t.externalObject, t.supportFiles, t.undo).replaceMogrt(e);
                    });
                };
                e.prototype.dropMogrt = function(e) {
                    var t = this;
                    l.globalLock.require(function() {
                        new n.MogrtImporter(t.graphics, t.externalObject, t.supportFiles, t.undo).dropMogrt(e);
                    });
                };
                e.prototype.insertSound = function(e) {
                    var t = this;
                    l.globalLock.require(function() {
                        new o.SoundImporter(t.externalObject, t.supportFiles, t.undo).insertSound(e);
                    });
                };
                e.prototype.replaceSound = function(e) {
                    var t = this;
                    l.globalLock.require(function() {
                        new o.SoundImporter(t.externalObject, t.supportFiles, t.undo).replaceSound(e);
                    });
                };
                e.prototype.dropSound = function(e) {
                    var t = this;
                    l.globalLock.require(function() {
                        new o.SoundImporter(t.externalObject, t.supportFiles, t.undo).dropSound(e);
                    });
                };
                e.prototype.openSound = function(e) {
                    var t = this;
                    l.globalLock.require(function() {
                        new o.SoundImporter(t.externalObject, t.supportFiles, t.undo).openSound(e);
                    });
                };
                e.prototype.insertFootageFile = function(e) {
                    var t = this;
                    l.globalLock.require(function() {
                        new i.FootageImporter(t.externalObject, t.supportFiles, t.undo).insertFootageFile(e);
                    });
                };
                e.prototype.dropFootageFile = function(e) {
                    var t = this;
                    l.globalLock.require(function() {
                        new i.FootageImporter(t.externalObject, t.supportFiles, t.undo).dropFootageFile(e);
                    });
                };
                e.prototype.openFootageFile = function(e) {
                    var t = this;
                    l.globalLock.require(function() {
                        new i.FootageImporter(t.externalObject, t.supportFiles, t.undo).openFootageFile(e);
                    });
                };
                e.prototype.insertSequence = function(e) {
                    var t = this;
                    l.globalLock.require(function() {
                        new a.SequenceImporter(t.externalObject, t.supportFiles, t.undo).insertSequence(e);
                    });
                };
                e.prototype.dropSequence = function(e) {
                    var t = this;
                    l.globalLock.require(function() {
                        new a.SequenceImporter(t.externalObject, t.supportFiles, t.undo).dropSequence(e);
                    });
                };
                e.prototype.insertAnimatedFont = function(e) {
                    var t = this;
                    l.globalLock.require(function() {
                        new u.FontImporter(t.externalObject, t.supportFiles, t.undo).insertFont(e);
                    });
                };
                e.prototype.captions = function() {
                    return new s.CaptionsImporter(this.externalObject, this.supportFiles, this.undo, this.graphics, this.transcriber);
                };
                e.prototype.getCaptionTemplateInfo = function(e) {
                    return this.captions().getCaptionTemplateInfo(e);
                };
                e.prototype.getReplacedCaptionInfo = function() {
                    return this.captions().getReplacedClipInfo();
                };
                e.prototype.getRawReplacedCaptionData = function() {
                    return (0, p.serializeCaptionClipData)(this.captions().getReplacedClipData());
                };
                e.prototype.prepareCaptions = function(e) {
                    var t = this;
                    l.globalLock.require(function() {
                        return t.captions().prepareCaptions(e);
                    });
                };
                e.prototype.finishCaptions = function(e) {
                    var t = this;
                    l.globalLock.require(function() {
                        return t.captions().finishCaptions(e);
                    });
                };
                e.prototype.cleanCaptions = function(e) {
                    var t = this;
                    l.globalLock.require(function() {
                        return t.captions().cleanCaptions(e);
                    });
                };
                e.prototype.replaceCaptions = function(e) {
                    var t = this;
                    l.globalLock.require(function() {
                        return t.captions().replaceCaptions(e);
                    });
                };
                e.prototype.getSoundPreviewFiles = function(e) {
                    return this.preview.getSoundPreviewFiles(e);
                };
                e.prototype.getMogrtPreviewFiles = function(e) {
                    return this.preview.getMogrtPreviewFiles(e);
                };
                e.prototype.getFootagePreviewFiles = function(e) {
                    return this.preview.getFootagePreviewFiles(e);
                };
                e.prototype.getSequencePreviewFiles = function(e) {
                    return this.preview.getSequencePreviewFiles(e);
                };
                return e;
            }();
            t.ImportsImpl = f;
        },
        6721: function(e, t, r) {
            "use strict";
            t.__esModule = true;
            t.SettingsImpl = void 0;
            var n = r(3391);
            var o = function() {
                function e(e, t) {
                    this.presets = e;
                    this.palettes = t;
                }
                e.prototype.createMigrator = function() {
                    return new n.SettingsMigrator(this.presets, this.palettes);
                };
                e.prototype.migratePreset = function(e) {
                    this.createMigrator().migratePreset(e.preset);
                };
                e.prototype.migratePalette = function(e) {
                    this.createMigrator().migratePalette(e.group, e.palette);
                };
                return e;
            }();
            t.SettingsImpl = o;
        },
        3547: function(e, t, r) {
            "use strict";
            t.__esModule = true;
            t.globalLock = void 0;
            var n = r(9008);
            var o = function() {
                function e() {
                    this.locked = false;
                    this.waiting = [];
                }
                e.prototype.wait = function(e) {
                    if (this.locked) {
                        this.waiting.push(e);
                        return false;
                    } else {
                        this.execute(e);
                        return true;
                    }
                };
                e.prototype["try"] = function(e) {
                    if (this.locked) {
                        return false;
                    } else {
                        this.execute(e);
                        return true;
                    }
                };
                e.prototype.require = function(e) {
                    if (!this["try"](e)) {
                        throw new n.Exception("Unable to acquire lock");
                    }
                };
                e.prototype.execute = function(e) {
                    this.locked = true;
                    var t;
                    var r = false;
                    try {
                        e();
                    } catch (e) {
                        t = e;
                        r = true;
                    }
                    try {
                        this.flush();
                    } catch (e) {
                        if (!r) throw e;
                    }
                    if (r) throw t;
                };
                e.prototype.flush = function() {
                    var t;
                    var r = false;
                    try {
                        while (this.waiting.length > 0) {
                            var e = 0;
                            for (;e < this.waiting.length; e++) {
                                try {
                                    this.waiting[e]();
                                } catch (e) {
                                    if (!r) {
                                        t = e;
                                        r = true;
                                    }
                                }
                            }
                            this.waiting.splice(0, e);
                        }
                    } finally {
                        this.locked = false;
                    }
                    if (r) throw t;
                };
                return e;
            }();
            t.globalLock = new o();
        },
        1091: function(e, t, r) {
            "use strict";
            var n = this && this.__extends || function() {
                var n = function(e, t) {
                    n = Object.setPrototypeOf || {
                        __proto__: []
                    } instanceof Array && function(e, t) {
                        e.__proto__ = t;
                    } || function(e, t) {
                        for (var r in t) if (Object.prototype.hasOwnProperty.call(t, r)) e[r] = t[r];
                    };
                    return n(e, t);
                };
                return function(e, t) {
                    if (typeof t !== "function" && t !== null) throw new TypeError("Class extends value " + String(t) + " is not a constructor or null");
                    n(e, t);
                    function r() {
                        this.constructor = e;
                    }
                    e.prototype = t === null ? Object.create(t) : (r.prototype = t.prototype, 
                    new r());
                };
            }();
            t.__esModule = true;
            t.BrowserPlugin = void 0;
            var o = r(5842);
            var i = r(8537);
            var a = r(1955);
            var u = r(4628);
            var s = r(2613);
            var c = r(9401);
            var l = r(6374);
            var p = r(6265);
            var f = r(4442);
            var d = r(3284);
            var h = r(9921);
            var v = r(6721);
            var y = r(3745);
            var g = r(3325);
            var m = function(t) {
                n(e, t);
                function e() {
                    var e = t !== null && t.apply(this, arguments) || this;
                    e.externalObject = new a.PCExternalObject(e.supportFiles);
                    e.undoStackManager = new l.UndoStackManager();
                    e.graphicParams = new p.GraphicParams(e.externalObject);
                    e.paletteStorage = new f.UserPaletteStorage(e.externalObject);
                    e.presetStorage = new d.UserPresetStorage(e.externalObject);
                    e.transcriber = new g.Transcriber(e.externalObject);
                    e.editorManager = new c.EditorManager(e.externalObject, e.graphicParams, e.undoStackManager, e.paletteStorage, e.presetStorage);
                    e.events = new s.AppEvents(e.editorManager, e.undoStackManager);
                    e.raw = {
                        imports: new u.ImportsImpl(e.externalObject, e.supportFiles, e.graphicParams, e.undoStackManager, e.transcriber),
                        editor: new h.EditorImpl(e.editorManager),
                        settings: new v.SettingsImpl(e.presetStorage, e.paletteStorage)
                    };
                    e.imports = (0, i.wrapApiImplementation)(e.raw.imports);
                    e.editor = (0, i.wrapApiImplementation)(e.raw.editor);
                    e.settings = (0, i.wrapApiImplementation)(e.raw.settings);
                    return e;
                }
                e.prototype.initPlugin = function() {
                    app.enableQE();
                    this.externalObject.load();
                    this.externalObject.checkDependencies();
                    this.events.subscribe();
                    (0, y.settleSync)(this.editorManager.updateSelectionEditor());
                };
                e.prototype.destroy = function() {
                    t.prototype.destroy.call(this);
                    this.events.unsubscribe();
                };
                return e;
            }(o.Plugin);
            t.BrowserPlugin = m;
        },
        3391: function(e, t, r) {
            "use strict";
            t.__esModule = true;
            t.SettingsMigrator = void 0;
            var a = r(5521);
            var i = r(9388);
            var u = r(6373);
            var s = r(3038);
            var c = r(2722);
            var l = r(2037);
            var n = function() {
                function e(e, t) {
                    this.presets = e;
                    this.palettes = t;
                }
                e.prototype.migratePreset = function(e) {
                    var t = this.createPreset(e);
                    if (t == null) return;
                    var r = this.presets.getPresets();
                    for (var n = 0, o = r; n < o.length; n++) {
                        var i = o[n];
                        if (i.getName() !== t.getName()) continue;
                        var a = i.matchTree(t.getSerializedTree());
                        if (a.structure && a.values) return;
                    }
                    this.presets.savePreset(t);
                };
                e.prototype.createPreset = function(e) {
                    var t = new s.SerializedTreeBuilder();
                    for (var r in e.values) {
                        var n = e.values[r];
                        t.addLegacyProperty(r, n);
                    }
                    var o = (0, a.nanoid)();
                    var i = t.buildTree();
                    if (i == null) return;
                    return new u.TreePreset(o, e.name, e.mogrtFilename, i);
                };
                e.prototype.migratePalette = function(e, t) {
                    var r = this.createPalette(e, t);
                    if (r == null) return;
                    var n = this.palettes.getPalettes(e, []);
                    for (var o = 0, i = n.user; o < i.length; o++) {
                        var a = i[o];
                        if (a.getName() === r.getName() && a.getColors().isEqual(r.getColors())) {
                            return;
                        }
                    }
                    this.palettes.addUserPalette(r);
                };
                e.prototype.createPalette = function(e, t) {
                    var r = (0, a.nanoid)();
                    var n = this.getPaletteColorNames(e);
                    if (n == null || n.length !== t.colors.length) return;
                    var o = new c.ColorMap((0, i.map)(t.colors, function(e, t) {
                        return [ n[t], (0, l.hexStringToColor)(e) ];
                    }));
                    return new c.Palette(r, t.name, e, o);
                };
                e.prototype.getPaletteColorNames = function(e) {
                    var t = this.palettes.getPalettes(e, []);
                    var r = t.product.length > 0 ? t.product[0] : null;
                    if (r == null) return null;
                    var n = r.getColors().getEntries();
                    return (0, i.map)(n, function(e) {
                        var t = e[0];
                        return t;
                    });
                };
                return e;
            }();
            t.SettingsMigrator = n;
        },
        3038: function(e, t, r) {
            "use strict";
            var n = this && this.__spreadArray || function(e, t, r) {
                if (r || arguments.length === 2) for (var n = 0, o = t.length, i; n < o; n++) {
                    if (i || !(n in t)) {
                        if (!i) i = Array.prototype.slice.call(t, 0, n);
                        i[n] = t[n];
                    }
                }
                return e.concat(i || Array.prototype.slice.call(t));
            };
            var o, i;
            t.__esModule = true;
            t.SerializedTreeBuilder = void 0;
            var a = r(3285);
            var u = r(2037);
            var s = r(9388);
            var c = r(5802);
            var l = function() {
                function e() {
                    this.section = {
                        name: "Precomp Settings",
                        type: g.section
                    };
                }
                e.prototype.addLegacyProperty = function(e, t) {
                    var r = p(e);
                    if (r == null) return;
                    if (r.type === h.Text) {
                        this.addTextGroup(r, t);
                    } else if (r.type === h.GroupWithCheckbox) {
                        this.addCheckboxGroup(r, t);
                    } else {
                        this.addProperty(r, t);
                    }
                };
                e.prototype.isEmpty = function() {
                    var e;
                    var t = (e = this.section.children) !== null && e !== void 0 ? e : [];
                    return t.length === 0;
                };
                e.prototype.buildTree = function() {
                    if (this.isEmpty()) return null;
                    this.combineColorGroups();
                    this.combineTextProperties();
                    return {
                        name: "",
                        type: g.root,
                        children: [ this.section ]
                    };
                };
                e.prototype.getParentNode = function(e) {
                    var r;
                    var n = this.section;
                    var t = function(t) {
                        var e = (0, s.find)((r = n.children) !== null && r !== void 0 ? r : [], function(e) {
                            return e.name === t;
                        });
                        if (e == null) {
                            e = {
                                name: t,
                                type: g.group
                            };
                            m(n, e);
                        }
                        n = e;
                    };
                    for (var o = 0, i = e; o < i.length; o++) {
                        var a = i[o];
                        t(a);
                    }
                    return n;
                };
                e.prototype.addProperty = function(e, t) {
                    var r = this.getParentNode(e.path);
                    var n = f(e.type, t);
                    var o = v[e.type];
                    if (o == null) return;
                    m(r, {
                        name: e.name,
                        type: g.property,
                        valDef: o,
                        value: n
                    });
                };
                e.prototype.addTextGroup = function(e, t) {
                    var r = this.getParentNode(e.path);
                    m(r, d(e.name, t));
                };
                e.prototype.addCheckboxGroup = function(e, t) {
                    var r = this.getParentNode(n(n([], e.path, true), [ e.name ], false));
                    r.valDef = v[h.GroupWithCheckbox];
                    r.value = t;
                };
                e.prototype.combineColorGroups = function() {
                    function c(e) {
                        var t;
                        if (e.type === g.colorGroup) return;
                        var r = (t = e.children) !== null && t !== void 0 ? t : [];
                        for (var n = 0; n < r.length; n++) {
                            var o = r[n];
                            if (o.valDef === "Color") {
                                var i = r[n + 1];
                                if (i == null) continue;
                                var a = "".concat(o.name, " Enabled");
                                var u = "".concat(o.name, " Opacity");
                                if (i.name === u || i.name === a) {
                                    var s = {
                                        name: o.name,
                                        type: g.colorGroup,
                                        children: [ o, i ]
                                    };
                                    r.splice(n, 2, s);
                                }
                            } else {
                                c(o);
                            }
                        }
                    }
                    c(this.section);
                };
                e.prototype.combineTextProperties = function() {
                    var p = [ "Auto Leading", "Leading", "Tracking", "Paragraph" ];
                    function f(e) {
                        var t, r;
                        var n = (r = (t = e.children) === null || t === void 0 ? void 0 : t.slice()) !== null && r !== void 0 ? r : [];
                        for (var o = 0, i = n; o < i.length; o++) {
                            var a = i[o];
                            if (a.type === g.text) {
                                for (var u = 0, s = p; u < s.length; u++) {
                                    var c = s[u];
                                    var l = C(e, "Text Properties - ".concat(a.name, " - ").concat(c));
                                    if (l == null) continue;
                                    P(e, l);
                                    m(a, l);
                                    l.name = c;
                                }
                            } else {
                                f(a);
                            }
                        }
                    }
                    f(this.section);
                };
                return e;
            }();
            t.SerializedTreeBuilder = l;
            function p(e) {
                var t;
                var r = (t = /^(\d+)([23]D.+)$/.exec(e)) !== null && t !== void 0 ? t : /^(\d+)(.+)$/.exec(e);
                if (r == null) return null;
                var n = r[1];
                var o = r[2].split(">>>");
                var i = o[o.length - 1];
                var a = o.slice(0, -1);
                return {
                    type: n,
                    name: i,
                    path: a
                };
            }
            function f(e, t) {
                switch (e) {
                  case h.Point2D:
                  case h.Point2DExt:
                    return [ t.x, t.y ];

                  case h.Color:
                    return (0, u.hexStringToColor)(t);

                  case h.Dropdown:
                    return t + 1;

                  default:
                    return t;
                }
            }
            function d(e, t) {
                var r = [];
                var n = {
                    name: e,
                    type: g.text,
                    children: r
                };
                r.push({
                    name: e,
                    type: g.property,
                    valDef: "Text",
                    value: (0, a.getEditText)(t)
                });
                if ((0, a.isFontFamilyEditable)(t)) {
                    r.push({
                        name: "Font",
                        type: g.property,
                        valDef: "Font",
                        value: (0, a.getFontFamily)(t)
                    });
                }
                if ((0, a.isFontSizeEditable)(t)) {
                    r.push({
                        name: "Font Size",
                        type: g.property,
                        valDef: "Slider",
                        value: (0, a.getFontSize)(t)
                    });
                }
                if ((0, a.isStyleEditable)(t)) {
                    var o = (0, a.getFontFauxVariant)(t);
                    r.push({
                        name: "Bold",
                        type: g.property,
                        valDef: "Checkbox",
                        value: (0, a.isFontFauxBold)(t)
                    }, {
                        name: "Italic",
                        type: g.property,
                        valDef: "Checkbox",
                        value: (0, a.isFontFauxItalic)(t)
                    }, {
                        name: "Variant",
                        type: g.property,
                        valDef: "Dropdown",
                        value: y[o]
                    });
                }
                return n;
            }
            var h;
            (function(e) {
                e["Checkbox"] = "1";
                e["Slider"] = "2";
                e["Angle"] = "3";
                e["Color"] = "4";
                e["Point2D"] = "5";
                e["Text"] = "6";
                e["Point2DExt"] = "9";
                e["Dropdown"] = "13";
                e["TimeTransitionInSpeed"] = "999902";
                e["TimeTransitionOutSpeed"] = "999903";
                e["GroupWithCheckbox"] = "999904";
            })(h || (h = {}));
            var v = (o = {}, o[h.Checkbox] = "Checkbox", o[h.Slider] = "Slider", 
            o[h.Angle] = "Angle", o[h.Color] = "Color", o[h.Point2D] = "Point", 
            o[h.Point2DExt] = "Point", o[h.Dropdown] = "Dropdown", o[h.TimeTransitionInSpeed] = "Slider", 
            o[h.TimeTransitionOutSpeed] = "Slider", o[h.GroupWithCheckbox] = "Checkbox", 
            o);
            var y = (i = {}, i[a.FontVariant.normal] = 1, i[a.FontVariant.allCaps] = 2, 
            i[a.FontVariant.smallCaps] = 3, i);
            var g = {
                root: (0, c.serializeNodeType)(c.PropertyTreeNodeType.Root),
                section: (0, c.serializeNodeType)(c.PropertyTreeNodeType.Section),
                group: (0, c.serializeNodeType)(c.PropertyTreeNodeType.Group),
                property: (0, c.serializeNodeType)(c.PropertyTreeNodeType.Property),
                text: (0, c.serializeNodeType)(c.PropertyTreeNodeType.TextPropertiesGroup),
                colorGroup: (0, c.serializeNodeType)(c.PropertyTreeNodeType.ColorGroup)
            };
            function m(e, t) {
                if (e.children == null) {
                    e.children = [ t ];
                } else {
                    e.children.push(t);
                }
            }
            function P(e, t) {
                if (e.children == null) return;
                e.children = (0, s.filter)(e.children, function(e) {
                    return e !== t;
                });
            }
            function C(e, t) {
                return e.children ? (0, s.find)(e.children, function(e) {
                    return e.name === t;
                }) : undefined;
            }
        },
        4442: function(e, t, r) {
            "use strict";
            t.__esModule = true;
            t.UserPaletteStorage = void 0;
            var n = r(2722);
            var o = function() {
                function e(e) {
                    this.externalObject = e;
                }
                e.prototype.getPalettes = function(e, t) {
                    var r = this.externalObject.getPalettes(e, t), n = r.predefined, o = r.user, i = r.similar;
                    return {
                        user: a(o),
                        product: a(n),
                        similar: a(i)
                    };
                };
                e.prototype.addUserPalette = function(e) {
                    this.externalObject.savePalette(u(e));
                };
                e.prototype.removeUserPalette = function(e) {
                    this.externalObject.deletePalette(e);
                };
                return e;
            }();
            t.UserPaletteStorage = o;
            function a(e) {
                var t = [];
                for (var r = 0, n = e; r < n.length; r++) {
                    var o = n[r];
                    t.push(i(o));
                }
                return t;
            }
            function i(e) {
                var t = [];
                for (var r in e.colors) {
                    t.push([ r, e.colors[r] ]);
                }
                return new n.Palette(e.id, e.name, e.groupId, new n.ColorMap(t));
            }
            function u(e) {
                var t = {};
                for (var r = 0, n = e.getColors().getEntries(); r < n.length; r++) {
                    var o = n[r], i = o[0], a = o[1];
                    t[i] = a;
                }
                return {
                    name: e.getName(),
                    groupId: e.getGroupId(),
                    colors: t
                };
            }
        },
        3284: function(e, t, r) {
            "use strict";
            t.__esModule = true;
            t.UserPresetStorage = void 0;
            var n = r(6373);
            var o = function() {
                function e(e) {
                    this.externalObject = e;
                }
                e.prototype.getPresets = function() {
                    var e = this.externalObject.getPropertyTreePresets();
                    return i(e);
                };
                e.prototype.savePreset = function(e) {
                    var t = u(e);
                    this.externalObject.savePropertyTreePreset(t);
                };
                e.prototype.deletePreset = function(e) {
                    this.externalObject.deletePropertyTreePreset(e);
                };
                e.prototype.deleteAllPresets = function() {
                    var e = this.externalObject.getPropertyTreePresets();
                    for (var t = 0, r = e; t < r.length; t++) {
                        var n = r[t];
                        this.externalObject.deletePropertyTreePreset(n.id);
                    }
                };
                return e;
            }();
            t.UserPresetStorage = o;
            function i(e) {
                var t = [];
                for (var r = 0, n = e; r < n.length; r++) {
                    var o = n[r];
                    t.push(a(o));
                }
                return t;
            }
            function a(e) {
                var t = e.value;
                return new n.TreePreset(e.id, t.name, t.mogrtName, t.tree);
            }
            function u(e) {
                return {
                    id: e.getId(),
                    value: {
                        name: e.getName(),
                        mogrtName: e.getMogrtName(),
                        tree: e.getSerializedTree()
                    }
                };
            }
        },
        3325: function(e, t) {
            "use strict";
            t.__esModule = true;
            t.Transcriber = void 0;
            var r = function() {
                function e(e) {
                    this.externalObject = e;
                }
                e.prototype.transcribeSource = function(e, t, r, n) {
                    this.externalObject.transcribeSource(e, t, r, n);
                };
                e.prototype.requestTranscript = function(e, t, r) {
                    this.externalObject.requestTranscript(e, t, r);
                };
                e.prototype.releaseTranscript = function(e) {
                    return this.externalObject.releaseTranscript(e);
                };
                e.prototype.updateLayout = function(e, t) {
                    return this.externalObject.updateTranscriptLayout(e, t);
                };
                return e;
            }();
            t.Transcriber = r;
        },
        6374: function(e, t, r) {
            "use strict";
            t.__esModule = true;
            t.UndoStackManager = void 0;
            var i = r(9008);
            var n = r(4666);
            var o = function() {
                function e() {
                    this.projects = {};
                }
                e.prototype.updateProject = function(e) {
                    this.getUndoStack(e).updateProject();
                };
                e.prototype.closeProject = function(e) {
                    delete this.projects[e];
                };
                e.prototype.startUndoGroup = function(e) {
                    this.getUndoStack(e).startUndoGroup();
                };
                e.prototype.endUndoGroup = function(e) {
                    this.getUndoStack(e).endUndoGroup();
                };
                e.prototype.abortUndoGroup = function(e) {
                    this.getUndoStack(e).abortUndoGroup();
                };
                e.prototype.executeUndoGroup = function(t, e) {
                    this.startUndoGroup(t);
                    try {
                        e();
                    } catch (e) {
                        this.abortUndoGroup(t);
                        throw e;
                    }
                    this.endUndoGroup(t);
                };
                e.prototype.preventRedo = function(e) {
                    this.getUndoStack(e).preventRedo();
                };
                e.prototype.getTempBin = function(e) {
                    return this.getUndoStack(e).getTempBin();
                };
                e.prototype.getUndoStack = function(e) {
                    if (this.projects[e] == null) {
                        this.projects[e] = new a(e);
                    }
                    return this.projects[e];
                };
                return e;
            }();
            t.UndoStackManager = o;
            var a = function() {
                function e(e) {
                    this.undoGroups = [];
                    this.currentIndex = null;
                    this.tempBin = null;
                    this.projectId = e;
                }
                e.prototype.startUndoGroup = function() {
                    if (this.currentIndex !== null) {
                        this.currentIndex = null;
                        throw new i.Exception("An undo group has been left open by a previous operation. Press OK to fix this.");
                    }
                    this.createTempBin();
                    this.currentIndex = this.getUndoStackIndex();
                };
                e.prototype.endUndoGroup = function() {
                    if (this.currentIndex === null) {
                        throw new i.Exception("No undo group has been started.");
                    }
                    this.checkCurrentProject();
                    var e = this.getUndoStackIndex();
                    this.undoGroups.push({
                        startIndex: this.currentIndex,
                        endIndex: e
                    });
                    if (this.undoGroups.length > 32) {
                        this.undoGroups = this.undoGroups.slice(-32);
                    }
                    this.removeTempBin();
                    this.currentIndex = null;
                };
                e.prototype.abortUndoGroup = function() {
                    if (this.currentIndex === null) return;
                    var e = this.getQeProject();
                    for (var t = 0; t < 32; t++) {
                        if (e.undoStackIndex() < this.currentIndex) break;
                        e.undo();
                    }
                    this.currentIndex = null;
                    this.preventRedo();
                };
                e.prototype.updateProject = function() {
                    if (this.currentIndex !== null) return;
                    var e = this.getQeProject();
                    var t = e.undoStackIndex();
                    var r = 0;
                    for (var n = 0; n < this.undoGroups.length; n++) {
                        var o = this.undoGroups[n];
                        if (t >= o.startIndex && t <= o.endIndex) {
                            if (t - o.startIndex < o.endIndex - t) {
                                while (e.undoStackIndex() <= o.endIndex) {
                                    e.redo();
                                    if (++r > 32) break;
                                }
                            } else {
                                while (e.undoStackIndex() >= o.startIndex) {
                                    e.undo();
                                    if (++r > 32) break;
                                }
                            }
                        }
                        if (r > 32) break;
                    }
                    if (r > 32) {
                        this.undoGroups = [];
                        this.currentIndex = null;
                        throw new i.Exception("A fatal error has occurred in undo groups - discarding them to prevent further errors.");
                    }
                };
                e.prototype.preventRedo = function() {
                    var e = (0, n.getOrCreateACBin)(app.project);
                    e.renameBin(e.name);
                    var t = this.getQeProject();
                    t.undo();
                };
                e.prototype.getTempBin = function() {
                    return this.tempBin;
                };
                e.prototype.createTempBin = function() {
                    var e = new Date().getTime();
                    var t = (0, n.getOrCreateACBin)(this.getProject());
                    this.tempBin = t.createBin("MH_UNDO_".concat(e));
                    this.getQeProject().undo();
                };
                e.prototype.removeTempBin = function() {
                    var e;
                    (e = this.tempBin) === null || e === void 0 ? void 0 : e.deleteBin();
                    this.tempBin = null;
                };
                e.prototype.getUndoStackIndex = function() {
                    var e = this.getQeProject();
                    e.init();
                    return e.undoStackIndex();
                };
                e.prototype.checkCurrentProject = function() {
                    if (app.project.documentID != this.projectId) {
                        this.currentIndex = null;
                        this.removeTempBin();
                        throw new i.Exception("The project has changed during undo group creation, aborting undo group.");
                    }
                };
                e.prototype.getQeProject = function() {
                    return (0, n.getQEProject)(this.getProject(), true);
                };
                e.prototype.getProject = function() {
                    var e = (0, n.getProjectById)(this.projectId);
                    if (e == null) throw new i.Exception("History project does not exist");
                    return e;
                };
                return e;
            }();
        },
        1137: function(e, t, r) {
            "use strict";
            t.__esModule = true;
            t.getCaptionProperties = void 0;
            var l = r(9008);
            function n(e) {
                var t = [];
                var r = [];
                var n = null;
                var o = e.getMGTComponent();
                for (var i = 0; i < o.properties.numItems; i++) {
                    var a = o.properties[i];
                    var u = void 0;
                    if (a.displayName === "Editor hash") {
                        n = {
                            property: a,
                            propertyIndex: i,
                            chunkIndex: 0
                        };
                    } else if (u = /(Caption|Editor) data (\d+)/.exec(a.displayName)) {
                        var s = parseInt(u[2], 10) - 1;
                        var c = {
                            propertyIndex: i,
                            chunkIndex: s,
                            property: a
                        };
                        if (u[1] === "Caption") {
                            t.push(c);
                        } else {
                            r.push(c);
                        }
                    }
                }
                if (n == null) {
                    throw new l.Exception("Hash data property not found");
                }
                if (t.length === 0) {
                    throw new l.Exception("Caption data properties not found");
                }
                if (r.length === 0) {
                    throw new l.Exception("Editor data properties not found");
                }
                t.sort(function(e, t) {
                    return e.chunkIndex - t.chunkIndex;
                });
                r.sort(function(e, t) {
                    return e.chunkIndex - t.chunkIndex;
                });
                return {
                    hash: n,
                    caption: t,
                    editor: r
                };
            }
            t.getCaptionProperties = n;
        },
        5132: function(e, t, r) {
            "use strict";
            t.__esModule = true;
            t.findFirstClip = t.isMHAdjustmentClip = t.scaleClipsToCanvas = t.scaleAdjustmentLayersToCanvas = t.setAudioClipSpeed = t.getClipSize = t.selectClips = t.selectClip = t.getLinkedAudioClip = void 0;
            var h = r(1413);
            var v = r(4530);
            var o = r(9008);
            var i = r(4425);
            function n(e) {
                var t = e.getLinkedItems();
                for (var r = 0; r < t.numItems; r++) {
                    var n = t[r];
                    if ((0, h.isClipType)(n, h.ClipType.Audio)) {
                        return n;
                    }
                }
                return null;
            }
            t.getLinkedAudioClip = n;
            function a(e, t) {
                var r = [];
                var n = t.getLinkedItems();
                if (n) {
                    for (var o = 0; o < n.numItems; o++) {
                        var i = n[o];
                        r.push(i);
                    }
                } else {
                    r.push(t);
                }
                e.setSelection(r);
            }
            t.selectClip = a;
            function u(e, t) {
                var r = [];
                for (var n = 0, o = t; n < o.length; n++) {
                    var i = o[n];
                    r.push((0, h.getClip)(e, i));
                }
                e.setSelection(r);
            }
            t.selectClips = u;
            function s(e) {
                try {
                    var t = e.getProjectItem();
                    if (t == null || t.clip == null) throw new o.Exception("QE clip has no project item");
                    return [ t.clip.videoFrameWidth, t.clip.videoFrameHeight ];
                } catch (e) {
                    return [ 3840, 2160 ];
                }
            }
            t.getClipSize = s;
            function c(e, t, r, n) {
                var o = (0, h.getQEClip)(e, t);
                o.setSpeed(r, "", n, false, false);
                if (r !== 1) {
                    o.setSpeed(r, "00;30;00;00", n, false, false);
                }
            }
            t.setAudioClipSpeed = c;
            function y(e, t) {
                var r = e[0] / t[0];
                var n = e[1] / t[1];
                var o = Math.min(r, n);
                var i = Math.max(r, n);
                return [ o, i ];
            }
            function l(e, t) {
                var r = e.components;
                for (var n = 0; n < r.numItems; n++) {
                    if (r[n].matchName !== "AE.ADBE Shape") continue;
                    r[n].properties[4].setValue(t * 100, true);
                    r[n].properties[5].setValue(t * 100, true);
                    return;
                }
                throw new o.Exception("No shape component found in clip");
            }
            function p(e) {
                var t = e.components;
                for (var r = 0; r < t.numItems; r++) {
                    if (t[r].matchName !== "AE.ADBE Motion") continue;
                    return t[r].properties[1];
                }
                throw new o.Exception("No motion component found in clip");
            }
            function g(e) {
                var t = p(e);
                return t.getValue() / 100;
            }
            function m(e, t) {
                var r = p(e);
                r.setValue(t * 100, true);
            }
            var f = [ 1920, 1080 ];
            function d(e, t) {
                var r = (0, v.getSequenceFrameSize)(e);
                for (var n = 0, o = t; n < o.length; n++) {
                    var i = o[n];
                    var a = void 0;
                    try {
                        a = (0, h.getClip)(e, i);
                    } catch (e) {
                        continue;
                    }
                    if (!x(a)) continue;
                    var u = y(r, f), s = u[0], c = u[1];
                    try {
                        l(a, c);
                    } catch (e) {
                        m(a, c / s);
                    }
                }
            }
            t.scaleAdjustmentLayersToCanvas = d;
            function P(e, t, r) {
                var n = (0, v.getSequenceFrameSize)(e);
                for (var o = 0, i = t; o < i.length; o++) {
                    var a = i[o];
                    var u = (0, h.getClip)(e, a);
                    var s = (0, h.getQEClip)(e, a);
                    var c = C(u);
                    var l = g(u);
                    var p = y(n, r), f = p[0], d = p[1];
                    if (s.scaleToFrameSize) {
                        m(u, d / f);
                    } else if (c.fillFrame) {
                        m(u, d * l);
                    } else if (c.fitToFrame) {
                        m(u, f * l);
                    }
                }
            }
            t.scaleClipsToCanvas = P;
            function C(e) {
                var t = (0, i.parseClipLabels)(e.name), r = t[0], n = t[1];
                e.name = n;
                return r;
            }
            var T = /mister horse adjustment/i;
            function x(e) {
                var t;
                if (!e.isMGT()) return false;
                for (var r = 0; r < e.components.length; r++) {
                    var n = e.components[r];
                    if (n.matchName === "AE.ADBE Text" && ((t = n.instanceName) === null || t === void 0 ? void 0 : t.match(T))) {
                        return true;
                    }
                }
                return false;
            }
            t.isMHAdjustmentClip = x;
            function I(e, t) {
                for (var r = 0, n = e; r < n.length; r++) {
                    var o = n[r];
                    if (o.type === t) {
                        return o;
                    }
                }
                return null;
            }
            t.findFirstClip = I;
        },
        9923: function(e, t) {
            "use strict";
            t.__esModule = true;
            t.FrameRate = void 0;
            var r = function() {
                function n(e, t) {
                    this.numerator = e;
                    this.denominator = t;
                }
                n.fromTimebase = function(e) {
                    var t = new Time();
                    t.ticks = String(e);
                    var r = 1 / t.seconds;
                    return n.fromNumber(r);
                };
                n.fromNumber = function(e) {
                    var t = Math.round(e);
                    if (e > 0 && e === t) {
                        return new n(t, 1);
                    } else if (e < t && (t == 24 || t == 30 || t == 60)) {
                        return new n(t * 1e3, 1001);
                    } else {
                        var r = 1e3;
                        return new n(Math.round(e * r), r);
                    }
                };
                n.prototype.getFraction = function() {
                    return [ this.numerator, this.denominator ];
                };
                n.prototype.getFramesPerSecond = function() {
                    return this.numerator / this.denominator;
                };
                n.prototype.isEqual = function(e) {
                    return this.numerator === e.numerator && this.denominator === e.denominator;
                };
                return n;
            }();
            t.FrameRate = r;
        },
        3575: function(e, t, r) {
            "use strict";
            var i = r(8708);
            var c = this && this.__spreadArray || function(e, t, r) {
                if (r || arguments.length === 2) for (var n = 0, o = t.length, i; n < o; n++) {
                    if (i || !(n in t)) {
                        if (!i) i = Array.prototype.slice.call(t, 0, n);
                        i[n] = t[n];
                    }
                }
                return e.concat(i || Array.prototype.slice.call(t));
            };
            t.__esModule = true;
            t.isTextProperty = t.traverseControlTree = t.copyClipProperties = t.captureClipProperties = t.setMogrtBlendingMode = t.addBrandName = t.fixClipOutPoint = t.ensureCorrectMogrtScale = t.getMetaPropertyValue = t.importMgtOrThrow = void 0;
            var s = r(4559);
            var a = r(7750);
            var n = r(8234);
            var l = r(3285);
            var u = r(9008);
            function o(e, t, r, n, o) {
                var i;
                try {
                    i = e.importMGT(t, r, n, o);
                } catch (e) {
                    throw new u.Exception("Failed to import the mogrt", {
                        exception: e instanceof Error && e.description || String(e)
                    });
                }
                if (i == null) throw new u.Exception("Failed to import the mogrt");
                if (i.nodeId === "00000000" && i.projectItem == null) {
                    throw new u.Exception("Failed to import the mogrt");
                }
                return i;
            }
            t.importMgtOrThrow = o;
            function p(e) {
                for (var t = 0; t < e.properties.length; t++) {
                    var r = e.properties[t];
                    if (r.displayName === "mhpc-meta") {
                        var n = r.getValue();
                        var o = (0, a.atob)(n);
                        return i.parse(o);
                    }
                }
                return {};
            }
            t.getMetaPropertyValue = p;
            function f(e, t) {
                for (var r = 0; r < e.components.numItems; r++) {
                    var n = e.components[r];
                    if (n.matchName === t) return n;
                }
                return null;
            }
            function d(e) {
                if (!e.isMGT() || e.getMGTComponent() == null) return;
                var t = f(e, "AE.ADBE Motion");
                if (t == null) return;
                var r = 1;
                var n = t.properties[r];
                if (n.getValue() != 100) {
                    n.setValue(100);
                }
            }
            t.ensureCorrectMogrtScale = d;
            function h(e, t) {
                if ((t === null || t === void 0 ? void 0 : t.maxDur) != null) {
                    e.outPoint = (0, n.createTimeValue)(t.maxDur);
                }
            }
            t.fixClipOutPoint = h;
            function v(e) {
                e.name = e.name + " by Mister Horse";
            }
            t.addBrandName = v;
            function y(e, t) {
                var r = f(e, "AE.ADBE Opacity");
                if (r == null) return;
                if ((t === null || t === void 0 ? void 0 : t.blendMode) != null) {
                    r.properties[1].setValue(t.blendMode);
                }
            }
            t.setMogrtBlendingMode = y;
            function g(e, t) {
                var r = e.getMGTComponent();
                var n = {};
                P(t, function(e, t) {
                    if (_(e)) return;
                    n[t] = T(r, e);
                });
                return n;
            }
            t.captureClipProperties = g;
            function m(e, t, n, o) {
                var i = e.getMGTComponent();
                P(t, function(e, t) {
                    if (_(e)) return;
                    var r = n[t];
                    if (r === undefined) return;
                    x(i, e, o, r);
                });
            }
            t.copyClipProperties = m;
            function P(e, a) {
                function u(e, t) {
                    if (e.control.type === s.ControlType.Group) {
                        var r = "".concat(t, "/").concat(e.control.name);
                        for (var n = 0, o = e.children; n < o.length; n++) {
                            var i = o[n];
                            u(i, r);
                        }
                    } else {
                        var r = "".concat(t, "/").concat(e.control.name, ":").concat(e.control.type);
                        a(e, r);
                    }
                }
                for (var t = 0, r = e; t < r.length; t++) {
                    var n = r[t];
                    u(n, "root");
                }
            }
            t.traverseControlTree = P;
            function C(e) {
                return e.control.type === s.ControlType.Text;
            }
            t.isTextProperty = C;
            function T(e, t) {
                var r = e.properties[t.originalIndex];
                if (S(t)) {
                    return r.getColorValue();
                } else {
                    return r.getValue();
                }
            }
            function x(e, t, r, n) {
                var o = e.properties[t.originalIndex];
                if (w(t)) {
                    if (r.keepTransform) {
                        o.setValue(n, true);
                    }
                } else if (C(t)) {
                    var i = (0, l.parseTextValue)(n);
                    var a = (0, l.parseTextValue)(o.getValue());
                    if (r.keepTextProperties) {
                        a = (0, l.setEditText)(i, (0, l.getEditText)(a));
                    }
                    if (r.keepTexts) {
                        a = (0, l.setEditText)(a, (0, l.getEditText)(i));
                    }
                    var u = (0, l.serializeTextValue)(a);
                    if (u !== o.getValue()) {
                        o.setValue(u, true);
                    }
                } else if (S(t)) {
                    var s = n;
                    if (r.keepOtherProperties) {
                        o.setColorValue.apply(o, c(c([], s, false), [ true ], false));
                    }
                } else if (V(t)) {
                    if (r.keepOtherProperties) {
                        o.setValue(n, true);
                    }
                }
            }
            var I = [ "Position", "Rotation", "Scale", "Skew", "Opacity" ];
            function w(e) {
                var t = e.control, r = e.parent;
                if (r == null || r.control.name === "Transform") {
                    var n = t.name.toLowerCase();
                    for (var o = 0, i = I; o < i.length; o++) {
                        var a = i[o];
                        if (n === a.toLowerCase()) return true;
                    }
                }
                return false;
            }
            function S(e) {
                return e.control.type === s.ControlType.Color;
            }
            var F = [ s.ControlType.Checkbox, s.ControlType.Slider, s.ControlType.Angle, s.ControlType.Color, s.ControlType.Point2D, s.ControlType.Point2DExt, s.ControlType.Dropdown ];
            function V(e) {
                var t = e.control;
                for (var r = 0, n = F; r < n.length; r++) {
                    var o = n[r];
                    if (t.type === o) return true;
                }
                return false;
            }
            function _(e) {
                var t = e.control;
                return t.type === s.ControlType.Slider && t.name === "Duration";
            }
        },
        3745: function(e, t) {
            "use strict";
            t.__esModule = true;
            t.settleSync = void 0;
            function r(e) {
                var t = null;
                e.then(function(e) {
                    t = {
                        success: true,
                        value: e
                    };
                }, function(e) {
                    t = {
                        success: false,
                        error: e
                    };
                });
                if (t != null) {
                    var r = t;
                    if (r.success) {
                        return r.value;
                    } else {
                        throw r.error;
                    }
                } else {
                    throw new Error("Promise was not settled synchronously");
                }
            }
            t.settleSync = r;
        },
        7811: function(e, t) {
            "use strict";
            t.__esModule = true;
            t.isPropertyColorValue = t.setPropertyColorValue = t.getPropertyColorValue = void 0;
            function r(e) {
                if (!a(e)) return null;
                var t = e.getColorValue(), r = t[1], n = t[2], o = t[3];
                return [ i(r), i(n), i(o) ];
            }
            t.getPropertyColorValue = r;
            function n(e, t) {
                e.setColorValue(1, o(t[0]), o(t[1]), o(t[2]), true);
            }
            t.setPropertyColorValue = n;
            function i(e) {
                return e / 255;
            }
            function o(e) {
                return Math.round(e * 255);
            }
            function a(e) {
                var t = e.getValue();
                if (typeof t !== "number") return false;
                try {
                    e.getColorValue();
                } catch (e) {
                    return false;
                }
                return true;
            }
            t.isPropertyColorValue = a;
        },
        4155: function(e, t, r) {
            "use strict";
            t.__esModule = true;
            t.razorSequenceTrack = t.addSequenceTracks = t.getSequenceByProjectItem = t.getTrackEmptySpace = t.isTrackFree = t.getFreeTracks = void 0;
            var c = r(4530);
            var u = r(4425);
            var l = r(9008);
            function n(e, t, r, n, o, i) {
                if (i === void 0) {
                    i = false;
                }
                if (!n && !o) return [ -1, -1 ];
                var a = e.videoTracks;
                var u = e.audioTracks;
                var s = Math.max(a.numTracks, u.numTracks);
                var c = C(s + n, true);
                var l = C(s + o, true);
                if (n) {
                    for (var p = 0; p < a.numTracks; p++) {
                        c[p] = T(a[p], t, t + r);
                    }
                }
                if (o) {
                    for (var p = 0; p < u.numTracks; p++) {
                        l[p] = T(u[p], t, t + r);
                    }
                }
                var f;
                var d;
                if (i) {
                    f = a.numTracks;
                    d = u.numTracks;
                    for (var h = 0; h < s; h++) {
                        var v = true;
                        for (var p = 0; p < n; p++) {
                            if (!c[h + p]) {
                                v = false;
                                break;
                            }
                        }
                        if (v) {
                            f = h;
                            break;
                        }
                    }
                    for (var h = 0; h < s; h++) {
                        var v = true;
                        for (var p = 0; p < o; p++) {
                            if (!l[h + p]) {
                                v = false;
                                break;
                            }
                        }
                        if (v) {
                            d = h;
                            break;
                        }
                    }
                } else {
                    f = s;
                    d = s;
                    for (var h = 0; h < s; h++) {
                        var v = true;
                        for (var p = 0; p < n; p++) {
                            if (!c[h + p]) {
                                v = false;
                                break;
                            }
                        }
                        if (!v) continue;
                        for (var p = 0; p < o; p++) {
                            if (!l[h + p]) {
                                v = false;
                                break;
                            }
                        }
                        if (!v) continue;
                        f = h;
                        d = h;
                        break;
                    }
                }
                var y = n > 0 && f + n > a.numTracks;
                var g = o > 0 && d + o > u.numTracks;
                if (y || g) {
                    var m = y ? Math.max(0, f + n - a.numTracks) : 0;
                    var P = g ? Math.max(0, d + o - u.numTracks) : 0;
                    x(e, {
                        videoTracks: m,
                        audioTracks: P
                    });
                }
                return [ n ? f : -1, o ? d : -1 ];
            }
            t.getFreeTracks = n;
            function C(e, t) {
                var r = Array(e);
                for (var n = 0; n < e; n++) r[n] = t;
                return r;
            }
            function T(e, t, r) {
                for (var n = 0; n < e.clips.numItems; n++) {
                    var o = e.clips[n];
                    if (t < o.end.seconds && o.start.seconds < r) {
                        return false;
                    }
                }
                return true;
            }
            t.isTrackFree = T;
            function o(e, t) {
                for (var r = 0; r < e.clips.numItems; r++) {
                    var n = e.clips[r];
                    if (n.start.seconds <= t && t < n.end.seconds) {
                        return 0;
                    }
                    if (n.start.seconds > t) {
                        return n.start.seconds - t;
                    }
                }
                return Infinity;
            }
            t.getTrackEmptySpace = o;
            function i(e, t) {
                for (var r = 0; r < e.sequences.numSequences; r++) {
                    var n = e.sequences[r];
                    if (n.projectItem.treePath === t.treePath) return n;
                }
                return null;
            }
            t.getSequenceByProjectItem = i;
            function x(e, t) {
                var r = t.videoTracks, n = r === void 0 ? 0 : r, o = t.audioTracks, i = o === void 0 ? 0 : o;
                if (n === 0 && i === 0) return [ 0, 0 ];
                var a = e.videoTracks.numTracks;
                var u = e.audioTracks.numTracks;
                var s = 1;
                (0, c.getQESequence)(e).addTracks(n, a, i, s, u, 0, 0);
                if (e.videoTracks.numTracks < a + n || e.audioTracks.numTracks < u + i) {
                    throw new l.UserError("Couldn't add new tracks to the sequence. Please add tracks manually and try again.");
                }
                return [ a, u ];
            }
            t.addSequenceTracks = x;
            function a(e, t, r, n) {
                var o = (0, c.getQESequence)(e);
                var i = e.getPlayerPosition();
                e.setPlayerPosition(n.ticks);
                var a = o.CTI.timecode;
                if (t === u.ClipType.Video) {
                    o.getVideoTrackAt(r).razor(a);
                } else {
                    o.getAudioTrackAt(r).razor(a);
                }
                e.setPlayerPosition(i.ticks);
            }
            t.razorSequenceTrack = a;
        },
        5194: function(e, t, r) {
            "use strict";
            t.__esModule = true;
            t.SequenceSnapshot = void 0;
            var o = r(9008);
            var i = r(1413);
            var n = function() {
                function n(e) {
                    this.sequenceId = e;
                    this.clips = {};
                }
                n.create = function(e) {
                    var t = new n(e.sequenceID);
                    for (var r = 0; r < e.videoTracks.numTracks; r++) {
                        t.addTrack(e.videoTracks[r], r);
                    }
                    for (var r = 0; r < e.audioTracks.numTracks; r++) {
                        t.addTrack(e.audioTracks[r], r);
                    }
                    return t;
                };
                n.prototype.getAddedClips = function(e) {
                    if (this.sequenceId !== e.sequenceId) throw new o.Exception("Snapshot is not for this sequence");
                    var t = new n(this.sequenceId);
                    for (var r in this.clips) {
                        if (e.clips[r]) continue;
                        t.clips[r] = this.clips[r];
                    }
                    return t;
                };
                n.prototype.getFirstClip = function(e) {
                    for (var t in this.clips) {
                        var r = this.clips[t];
                        if (e && r.location.type !== e) continue;
                        return r;
                    }
                    return null;
                };
                n.prototype.getClipLocations = function(e) {
                    var t = [];
                    for (var r in this.clips) {
                        var n = this.clips[r];
                        if (e && n.location.type !== e) continue;
                        t.push(n.location);
                    }
                    return t;
                };
                n.prototype.addTrack = function(e, t) {
                    for (var r = 0; r < e.clips.numItems; r++) {
                        var n = e.clips[r];
                        this.addClip(n, t, r);
                    }
                };
                n.prototype.addClip = function(e, t, r) {
                    this.clips[e.nodeId] = a(e, t, r);
                };
                return n;
            }();
            t.SequenceSnapshot = n;
            function a(e, t, r) {
                var n = (0, i.getClipType)(e);
                return {
                    id: e.nodeId,
                    location: {
                        trackIndex: t,
                        clipIndex: r,
                        type: n
                    }
                };
            }
        },
        492: function(e, t) {
            "use strict";
            t.__esModule = true;
            t.TempFileContext = void 0;
            var r = function() {
                function e(e) {
                    this.externalObject = e;
                    this.tempFiles = [];
                }
                e.prototype.getTempFile = function(e) {
                    var t = this.externalObject.getTempFile(e);
                    this.tempFiles.push(t);
                    return t;
                };
                e.prototype.addTempFile = function(e) {
                    this.tempFiles.push(e);
                    return e;
                };
                e.prototype.deleteTempFiles = function() {
                    if (this.tempFiles.length === 0) return;
                    this.externalObject.deleteTempFiles(this.tempFiles);
                    this.tempFiles = [];
                };
                e.prototype.execute = function(e) {
                    try {
                        return e(this);
                    } finally {
                        this.deleteTempFiles();
                    }
                };
                return e;
            }();
            t.TempFileContext = r;
        },
        3285: function(e, t, r) {
            "use strict";
            var n = r(8708);
            var o = this && this.__assign || function() {
                o = Object.assign || function(e) {
                    for (var t, r = 1, n = arguments.length; r < n; r++) {
                        t = arguments[r];
                        for (var o in t) if (Object.prototype.hasOwnProperty.call(t, o)) e[o] = t[o];
                    }
                    return e;
                };
                return o.apply(this, arguments);
            };
            t.__esModule = true;
            t.setFontFauxVariant = t.getFontFauxVariant = t.setFontFauxItalic = t.isFontFauxItalic = t.setFontFauxBold = t.isFontFauxBold = t.isStyleEditable = t.isFontFamilyEditable = t.setFontFamily = t.getFontFamily = t.isFontSizeEditable = t.setFontSize = t.getFontSize = t.setEditText = t.getEditText = t.serializeTextValue = t.parseTextValue = t.FontVariant = void 0;
            var i = r(9008);
            var a;
            (function(e) {
                e["normal"] = "normal";
                e["allCaps"] = "all_caps";
                e["smallCaps"] = "small_caps";
            })(a || (t.FontVariant = a = {}));
            function u(e) {
                var t = n.parse(e);
                if (typeof t !== "object" || t === null) {
                    throw new i.Exception("Invalid text value JSON");
                }
                return t;
            }
            t.parseTextValue = u;
            function s(e) {
                return n.stringify(e);
            }
            t.serializeTextValue = s;
            function c(e) {
                return e.textEditValue;
            }
            t.getEditText = c;
            function l(e, t) {
                if (w(e)) {
                    return o(o({}, e), {
                        textEditValue: t
                    });
                } else {
                    return o(o({}, e), {
                        textEditValue: t,
                        fontTextRunLength: [ t.length ]
                    });
                }
            }
            t.setEditText = l;
            function p(e) {
                if (w(e)) {
                    return e.fonteditinfo.fontSizeEditValue;
                } else {
                    return e.fontSizeEditValue[0];
                }
            }
            t.getFontSize = p;
            function f(e, t) {
                if (w(e)) {
                    return o(o({}, e), {
                        fonteditinfo: o(o({}, e.fonteditinfo), {
                            fontSizeEditValue: t
                        })
                    });
                } else {
                    return o(o({}, e), {
                        fontSizeEditValue: [ t ]
                    });
                }
            }
            t.setFontSize = f;
            function d(e) {
                if (w(e)) {
                    return e.fonteditinfo.capPropFontSizeEdit;
                } else {
                    return e.capPropFontSizeEdit;
                }
            }
            t.isFontSizeEditable = d;
            function h(e) {
                if (w(e)) {
                    return e.fonteditinfo.fontEditValue;
                } else {
                    return e.fontEditValue[0];
                }
            }
            t.getFontFamily = h;
            function v(e, t) {
                if (w(e)) {
                    return o(o({}, e), {
                        fonteditinfo: o(o({}, e.fonteditinfo), {
                            fontEditValue: t
                        })
                    });
                } else {
                    return o(o({}, e), {
                        fontEditValue: [ t ]
                    });
                }
            }
            t.setFontFamily = v;
            function y(e) {
                if (w(e)) {
                    return e.fonteditinfo.capPropFontEdit;
                } else {
                    return e.capPropFontEdit;
                }
            }
            t.isFontFamilyEditable = y;
            function g(e) {
                if (w(e)) {
                    return e.fonteditinfo.capPropFontFauxStyleEdit;
                } else {
                    return e.capPropFontFauxStyleEdit;
                }
            }
            t.isStyleEditable = g;
            function m(e) {
                if (w(e)) {
                    return e.fonteditinfo.fontFSBoldValue;
                } else {
                    return e.fontFSBoldValue[0];
                }
            }
            t.isFontFauxBold = m;
            function P(e, t) {
                if (w(e)) {
                    return o(o({}, e), {
                        fonteditinfo: o(o({}, e.fonteditinfo), {
                            fontFSBoldValue: t
                        })
                    });
                } else {
                    return o(o({}, e), {
                        fontFSBoldValue: [ t ]
                    });
                }
            }
            t.setFontFauxBold = P;
            function C(e) {
                if (w(e)) {
                    return e.fonteditinfo.fontFSItalicValue;
                } else {
                    return e.fontFSItalicValue[0];
                }
            }
            t.isFontFauxItalic = C;
            function T(e, t) {
                if (w(e)) {
                    return o(o({}, e), {
                        fonteditinfo: o(o({}, e.fonteditinfo), {
                            fontFSItalicValue: t
                        })
                    });
                } else {
                    return o(o({}, e), {
                        fontFSItalicValue: [ t ]
                    });
                }
            }
            t.setFontFauxItalic = T;
            function x(e) {
                if (w(e)) {
                    if (e.fonteditinfo.fontFSAllCapsValue) {
                        return a.allCaps;
                    } else if (e.fonteditinfo.fontFSSmallCapsValue) {
                        return a.smallCaps;
                    } else {
                        return a.normal;
                    }
                } else {
                    if (e.fontFSAllCapsValue[0]) {
                        return a.allCaps;
                    } else if (e.fontFSSmallCapsValue[0]) {
                        return a.smallCaps;
                    } else {
                        return a.normal;
                    }
                }
            }
            t.getFontFauxVariant = x;
            function I(e, t) {
                if (w(e)) {
                    if (t === a.allCaps) {
                        return o(o({}, e), {
                            fonteditinfo: o(o({}, e.fonteditinfo), {
                                fontFSAllCapsValue: true,
                                fontFSSmallCapsValue: false
                            })
                        });
                    } else if (t === a.smallCaps) {
                        return o(o({}, e), {
                            fonteditinfo: o(o({}, e.fonteditinfo), {
                                fontFSSmallCapsValue: true,
                                fontFSAllCapsValue: false
                            })
                        });
                    } else {
                        return o(o({}, e), {
                            fonteditinfo: o(o({}, e.fonteditinfo), {
                                fontFSAllCapsValue: false,
                                fontFSSmallCapsValue: false
                            })
                        });
                    }
                } else {
                    if (t === a.allCaps) {
                        return o(o({}, e), {
                            fontFSAllCapsValue: [ true ],
                            fontFSSmallCapsValue: [ false ]
                        });
                    } else if (t === a.smallCaps) {
                        return o(o({}, e), {
                            fontFSSmallCapsValue: [ true ],
                            fontFSAllCapsValue: [ false ]
                        });
                    } else {
                        return o(o({}, e), {
                            fontFSAllCapsValue: [ false ],
                            fontFSSmallCapsValue: [ false ]
                        });
                    }
                }
            }
            t.setFontFauxVariant = I;
            function w(e) {
                return "fonteditinfo" in e;
            }
        },
        633: function(e, t) {
            "use strict";
            t.__esModule = true;
            t.createTimer = void 0;
            var n = 0;
            function r(e, t) {
                var r = false;
                app.setTimeout(function() {
                    if (r) return;
                    e();
                }, t);
                return {
                    id: n++,
                    cancel: function() {
                        r = true;
                    }
                };
            }
            t.createTimer = r;
        },
        1413: function(e, t, r) {
            "use strict";
            var u = this && this.__assign || function() {
                u = Object.assign || function(e) {
                    for (var t, r = 1, n = arguments.length; r < n; r++) {
                        t = arguments[r];
                        for (var o in t) if (Object.prototype.hasOwnProperty.call(t, o)) e[o] = t[o];
                    }
                    return e;
                };
                return u.apply(this, arguments);
            };
            var a = this && this.__spreadArray || function(e, t, r) {
                if (r || arguments.length === 2) for (var n = 0, o = t.length, i; n < o; n++) {
                    if (i || !(n in t)) {
                        if (!i) i = Array.prototype.slice.call(t, 0, n);
                        i[n] = t[n];
                    }
                }
                return e.concat(i || Array.prototype.slice.call(t));
            };
            t.__esModule = true;
            t.splitClipLocation = t.findClipLocationAtTime = t.findClipIndexAtTime = t.removeClips = t.ClipType = t.getClipLocation = t.isClipType = t.getClipType = t.sortClipLocations = t.getSelectedClips = t.getQEClip = t.getClip = void 0;
            var v = r(5897);
            var s = r(4530);
            var c = r(9008);
            var l = r(4425);
            t.ClipType = l.ClipType;
            function p(e, t) {
                var r = t.type === l.ClipType.Audio ? e.audioTracks : e.videoTracks;
                if (t.trackIndex >= r.numTracks) throw new c.Exception("Invalid track index");
                var n = r[t.trackIndex];
                if (t.clipIndex >= n.clips.numItems) throw new c.Exception("Invalid clip index");
                return n.clips[t.clipIndex];
            }
            t.getClip = p;
            function n(e, t) {
                var r = (0, s.getQESequence)(e);
                var n = t.type === l.ClipType.Audio ? r.getAudioTrackAt(t.trackIndex) : r.getVideoTrackAt(t.trackIndex);
                var o = 0;
                for (var i = 0; i < n.numItems; i++) {
                    var a = n.getItemAt(i);
                    if (a.type === "Empty") continue;
                    if (t.clipIndex === o) {
                        return a;
                    }
                    o++;
                }
                throw new c.Exception("QE clip not found");
            }
            t.getQEClip = n;
            function o(e, t) {
                var r = e.getSelection();
                var n = new v.Set();
                for (var o = 0, i = r; o < i.length; o++) {
                    var a = i[o];
                    n.add(a.nodeId);
                }
                var u = [];
                var s = [ e.videoTracks, e.audioTracks ];
                for (var c = 0, l = s; c < l.length; c++) {
                    var p = l[c];
                    for (var f = 0; f < p.numTracks; f++) {
                        var d = p[f];
                        for (var h = 0; h < d.clips.numItems; h++) {
                            var a = d.clips[h];
                            if (t != null && !g(a, t)) continue;
                            if (n.has(a.nodeId)) {
                                u.push({
                                    trackIndex: f,
                                    clipIndex: h,
                                    type: y(a)
                                });
                            }
                        }
                    }
                }
                return u;
            }
            t.getSelectedClips = o;
            function f(e) {
                e.sort(function(e, t) {
                    if (e.trackIndex === t.trackIndex) {
                        return e.clipIndex - t.clipIndex;
                    } else {
                        return e.trackIndex - t.trackIndex;
                    }
                });
            }
            t.sortClipLocations = f;
            function y(e) {
                if (e.mediaType === "Audio") {
                    return l.ClipType.Audio;
                } else {
                    return l.ClipType.Video;
                }
            }
            t.getClipType = y;
            function g(e, t) {
                return y(e) === t;
            }
            t.isClipType = g;
            function i(e, t) {
                var r = g(e, l.ClipType.Audio) ? t.audioTracks : t.videoTracks;
                for (var n = 0; n < r.numTracks; n++) {
                    var o = r[n];
                    for (var i = 0; i < o.clips.numItems; i++) {
                        var a = o.clips[i];
                        if (a.nodeId === e.nodeId) {
                            return {
                                trackIndex: n,
                                clipIndex: i,
                                type: y(e)
                            };
                        }
                    }
                }
                throw new c.Exception("Clip not found in sequence");
            }
            t.getClipLocation = i;
            function d(e, t) {
                var r = a([], t, true);
                f(r);
                for (var n = r.length - 1; n >= 0; n--) {
                    var o = r[n];
                    var i = p(e, o);
                    i.remove(false, false);
                }
            }
            t.removeClips = d;
            function h(e, t) {
                for (var r = 0; r < e.clips.numItems; r++) {
                    var n = e.clips[r];
                    if (n.start.ticks === t.ticks) {
                        return r;
                    }
                }
                return null;
            }
            t.findClipIndexAtTime = h;
            function m(e, t, r, n) {
                var o = t === l.ClipType.Video ? e.videoTracks[r] : e.audioTracks[r];
                var i = h(o, n);
                if (i == null) return null;
                return {
                    type: t,
                    trackIndex: r,
                    clipIndex: i
                };
            }
            t.findClipLocationAtTime = m;
            function P(e, t) {
                var r = [];
                for (var n = 0, o = e; n < o.length; n++) {
                    var i = o[n];
                    var a = i.type === t.type && i.trackIndex === t.trackIndex;
                    if ((0, l.isClipLocationEqual)(i, t)) {
                        r.push(u({}, i));
                        r.push(u(u({}, i), {
                            clipIndex: i.clipIndex + 1
                        }));
                    } else if (a && i.clipIndex > t.clipIndex) {
                        r.push(u(u({}, i), {
                            clipIndex: i.clipIndex + 1
                        }));
                    } else {
                        r.push(u({}, i));
                    }
                }
                return r;
            }
            t.splitClipLocation = P;
        },
        5474: function(e, t, r) {
            "use strict";
            var n = r(8708);
            t.__esModule = true;
            t.console = void 0;
            var o = r(9388);
            t.console = {
                log: function() {
                    var e = [];
                    for (var t = 0; t < arguments.length; t++) {
                        e[t] = arguments[t];
                    }
                    var r = (0, o.map)(e, function(e) {
                        if (typeof e === "string") return e;
                        if (typeof e === "number") return e.toString();
                        return n.stringify(e);
                    });
                    $.writeln(r.join(" "));
                },
                dir: function() {
                    var e = [];
                    for (var t = 0; t < arguments.length; t++) {
                        e[t] = arguments[t];
                    }
                    var r = (0, o.map)(e, function(e) {
                        return n.stringify(e, undefined, 2);
                    });
                    $.writeln(r.join(" "));
                },
                time: function(e) {
                    if (e === void 0) {
                        e = "default";
                    }
                    i[e] = a();
                },
                timeEnd: function(e) {
                    if (e === void 0) {
                        e = "default";
                    }
                    var t = i[e];
                    if (t == null) return;
                    var r = a();
                    var n = r - t;
                    $.writeln("".concat(e, ": ").concat(n, " ms"));
                    delete i[e];
                }
            };
            var i = {};
            function a() {
                var e = new Date();
                return e.getTime();
            }
        },
        5998: function(e, t, r) {
            "use strict";
            t.__esModule = true;
            t.ProjectAssets = void 0;
            var u = r(9008);
            var n = function() {
                function e(e, t) {
                    this.project = e;
                    this.externalObject = t;
                }
                e.prototype.importItem = function(e) {
                    var t = this.externalObject.ensureFootageForItem(e, this.project.path);
                    return this.importAsset(t);
                };
                e.prototype.importAdditionalFootage = function(e, t) {
                    var r = this.externalObject.ensureAdditionalFootageForItem(e, this.project.path, t);
                    return this.importAsset(r);
                };
                e.prototype.importImageSequence = function(e) {
                    var t = this.externalObject.ensureFootageForItem(e, this.project.path);
                    if (t.files.length < 1) throw new u.Exception("Expected at least one file for project asset");
                    var r = t.files[0];
                    var n = this.getProjectBin(t.projectItemPath);
                    var o = this.findProjectItem(n, r);
                    if (o != null) return o;
                    var i = this.project.importFiles(t.files, true, n, true);
                    if (!i) throw new u.Exception("Failed to import asset: ".concat(r));
                    var a = this.findProjectItem(n, r);
                    if (a == null) throw new u.Exception("Failed to find project item: ".concat(r));
                    return a;
                };
                e.prototype.importAsset = function(e) {
                    if (e.files.length !== 1) throw new u.Exception("Expected exactly one file for project asset");
                    var t = e.files[0];
                    var r = this.getProjectBin(e.projectItemPath);
                    var n = this.findProjectItem(r, t);
                    if (n != null) return n;
                    var o = this.project.importFiles([ t ], true, r, false);
                    if (!o) throw new u.Exception("Failed to import asset: ".concat(t));
                    var i = this.findProjectItem(r, t);
                    if (i == null) throw new u.Exception("Failed to find project item: ".concat(t));
                    return i;
                };
                e.prototype.getProjectBin = function(e) {
                    var t = this.project.rootItem;
                    for (var r = 0, n = e; r < n.length; r++) {
                        var o = n[r];
                        var i = null;
                        for (var a = 0; a < t.children.numItems; a++) {
                            var u = t.children[a];
                            if (u.type === ProjectItemType.BIN && u.name === o) {
                                i = u;
                                break;
                            }
                        }
                        if (i === null) {
                            i = t.createBin(o);
                        }
                        t = i;
                    }
                    return t;
                };
                e.prototype.findProjectItem = function(e, t) {
                    var r = this.externalObject.normalizeFilePath(t);
                    for (var n = 0; n < e.children.numItems; n++) {
                        var o = e.children[n];
                        if (o.type !== ProjectItemType.CLIP && o.type !== ProjectItemType.FILE) continue;
                        var i = this.externalObject.normalizeFilePath(o.getMediaPath());
                        if (i === r) return o;
                    }
                    return null;
                };
                return e;
            }();
            t.ProjectAssets = n;
        },
        4666: function(e, t, r) {
            "use strict";
            t.__esModule = true;
            t.findProjectItemRecursive = t.findBinByName = t.findACBin = t.getOrCreateACBin = t.getQEProject = t.getProjectBySequenceId = t.getProjectById = t.getProjectByFilePath = void 0;
            var o = r(4530);
            var i = r(9008);
            function n(e) {
                for (var t = 0; t < app.projects.numProjects; t++) {
                    var r = app.projects[t];
                    if (r.path === e) return r;
                }
                return null;
            }
            t.getProjectByFilePath = n;
            function a(e) {
                for (var t = 0; t < app.projects.numProjects; t++) {
                    var r = app.projects[t];
                    if (r.documentID === e) return r;
                }
                return null;
            }
            t.getProjectById = a;
            function u(e) {
                var t = app.project;
                if ((0, o.getSequenceById)(t, e) != null) {
                    return t;
                }
                for (var r = 0; r < app.projects.numProjects; r++) {
                    var n = app.projects[r];
                    if ((0, o.getSequenceById)(n, e) != null) {
                        return n;
                    }
                }
                return null;
            }
            t.getProjectBySequenceId = u;
            function s(e, t) {
                if (t === void 0) {
                    t = true;
                }
                if (p(qe.project, e.path)) {
                    return qe.project;
                }
                if (f(qe.project, e.path)) {
                    qe.project.init();
                    if (p(qe.project, e.path)) {
                        return qe.project;
                    }
                }
                if (t) {
                    c(e);
                    if (p(qe.project, e.path)) {
                        return qe.project;
                    }
                }
                throw new i.Exception('QE project "'.concat(e.name, '" is not available'), l(e));
            }
            t.getQEProject = s;
            function c(e) {
                var t = v(e.path);
                var r = null;
                for (var n = 0; n < app.projects.numProjects; n++) {
                    if (app.projects[n].path === e.path) {
                        r = app.projects[n];
                        break;
                    }
                }
                if (r == null) throw new i.Exception('Failed to locate project "'.concat(e.name, '".'), l(e));
                app.project = r;
                if (v(qe.project.path) !== t) throw new i.Exception('Failed to activate QE project "'.concat(e.name, '"'), l(e));
                if (typeof qe.project.undoStackIndex !== "function") qe.project.init();
            }
            function l(t) {
                var r = false;
                try {
                    for (var e = 0; e < app.projects.numProjects; e++) {
                        if (t.documentID === app.projects[e].documentID) {
                            r = true;
                            break;
                        }
                    }
                } catch (e) {}
                try {
                    return {
                        existing: r,
                        app: {
                            path: t.path,
                            name: t.name,
                            normalizedPath: v(app.project.path)
                        },
                        qe: {
                            path: qe.project.path,
                            name: qe.project.name,
                            normalizedPath: v(qe.project.path)
                        }
                    };
                } catch (e) {
                    return {
                        existing: r,
                        path: t.path,
                        name: t.name
                    };
                }
            }
            function p(e, t) {
                return d(e, t) && h(e);
            }
            function f(e, t) {
                return d(e, t) && !h(e);
            }
            function d(e, t) {
                try {
                    return e != null && v(e.path) === v(t);
                } catch (e) {
                    return false;
                }
            }
            function h(e) {
                try {
                    return e != null && typeof e.undoStackIndex === "function";
                } catch (e) {
                    return false;
                }
            }
            function v(e) {
                return new File(e).absoluteURI;
            }
            var y = "Animation Composer";
            function g(e) {
                var t = m(e.rootItem);
                if (t) return t;
                return e.rootItem.createBin(y);
            }
            t.getOrCreateACBin = g;
            function m(e) {
                return P(y, e);
            }
            t.findACBin = m;
            function P(e, t) {
                for (var r = 0; r < t.children.numItems; r++) {
                    var n = t.children[r];
                    if (n.type === ProjectItemType.BIN) {
                        if (n.name === e) return n;
                    }
                }
                return null;
            }
            t.findBinByName = P;
            function C(e, t) {
                for (var r = 0; r < e.children.numItems; r++) {
                    var n = e.children[r];
                    if (n.type == ProjectItemType.BIN) {
                        var o = C(n, t);
                        if (o) return o;
                    } else if (n.type == ProjectItemType.CLIP || n.type == ProjectItemType.FILE) {
                        if (t(n)) return n;
                    }
                }
                return null;
            }
            t.findProjectItemRecursive = C;
        },
        4530: function(e, t, r) {
            "use strict";
            t.__esModule = true;
            t.timeToSequenceTimecode = t.getSequenceFrameRate = t.getSequenceFrameSize = t.getSequenceByName = t.getSequenceByProjectItem = t.getSequenceById = t.getQESequence = void 0;
            var n = r(9008);
            function o(e) {
                var t = qe.project.getActiveSequence();
                if ((t === null || t === void 0 ? void 0 : t.guid) === e.sequenceID) {
                    return t;
                }
                throw new n.Exception("QE sequence does not match requested sequence");
            }
            t.getQESequence = o;
            function i(e, t) {
                for (var r = 0; r < e.sequences.numSequences; r++) {
                    var n = e.sequences[r];
                    if (n.sequenceID === t) return n;
                }
                return null;
            }
            t.getSequenceById = i;
            function a(e, t) {
                for (var r = 0; r < e.sequences.numSequences; r++) {
                    var n = e.sequences[r];
                    if (n.projectItem.treePath === t.treePath) return n;
                }
                return null;
            }
            t.getSequenceByProjectItem = a;
            function u(e, t) {
                for (var r = 0; r < e.sequences.numSequences; r++) {
                    var n = e.sequences[r];
                    if (n.name === t) return n;
                }
                return null;
            }
            t.getSequenceByName = u;
            function s(e) {
                return [ e.frameSizeHorizontal, e.frameSizeVertical ];
            }
            t.getSequenceFrameSize = s;
            function c(e) {
                var t = new Time();
                t.ticks = e.timebase;
                return t;
            }
            t.getSequenceFrameRate = c;
            function l(e, t) {
                return e.getFormatted(c(t), t.videoDisplayFormat);
            }
            t.timeToSequenceTimecode = l;
        },
        8234: function(e, t) {
            "use strict";
            t.__esModule = true;
            t.isTimeEqual = t.timeFromFraction = t.roundToNextFrame = t.subtractTimeValues = t.addTimeValues = t.timeFromTicks = t.ticksFromTime = t.createTimeValue = void 0;
            function r(e) {
                var t = new Time();
                t.seconds = e;
                return t;
            }
            t.createTimeValue = r;
            function o(e) {
                return parseInt(e.ticks, 10);
            }
            t.ticksFromTime = o;
            function i(e) {
                var t = new Time();
                t.ticks = e.toString();
                return t;
            }
            t.timeFromTicks = i;
            function n(e, t) {
                return i(o(e) + o(t));
            }
            t.addTimeValues = n;
            function a(e, t) {
                return i(o(e) - o(t));
            }
            t.subtractTimeValues = a;
            function u(e, t) {
                var r = o(e);
                var n = o(t);
                return i(Math.ceil(r / n) * n);
            }
            t.roundToNextFrame = u;
            var s = o(r(1));
            function c(e) {
                return i(s * e[0] / e[1]);
            }
            t.timeFromFraction = c;
            function l(e, t) {
                return e.ticks === t.ticks;
            }
            t.isTimeEqual = l;
        },
        4339: function(e, t) {
            "use strict";
            t.__esModule = true;
            t.CompositionItem = void 0;
            var r = function() {
                function e() {}
                return e;
            }();
            t.CompositionItem = r;
        },
        4559: function(e, t, r) {
            "use strict";
            t.__esModule = true;
            t.isControlIgnored = t.isDurationControl = t.isCaptionGroup = t.isMetadataGroup = t.getControlTreePath = t.buildControlTree = t.ControlType = void 0;
            var n = r(4512);
            var o = r(9388);
            var v;
            (function(e) {
                e[e["Checkbox"] = 1] = "Checkbox";
                e[e["Slider"] = 2] = "Slider";
                e[e["Angle"] = 3] = "Angle";
                e[e["Color"] = 4] = "Color";
                e[e["Point2D"] = 5] = "Point2D";
                e[e["Text"] = 6] = "Text";
                e[e["Comment"] = 8] = "Comment";
                e[e["Point2DExt"] = 9] = "Point2DExt";
                e[e["Group"] = 10] = "Group";
                e[e["Dropdown"] = 13] = "Dropdown";
                e[e["Media"] = 14] = "Media";
            })(v || (t.ControlType = v = {}));
            function i(e) {
                var t = {};
                for (var r = 0; r < e.length; r++) {
                    var n = e[r];
                    var o = {
                        control: n,
                        originalIndex: r,
                        parent: null,
                        children: []
                    };
                    t[n.id] = o;
                }
                for (var i = 0, a = e; i < a.length; i++) {
                    var n = a[i];
                    if (n.type == v.Group) {
                        for (var u = 0, s = n.children; u < s.length; u++) {
                            var c = s[u];
                            var l = t[c];
                            var p = t[n.id];
                            l.parent = p;
                            p.children.push(l);
                        }
                    }
                }
                var f = [];
                for (var d = 0, h = e; d < h.length; d++) {
                    var n = h[d];
                    var o = t[n.id];
                    if (o.parent == null) {
                        f.push(o);
                    }
                }
                return f;
            }
            t.buildControlTree = i;
            function a(e) {
                var t = e.parent ? a(e.parent) : [];
                return t.concat([ e.control.name ]);
            }
            t.getControlTreePath = a;
            function u(e) {
                return e.type === v.Group && e.name === "Mister Horse Metadata";
            }
            t.isMetadataGroup = u;
            function s(e) {
                return e.type === v.Group && e.name === "Mister Horse Captions";
            }
            t.isCaptionGroup = s;
            function c(e, t) {
                return e.name === "Duration" && t == null;
            }
            t.isDurationControl = c;
            function l(e, t) {
                if (t.length === 0) return false;
                var r = a(e).join(">");
                return (0, o.some)(t, function(e) {
                    return (0, n.matchWildcardPattern)(e, r);
                });
            }
            t.isControlIgnored = l;
        },
        9932: function(e, t) {
            "use strict";
            t.__esModule = true;
            t.Events = void 0;
            var r = function() {
                function e() {}
                return e;
            }();
            t.Events = r;
        },
        3149: function(e, t) {
            "use strict";
            t.__esModule = true;
            t.History = void 0;
            var r = function() {
                function e() {}
                return e;
            }();
            t.History = r;
        },
        2722: function(e, t, r) {
            "use strict";
            t.__esModule = true;
            t.ColorMap = t.Palette = void 0;
            var o = r(5521);
            var u = r(2037);
            var n = function() {
                function n(e, t, r, n) {
                    this.id = e;
                    this.name = t;
                    this.groupId = r;
                    this.colors = n;
                }
                n.createUserPalette = function(e, t, r) {
                    return new n((0, o.nanoid)(), e, t, r);
                };
                n.prototype.getId = function() {
                    return this.id;
                };
                n.prototype.getName = function() {
                    return this.name;
                };
                n.prototype.getGroupId = function() {
                    return this.groupId;
                };
                n.prototype.getColors = function() {
                    return this.colors;
                };
                n.prototype.serialize = function() {
                    return {
                        id: this.id,
                        name: this.name,
                        colors: this.colors.getHexValues()
                    };
                };
                return n;
            }();
            t.Palette = n;
            var i = function() {
                function e(e) {
                    if (e === void 0) {
                        e = [];
                    }
                    this.entries = e;
                }
                e.prototype.getSize = function() {
                    return this.entries.length;
                };
                e.prototype.getEntries = function() {
                    return this.entries;
                };
                e.prototype.hasColor = function(e) {
                    return this.getColorValue(e) != null;
                };
                e.prototype.getColorValue = function(e) {
                    for (var t = 0, r = this.entries; t < r.length; t++) {
                        var n = r[t], o = n[0], i = n[1];
                        if (o === e) {
                            return i;
                        }
                    }
                    return null;
                };
                e.prototype.addColorValue = function(e, t) {
                    this.entries.push([ e, t ]);
                };
                e.prototype.getHexValues = function() {
                    var e = [];
                    for (var t = 0, r = this.entries; t < r.length; t++) {
                        var n = r[t], o = n[1];
                        e.push((0, u.colorToHexString)(o));
                    }
                    return e;
                };
                e.prototype.isEqual = function(e) {
                    if (this.getSize() !== e.getSize()) return false;
                    for (var t = 0, r = this.entries; t < r.length; t++) {
                        var n = r[t], o = n[0], i = n[1];
                        var a = e.getColorValue(o);
                        if (a == null || !(0, u.isColorValueEqual)(i, a)) {
                            return false;
                        }
                    }
                    return true;
                };
                return e;
            }();
            t.ColorMap = i;
        },
        9860: function(e, t, r) {
            "use strict";
            var n = r(9185);
            var i = this && this.__extends || function() {
                var n = function(e, t) {
                    n = Object.setPrototypeOf || {
                        __proto__: []
                    } instanceof Array && function(e, t) {
                        e.__proto__ = t;
                    } || function(e, t) {
                        for (var r in t) if (Object.prototype.hasOwnProperty.call(t, r)) e[r] = t[r];
                    };
                    return n(e, t);
                };
                return function(e, t) {
                    if (typeof t !== "function" && t !== null) throw new TypeError("Class extends value " + String(t) + " is not a constructor or null");
                    n(e, t);
                    function r() {
                        this.constructor = e;
                    }
                    e.prototype = t === null ? Object.create(t) : (r.prototype = t.prototype, 
                    new r());
                };
            }();
            t.__esModule = true;
            t.AggregateProperty = void 0;
            var o = r(7638);
            var s = r(9388);
            var a = function(u) {
                i(o, u);
                function o() {
                    var e = u !== null && u.apply(this, arguments) || this;
                    e.properties = [];
                    e.attributes = undefined;
                    return e;
                }
                o.fromProperty = function(e) {
                    if (e instanceof o) return e;
                    var t = new o(e.events, e.name);
                    t.addProperty(e);
                    return t;
                };
                o.prototype.getAggregatedProperties = function() {
                    return this.properties;
                };
                o.prototype.getAttributes = function() {
                    return this.attributes;
                };
                o.prototype.setAttributes = function(e) {
                    this.attributes = e;
                };
                o.prototype.addProperty = function(e) {
                    var t;
                    var r = e.getValueDefinition();
                    var n = this.definition != null ? this.definition.mergeWith(r) : r;
                    if (n == null) return false;
                    this.definition = n;
                    if (e instanceof o) {
                        (t = this.properties).push.apply(t, e.properties);
                    } else {
                        this.properties.push(e);
                    }
                    return true;
                };
                o.prototype.isResetSupported = function() {
                    return (0, s.every)(this.properties, function(e) {
                        return e.isResetSupported();
                    });
                };
                o.prototype.shouldIncludeInPreset = function() {
                    return (0, s.every)(this.properties, function(e) {
                        return e.shouldIncludeInPreset();
                    });
                };
                o.prototype.getValueDefinition = function() {
                    if (this.definition == null) {
                        throw new Error("Value definition not set for aggregate property");
                    }
                    return this.definition;
                };
                o.prototype.fetchValueFromSource = function() {
                    var e = (0, s.map)(this.properties, function(e) {
                        return e.fetchValueFromSource();
                    });
                    return n.all(e).then(function(e) {
                        if (e.length === 0) return null;
                        var t = e[0];
                        for (var r = 1; r < e.length; r++) {
                            var n = e[r];
                            if ((0, s.isArray)(n) && (0, s.isArray)(t)) {
                                t = c(t, n);
                                continue;
                            }
                            if (n !== t) {
                                return null;
                            }
                        }
                        return t;
                    });
                };
                o.prototype.updateValueInSource = function(t, r) {
                    var e = (0, s.map)(this.properties, function(e) {
                        return e.updateValueInSource(t, r);
                    });
                    return n.all(e).then(function() {});
                };
                o.prototype.resetValueInSource = function() {
                    var e = (0, s.map)(this.properties, function(e) {
                        return e.resetValueInSource();
                    });
                    return n.all(e).then(function() {});
                };
                o.prototype.getActionNames = function() {
                    var r = this;
                    var n = u.prototype.getActionNames.call(this);
                    if (this.properties.length === 0) return n;
                    var e = [];
                    for (var t in this.properties[0].actions) {
                        e.push(t);
                    }
                    var o = function(t) {
                        e = (0, s.filter)(e, function(e) {
                            return r.properties[t].actions[e] != null;
                        });
                    };
                    for (var i = 1; i < this.properties.length; i++) {
                        o(i);
                    }
                    var a = function(t) {
                        if (!(0, s.some)(e, function(e) {
                            return e === n[t];
                        })) e.push(n[t]);
                    };
                    for (var i = 0; i < n.length; i++) {
                        a(i);
                    }
                    return e;
                };
                o.prototype.callAction = function(t, r) {
                    if (this.actions[t]) {
                        return u.prototype.callAction.call(this, t, r);
                    }
                    if (this.properties.length === 0) {
                        return u.prototype.callAction.call(this, t, r);
                    }
                    return n.all((0, s.map)(this.properties, function(e) {
                        return e.callAction(t, r);
                    })).then(function(e) {
                        return e[0];
                    });
                };
                return o;
            }(o.Property);
            t.AggregateProperty = a;
            function c(e, t) {
                if (e.length !== t.length) return null;
                var r = e.slice();
                for (var n = 0; n < e.length; n++) {
                    if (e[n] !== t[n]) {
                        r[n] = null;
                    }
                }
                return r;
            }
        },
        6280: function(e, t, r) {
            "use strict";
            var u = r(9185);
            var n = this && this.__extends || function() {
                var n = function(e, t) {
                    n = Object.setPrototypeOf || {
                        __proto__: []
                    } instanceof Array && function(e, t) {
                        e.__proto__ = t;
                    } || function(e, t) {
                        for (var r in t) if (Object.prototype.hasOwnProperty.call(t, r)) e[r] = t[r];
                    };
                    return n(e, t);
                };
                return function(e, t) {
                    if (typeof t !== "function" && t !== null) throw new TypeError("Class extends value " + String(t) + " is not a constructor or null");
                    n(e, t);
                    function r() {
                        this.constructor = e;
                    }
                    e.prototype = t === null ? Object.create(t) : (r.prototype = t.prototype, 
                    new r());
                };
            }();
            t.__esModule = true;
            t.PaletteProperty = void 0;
            var o = r(7638);
            var s = r(2722);
            var c = r(5938);
            var l = r(3721);
            var p = r(2037);
            var f = r(9388);
            var i = function(i) {
                n(a, i);
                function a(e, t, r, n) {
                    var o = i.call(this, e, "Color Palette") || this;
                    o.repository = t;
                    o.paletteGroupId = r;
                    o.properties = n;
                    o.valueDefinition = new c.PaletteValueDefinition(o.paletteGroupId, o.getPaletteCollection());
                    return o;
                }
                a.create = function(e, t, r, n) {
                    var o = d(r);
                    return new a(e, t, n, o);
                };
                a.prototype.shouldIncludeInPreset = function() {
                    return false;
                };
                a.prototype.getValueDefinition = function() {
                    return this.valueDefinition;
                };
                a.prototype.fetchValueFromSource = function() {
                    var e = this;
                    var t = this.getAllPalettes();
                    var r = (0, f.map)(t, function(t) {
                        return e.matchPalette(t).then(function(e) {
                            return [ t, e ];
                        });
                    });
                    return u.all(r).then(function(e) {
                        for (var t = 0, r = e; t < r.length; t++) {
                            var n = r[t], o = n[0], i = n[1];
                            if (i) return o.getId();
                        }
                        return "";
                    });
                };
                a.prototype.updateValueInSource = function(e, t) {
                    if (t) return u.reject(new Error("Relative update not supported"));
                    var r = this.getPaletteById(e);
                    var n = r.getColors();
                    var o = (0, f.map)(this.properties, function(e) {
                        var t = n.getColorValue(e.name);
                        if (t == null) return u.resolve();
                        return e.updateValueInSource(t, false);
                    });
                    return u.all(o).then(function() {});
                };
                a.prototype.savePalette = function(t) {
                    var r = this;
                    var n = new s.ColorMap();
                    var e = (0, f.map)(this.properties, function(t) {
                        return t.fetchValueFromSource().then(function(e) {
                            n.addColorValue(t.name, e);
                        });
                    });
                    return u.all(e).then(function() {
                        var e = s.Palette.createUserPalette(t, r.paletteGroupId, n);
                        r.repository.addUserPalette(e);
                    });
                };
                a.prototype.getPaletteCollection = function() {
                    if (!this.paletteGroupId) return l.emptyPaletteCollection;
                    var e = [];
                    for (var t = 0, r = this.properties; t < r.length; t++) {
                        var n = r[t];
                        e.push(n.name);
                    }
                    return this.repository.getPalettes(this.paletteGroupId, e);
                };
                a.prototype.getAllPalettes = function() {
                    var e = this.getPaletteCollection();
                    return [].concat(e.user, e.similar, e.product);
                };
                a.prototype.getPaletteById = function(e) {
                    var t = this.getAllPalettes();
                    for (var r = 0, n = t; r < n.length; r++) {
                        var o = n[r];
                        if (o.getId() === e) {
                            return o;
                        }
                    }
                    throw new Error("Palette not found");
                };
                a.prototype.matchPalette = function(e) {
                    var r = e.getColors();
                    if (r.getSize() !== this.properties.length) return u.resolve(false);
                    var t = (0, f.map)(this.properties, function(e) {
                        var t = r.getColorValue(e.name);
                        if (t == null) return false;
                        return e.fetchValueFromSource().then(function(e) {
                            return (0, p.isColorValueEqual)(t, e);
                        });
                    });
                    return u.all(t).then(function(e) {
                        return (0, f.every)(e, function(e) {
                            return e;
                        });
                    });
                };
                return a;
            }(o.Property);
            t.PaletteProperty = i;
            function d(e) {
                var t;
                var r = [];
                if (((t = e.property) === null || t === void 0 ? void 0 : t.getValueDefinition().getName()) === "Color") {
                    r.push(e.property);
                }
                for (var n = 0, o = e.children; n < o.length; n++) {
                    var i = o[n];
                    r.push.apply(r, d(i));
                }
                return r;
            }
        },
        924: function(e, t, r) {
            "use strict";
            var s = r(9185);
            var n = this && this.__extends || function() {
                var n = function(e, t) {
                    n = Object.setPrototypeOf || {
                        __proto__: []
                    } instanceof Array && function(e, t) {
                        e.__proto__ = t;
                    } || function(e, t) {
                        for (var r in t) if (Object.prototype.hasOwnProperty.call(t, r)) e[r] = t[r];
                    };
                    return n(e, t);
                };
                return function(e, t) {
                    if (typeof t !== "function" && t !== null) throw new TypeError("Class extends value " + String(t) + " is not a constructor or null");
                    n(e, t);
                    function r() {
                        this.constructor = e;
                    }
                    e.prototype = t === null ? Object.create(t) : (r.prototype = t.prototype, 
                    new r());
                };
            }();
            t.__esModule = true;
            t.PresetProperty = t.PresetValueDefinition = void 0;
            var o = r(7638);
            var i = r(6373);
            var a = r(5938);
            var c = function(e) {
                n(t, e);
                function t() {
                    return e !== null && e.apply(this, arguments) || this;
                }
                t.prototype.getName = function() {
                    return "PropertyTreePreset";
                };
                return t;
            }(a.ValueDefinition);
            t.PresetValueDefinition = c;
            var u = function(u) {
                n(e, u);
                function e(e, t, r, n, o, i) {
                    var a = u.call(this, e, t) || this;
                    a.history = r;
                    a.repository = n;
                    a.tree = o;
                    a.mogrtName = i;
                    a.registerAction("getAvailablePresets", a.getAvailablePresets);
                    a.registerAction("apply", a.applyPreset);
                    a.registerAction("saveAs", a.savePreset);
                    a.registerAction("remove", a.removePreset);
                    return a;
                }
                e.prototype.shouldIncludeInPreset = function() {
                    return false;
                };
                e.prototype.wantsRevealEditTab = function() {
                    return false;
                };
                e.prototype.getValueDefinition = function() {
                    return new c();
                };
                e.prototype.fetchValueFromSource = function() {
                    return s.resolve(null);
                };
                e.prototype.updateValueInSource = function(e, t) {
                    return s.resolve();
                };
                e.prototype.getPresetCollection = function() {
                    var e = this.repository.getPresets();
                    return i.TreePresetCollection.createForTree(e, this.tree, this.mogrtName);
                };
                e.prototype.getAvailablePresets = function() {
                    var e = this.getPresetCollection();
                    var t = {
                        presets: [],
                        matchingPreset: null
                    };
                    var r = e.getCompatiblePresets();
                    for (var n = 0, o = r; n < o.length; n++) {
                        var i = o[n];
                        t.presets.push({
                            id: i.getId(),
                            name: i.getName()
                        });
                    }
                    var a = e.getMatchingPreset();
                    if (a) t.matchingPreset = a.getId();
                    return s.resolve(t);
                };
                e.prototype.applyPreset = function(e) {
                    var t = this;
                    var r = this.getPresetCollection();
                    var n = r.getPresetById(e.id);
                    if (!n) return s.resolve(false);
                    return this.history.executeTransaction(function() {
                        return n.applyToTree(t.tree);
                    }).then(function() {
                        return true;
                    });
                };
                e.prototype.savePreset = function(e) {
                    var t = i.TreePreset.createFromTree(this.tree, e.name, this.mogrtName);
                    this.repository.savePreset(t);
                    return s.resolve();
                };
                e.prototype.removePreset = function(e) {
                    this.repository.deletePreset(e.id);
                    return s.resolve();
                };
                return e;
            }(o.Property);
            t.PresetProperty = u;
        },
        7638: function(e, t, r) {
            "use strict";
            var n = r(9185);
            t.__esModule = true;
            t.Property = void 0;
            var o = function() {
                function e(e, t) {
                    this.actions = {};
                    this.events = e;
                    this.id = a();
                    this.name = t;
                }
                e.prototype.isResetSupported = function() {
                    return false;
                };
                e.prototype.shouldIncludeInPreset = function() {
                    return true;
                };
                e.prototype.getValue = function() {
                    return this.value;
                };
                e.prototype.setValue = function(e, t) {
                    var r = this;
                    return this.updateValueInSource(e, t).then(function() {
                        return r.updateValue();
                    });
                };
                e.prototype.resetValue = function() {
                    var e = this;
                    if (!this.isResetSupported()) return n.resolve();
                    return this.resetValueInSource().then(function() {
                        return e.updateValue();
                    });
                };
                e.prototype.initializeValue = function() {
                    var t = this;
                    return this.fetchValueFromSource().then(function(e) {
                        t.value = e;
                    });
                };
                e.prototype.updateValue = function() {
                    var r = this;
                    return this.fetchValueFromSource().then(function(e) {
                        var t = r.getValueDefinition();
                        if (t.isValueEqual(r.value, e)) return;
                        r.value = e;
                        r.events.notifyPropertyValueChanged(r.id, e);
                    });
                };
                e.prototype.serialize = function() {
                    var e = this.getValueDefinition();
                    return {
                        id: this.id,
                        name: this.name,
                        resetSupported: this.isResetSupported(),
                        def: e.serialize(),
                        valueType: e.getName(),
                        value: this.getValue(),
                        actions: this.getActionNames(),
                        attributes: this.getAttributes()
                    };
                };
                e.prototype.resetValueInSource = function() {
                    return n.resolve();
                };
                e.prototype.wantsRevealEditTab = function() {
                    return true;
                };
                e.prototype.registerAction = function(e, t) {
                    var r = this;
                    if (this.actions[e]) {
                        throw new Error("Action ".concat(e, " already registered"));
                    }
                    this.actions[e] = function(e) {
                        return t.call(r, e);
                    };
                };
                e.prototype.getActionNames = function() {
                    var e = [];
                    for (var t in this.actions) {
                        e.push(t);
                    }
                    return e;
                };
                e.prototype.callAction = function(e, t) {
                    if (!this.actions[e]) {
                        throw new Error("Action ".concat(e, " not registered"));
                    }
                    return this.actions[e](t);
                };
                e.prototype.getAttributes = function() {
                    return;
                };
                return e;
            }();
            t.Property = o;
            var i = 1;
            function a() {
                var e = i++;
                return e.toString(16);
            }
        },
        5938: function(e, t, r) {
            "use strict";
            var a = this && this.__extends || function() {
                var n = function(e, t) {
                    n = Object.setPrototypeOf || {
                        __proto__: []
                    } instanceof Array && function(e, t) {
                        e.__proto__ = t;
                    } || function(e, t) {
                        for (var r in t) if (Object.prototype.hasOwnProperty.call(t, r)) e[r] = t[r];
                    };
                    return n(e, t);
                };
                return function(e, t) {
                    if (typeof t !== "function" && t !== null) throw new TypeError("Class extends value " + String(t) + " is not a constructor or null");
                    n(e, t);
                    function r() {
                        this.constructor = e;
                    }
                    e.prototype = t === null ? Object.create(t) : (r.prototype = t.prototype, 
                    new r());
                };
            }();
            t.__esModule = true;
            t.createValueDefinitionFromControl = t.MediaValueDefinition = t.CommentValueDefinition = t.PaletteValueDefinition = t.TimeValueDefinition = t.DropdownValueDefinition = t.Point2DValueDefinition = t.ColorValueDefinition = t.AngleValueDefinition = t.SliderValueDefinition = t.CheckboxValueDefinition = t.NoValueDefinition = t.ValueDefinition = void 0;
            var o = r(9388);
            var n = r(4559);
            var i = r(8736);
            var u = r(2037);
            var s = r(951);
            var c = function() {
                function e() {}
                e.prototype.mergeWith = function(e) {
                    if (this.getName() !== e.getName()) return null;
                    return this;
                };
                e.prototype.isValueValid = function(e) {
                    return true;
                };
                e.prototype.isValueEqual = function(e, t) {
                    return e === t;
                };
                e.prototype.serialize = function() {
                    return {};
                };
                return e;
            }();
            t.ValueDefinition = c;
            var l = function(e) {
                a(t, e);
                function t() {
                    return e !== null && e.apply(this, arguments) || this;
                }
                t.prototype.getName = function() {
                    return "NoValue";
                };
                return t;
            }(c);
            t.NoValueDefinition = l;
            var p = function(e) {
                a(t, e);
                function t() {
                    return e !== null && e.apply(this, arguments) || this;
                }
                t.prototype.getName = function() {
                    return "Checkbox";
                };
                t.prototype.isValueValid = function(e) {
                    return typeof e === "boolean";
                };
                return t;
            }(c);
            t.CheckboxValueDefinition = p;
            var f = function(o) {
                a(r, o);
                function r(e, t, r) {
                    var n = o.call(this) || this;
                    n.sliderMin = e;
                    n.sliderMax = t;
                    n.percent = r;
                    return n;
                }
                r.prototype.getName = function() {
                    return "Slider";
                };
                r.prototype.mergeWith = function(e) {
                    if (e instanceof r) {
                        var t = this.getRangeOverlap(e);
                        if (t != null && this.percent === e.percent) {
                            return new r(t[0], t[1], this.percent);
                        } else {
                            return null;
                        }
                    }
                    return null;
                };
                r.prototype.isValueValid = function(e) {
                    return typeof e === "number";
                };
                r.prototype.isValueEqual = function(e, t) {
                    return (0, i.isNumberClose)(e, t);
                };
                r.prototype.serialize = function() {
                    return {
                        sliderMin: this.sliderMin,
                        sliderMax: this.sliderMax,
                        validMin: this.sliderMin,
                        validMax: this.sliderMax,
                        precision: 2,
                        percent: this.percent,
                        suffix: ""
                    };
                };
                r.prototype.getRangeOverlap = function(e) {
                    var t = Math.max(this.sliderMin, e.sliderMin);
                    var r = Math.min(this.sliderMax, e.sliderMax);
                    if (r - t > .9) {
                        return [ t, r ];
                    } else {
                        return null;
                    }
                };
                return r;
            }(c);
            t.SliderValueDefinition = f;
            var d = function(e) {
                a(t, e);
                function t() {
                    return e !== null && e.apply(this, arguments) || this;
                }
                t.prototype.getName = function() {
                    return "Angle";
                };
                t.prototype.isValueValid = function(e) {
                    return typeof e === "number";
                };
                t.prototype.isValueEqual = function(e, t) {
                    return (0, i.isNumberClose)(e, t);
                };
                return t;
            }(c);
            t.AngleValueDefinition = d;
            var h = function(e) {
                a(t, e);
                function t() {
                    return e !== null && e.apply(this, arguments) || this;
                }
                t.prototype.getName = function() {
                    return "Color";
                };
                t.prototype.isValueValid = function(e) {
                    return (0, u.isColorValue)(e);
                };
                t.prototype.isValueEqual = function(e, t) {
                    if ((0, u.isColorValue)(e) && (0, u.isColorValue)(t)) {
                        return (0, u.isColorValueEqual)(e, t);
                    }
                    return false;
                };
                return t;
            }(c);
            t.ColorValueDefinition = h;
            var v = function(n) {
                a(e, n);
                function e(e, t) {
                    var r = n.call(this) || this;
                    r.percent = e;
                    r.constrained = t;
                    return r;
                }
                e.prototype.getName = function() {
                    return "Point";
                };
                e.prototype.serialize = function() {
                    return {
                        dimensions: 2,
                        percent: this.percent,
                        constrained: this.constrained
                    };
                };
                e.prototype.isValueValid = function(e) {
                    return (0, o.isNumberOrNullArray)(e) && e.length === 2;
                };
                e.prototype.isValueEqual = function(e, t) {
                    if ((0, o.isNumberArray)(e) && (0, o.isNumberArray)(t)) {
                        return (0, s.isPointValueEqual)(e, t);
                    }
                    return false;
                };
                return e;
            }(c);
            t.Point2DValueDefinition = v;
            var y = function(r) {
                a(e, r);
                function e(e) {
                    var t = r.call(this) || this;
                    t.options = e;
                    return t;
                }
                e.prototype.getName = function() {
                    return "Dropdown";
                };
                e.prototype.serialize = function() {
                    return {
                        options: this.options
                    };
                };
                e.prototype.isValueValid = function(e) {
                    return typeof e === "number" && this.hasOption(e);
                };
                e.prototype.hasOption = function(e) {
                    return e > 0 && e <= this.options.length;
                };
                return e;
            }(c);
            t.DropdownValueDefinition = y;
            var g = function(i) {
                a(e, i);
                function e(e, t, r, n) {
                    var o = i.call(this) || this;
                    o.frameDuration = e;
                    o.dropFrame = t;
                    o.validMin = r;
                    o.validMax = n;
                    return o;
                }
                e.prototype.getName = function() {
                    return "Time";
                };
                e.prototype.isValueValid = function(e) {
                    return typeof e === "number";
                };
                e.prototype.serialize = function() {
                    return {
                        frameDuration: this.frameDuration,
                        dropframe: this.dropFrame,
                        validMin: this.validMin,
                        validMax: this.validMax
                    };
                };
                return e;
            }(c);
            t.TimeValueDefinition = g;
            var m = function(n) {
                a(t, n);
                function t(e, t) {
                    var r = n.call(this) || this;
                    r.paletteGroupId = e;
                    r.palettes = t;
                    return r;
                }
                t.prototype.getName = function() {
                    return "Palette";
                };
                t.prototype.mergeWith = function(e) {
                    if (e instanceof t && this.paletteGroupId === e.paletteGroupId) {
                        return this;
                    }
                    return null;
                };
                t.prototype.serialize = function() {
                    return {
                        availablePalettes: {
                            predefined: T(this.palettes.product),
                            user: T(this.palettes.user),
                            similar: T(this.palettes.similar)
                        }
                    };
                };
                return t;
            }(c);
            t.PaletteValueDefinition = m;
            var P = function(r) {
                a(e, r);
                function e(e) {
                    var t = r.call(this) || this;
                    t.comment = e;
                    return t;
                }
                e.prototype.getName = function() {
                    return "Comment";
                };
                e.prototype.serialize = function() {
                    return {
                        comment: this.comment
                    };
                };
                return e;
            }(c);
            t.CommentValueDefinition = P;
            var C = function(e) {
                a(t, e);
                function t() {
                    return e !== null && e.apply(this, arguments) || this;
                }
                t.prototype.getName = function() {
                    return "Media Replacement";
                };
                t.prototype.isValueValid = function() {
                    return false;
                };
                return t;
            }(c);
            t.MediaValueDefinition = C;
            function T(e) {
                var t = [];
                for (var r = 0, n = e; r < n.length; r++) {
                    var o = n[r];
                    t.push(o.serialize());
                }
                return t;
            }
            function x(e, t) {
                switch (e.type) {
                  case n.ControlType.Checkbox:
                    return new p();

                  case n.ControlType.Slider:
                    {
                        var r = I(e, t);
                        return new f(e.sliderMin, e.sliderMax, r);
                    }

                  case n.ControlType.Angle:
                    return new d();

                  case n.ControlType.Color:
                    return new h();

                  case n.ControlType.Point2D:
                    return new v();

                  case n.ControlType.Point2DExt:
                    return new v(e.decimalType == 100, e.constrained);

                  case n.ControlType.Dropdown:
                    return new y(e.items);

                  case n.ControlType.Comment:
                    return new P(e.comment);

                  case n.ControlType.Media:
                    return new C();

                  default:
                    return null;
                }
            }
            t.createValueDefinitionFromControl = x;
            function I(e, t) {
                return e.name === "Speed" && ((t === null || t === void 0 ? void 0 : t.name) === "Animation In" || (t === null || t === void 0 ? void 0 : t.name) === "Animation Out") || /Opacity$/.test(e.name);
            }
        },
        5526: function(e, t, r) {
            "use strict";
            t.__esModule = true;
            t.getPropertyTreeIntersection = t.findPropertyTreeNode = t.filterPropertyTree = void 0;
            var u = r(5802);
            var o = r(9860);
            function s(e, t) {
                if (!t(e)) return null;
                var r = new u.PropertyTreeNode(e.type, e.name, e.property);
                for (var n = 0, o = e.children; n < o.length; n++) {
                    var i = o[n];
                    var a = s(i, t);
                    if (a) r.children.push(a);
                }
                return r;
            }
            t.filterPropertyTree = s;
            function a(e, t) {
                if (t(e)) return e;
                for (var r = 0, n = e.children; r < n.length; r++) {
                    var o = n[r];
                    var i = a(o, t);
                    if (i != null) return i;
                }
                return null;
            }
            t.findPropertyTreeNode = a;
            function c(e, t) {
                var r = l(e, t);
                if (r == null) return null;
                for (var n = 0, o = e.children; n < o.length; n++) {
                    var i = o[n];
                    var a = t.findChildByName(i.name);
                    if (a) {
                        var u = c(a, i);
                        if (u) r.children.push(u);
                    }
                }
                return r;
            }
            t.getPropertyTreeIntersection = c;
            function l(e, t) {
                if (e.type === u.PropertyTreeNodeType.Property && t.type === e.type) {
                    if (e.property == null || t.property == null) return null;
                    var r = o.AggregateProperty.fromProperty(e.property);
                    if (!r.addProperty(t.property)) return null;
                    return new u.PropertyTreeNode(e.type, e.name, r);
                }
                if ((e.type === u.PropertyTreeNodeType.Group || e.type === u.PropertyTreeNodeType.TextPropertiesGroup) && t.type === e.type) {
                    var n = new u.PropertyTreeNode(e.type, e.name);
                    if (e.property != null && t.property != null) {
                        var r = o.AggregateProperty.fromProperty(e.property);
                        if (!r.addProperty(t.property)) return n;
                        n.property = r;
                    }
                    return n;
                }
                if (t.type === e.type) {
                    return new u.PropertyTreeNode(e.type, e.name);
                }
                return null;
            }
        },
        5802: function(e, t, r) {
            "use strict";
            var o = r(9185);
            t.__esModule = true;
            t.serializeNodeType = t.PropertyTreeNode = t.PropertyTreeNodeType = void 0;
            var i = r(9388);
            var n;
            (function(e) {
                e[e["Root"] = 0] = "Root";
                e[e["Section"] = 1] = "Section";
                e[e["Group"] = 2] = "Group";
                e[e["Property"] = 3] = "Property";
                e[e["PresetGroup"] = 4] = "PresetGroup";
                e[e["TextPropertiesGroup"] = 5] = "TextPropertiesGroup";
                e[e["ColorGroup"] = 6] = "ColorGroup";
                e[e["CaptionGroup"] = 7] = "CaptionGroup";
            })(n || (t.PropertyTreeNodeType = n = {}));
            var a = function() {
                function r(e, t, r) {
                    this.children = [];
                    this.type = e;
                    this.name = t;
                    this.property = r;
                }
                r.createRootNode = function() {
                    return new r(n.Root, "");
                };
                r.createSectionNode = function(e) {
                    return new r(n.Section, e);
                };
                r.createGroupNode = function(e) {
                    return new r(n.Group, e);
                };
                r.createTextPropertiesGroupNode = function(e, t) {
                    return new r(n.TextPropertiesGroup, e, t);
                };
                r.createColorGroupNode = function(e) {
                    return new r(n.ColorGroup, e);
                };
                r.createCaptionGroupNode = function(e) {
                    return new r(n.CaptionGroup, e);
                };
                r.createPropertyNode = function(e) {
                    return new r(n.Property, e.name, e);
                };
                r.prototype.isEmpty = function() {
                    return this.children.length === 0;
                };
                r.prototype.addChild = function(e) {
                    this.children.push(e);
                };
                r.prototype.insertChild = function(e, t) {
                    this.children.splice(t, 0, e);
                };
                r.prototype.removeChild = function(e) {
                    for (var t = 0; t < this.children.length; t++) {
                        if (this.children[t] === e) {
                            this.children.splice(t, 1);
                            return;
                        }
                    }
                };
                r.prototype.getPropertyValues = function(e) {
                    if (this.property) {
                        e[this.property.id] = this.property.getValue();
                    }
                    for (var t = 0, r = this.children; t < r.length; t++) {
                        var n = r[t];
                        n.getPropertyValues(e);
                    }
                };
                r.prototype.findPropertyById = function(e) {
                    var t;
                    if (((t = this.property) === null || t === void 0 ? void 0 : t.id) == e) {
                        return this.property;
                    }
                    for (var r = 0, n = this.children; r < n.length; r++) {
                        var o = n[r];
                        var i = o.findPropertyById(e);
                        if (i) return i;
                    }
                    return null;
                };
                r.prototype.findChildByName = function(e) {
                    for (var t = 0, r = this.children; t < r.length; t++) {
                        var n = r[t];
                        if (n.name == e) {
                            return n;
                        }
                    }
                    return null;
                };
                r.prototype.findChildrenByType = function(e) {
                    var t = [];
                    for (var r = 0, n = this.children; r < n.length; r++) {
                        var o = n[r];
                        if (o.type == e) {
                            t.push(o);
                        }
                    }
                    return t;
                };
                r.prototype.initializePropertyValues = function() {
                    var t = this;
                    var e, r;
                    var n = (r = (e = this.property) === null || e === void 0 ? void 0 : e.initializeValue()) !== null && r !== void 0 ? r : o.resolve();
                    return n.then(function() {
                        var e = (0, i.map)(t.children, function(e) {
                            return e.initializePropertyValues();
                        });
                        return o.all(e);
                    }).then(function() {});
                };
                r.prototype.updatePropertyValues = function() {
                    var t = this;
                    var e, r;
                    var n = (r = (e = this.property) === null || e === void 0 ? void 0 : e.updateValue()) !== null && r !== void 0 ? r : o.resolve();
                    return n.then(function() {
                        var e = (0, i.map)(t.children, function(e) {
                            return e.updatePropertyValues();
                        });
                        return o.all(e);
                    }).then(function() {});
                };
                r.prototype.wantsRevealEditTab = function() {
                    var e;
                    if ((e = this.property) === null || e === void 0 ? void 0 : e.wantsRevealEditTab()) return true;
                    for (var t = 0, r = this.children; t < r.length; t++) {
                        var n = r[t];
                        if (n.wantsRevealEditTab()) return true;
                    }
                    return false;
                };
                r.prototype.serialize = function() {
                    var e = {
                        type: u(this.type),
                        name: this.name
                    };
                    if (this.property) {
                        e.property = this.property.serialize();
                    }
                    if (this.children.length > 0) {
                        e.children = [];
                        for (var t = 0, r = this.children; t < r.length; t++) {
                            var n = r[t];
                            e.children.push(n.serialize());
                        }
                    }
                    return e;
                };
                return r;
            }();
            t.PropertyTreeNode = a;
            function u(e) {
                switch (e) {
                  case n.Root:
                    return "root";

                  case n.Section:
                    return "section";

                  case n.Group:
                    return "group";

                  case n.Property:
                    return "property";

                  case n.PresetGroup:
                    return "preset";

                  case n.TextPropertiesGroup:
                    return "text_properties_group";

                  case n.ColorGroup:
                    return "color_group";

                  case n.CaptionGroup:
                    return "caption_group";

                  default:
                    throw new Error("Unknown node type");
                }
            }
            t.serializeNodeType = u;
        },
        3721: function(e, t) {
            "use strict";
            t.__esModule = true;
            t.emptyPaletteCollection = void 0;
            t.emptyPaletteCollection = {
                user: [],
                product: [],
                similar: []
            };
        },
        7521: function(e, t) {
            "use strict";
            t.__esModule = true;
            t.SelectionEditor = void 0;
            var r = function() {
                function e(e, t, r) {
                    if (r === void 0) {
                        r = null;
                    }
                    this.state = e;
                    this.propertyTree = t;
                    this.singleEditor = r;
                }
                e.prototype.serialize = function() {
                    var e;
                    return {
                        numSelectedLayers: this.state.numSelectedItems,
                        selectedLayerName: (e = this.singleEditor) === null || e === void 0 ? void 0 : e.getItemName(),
                        soundApplyOptions: this.state.soundApplyOptions,
                        captionsApplyOptions: this.state.captionsApplyOptions,
                        propertyTree: this.propertyTree.serialize(),
                        wantsRevealEditTab: this.propertyTree.wantsRevealEditTab(),
                        activeCompSize: this.state.activeFrameSize
                    };
                };
                e.prototype.initialize = function() {
                    return this.propertyTree.initializePropertyValues();
                };
                e.prototype.update = function() {
                    var e;
                    (e = this.singleEditor) === null || e === void 0 ? void 0 : e.updateItemName();
                    return this.propertyTree.updatePropertyValues();
                };
                e.prototype.getPropertyTree = function() {
                    return this.propertyTree;
                };
                e.prototype.getSingleEditor = function() {
                    return this.singleEditor;
                };
                return e;
            }();
            t.SelectionEditor = r;
        },
        1115: function(e, t) {
            "use strict";
            t.__esModule = true;
            t.SingleItemEditor = void 0;
            var r = function() {
                function e(e, t) {
                    this.itemName = "";
                    this.events = e;
                    this.compItem = t;
                    this.itemName = t.getName();
                }
                e.prototype.getItemName = function() {
                    return this.itemName;
                };
                e.prototype.updateItemName = function() {
                    var e = this.compItem.getName();
                    if (e == this.itemName) return;
                    this.itemName = e;
                    this.events.notifyEditorReplaced();
                };
                e.prototype.getSourceIdentifier = function() {
                    return this.compItem.getSourceIdentifier();
                };
                return e;
            }();
            t.SingleItemEditor = r;
        },
        6373: function(e, t, r) {
            "use strict";
            var l = r(9185);
            t.__esModule = true;
            t.TreePresetCollection = t.TreePreset = void 0;
            var i = r(5521);
            var c = r(5802);
            var n = r(8736);
            var o = r(2037);
            var a = r(951);
            var u = function() {
                function o(e, t, r, n) {
                    this.id = e;
                    this.name = t;
                    this.mogrtName = r;
                    this.serializedTree = n;
                }
                o.createFromTree = function(e, t, r) {
                    var n = p(e);
                    if (n == null) throw new Error("Tree does not contain any serializable nodes");
                    return new o((0, i.nanoid)(), t, r, n);
                };
                o.prototype.getId = function() {
                    return this.id;
                };
                o.prototype.getName = function() {
                    return this.name;
                };
                o.prototype.getMogrtName = function() {
                    return this.mogrtName;
                };
                o.prototype.getSerializedTree = function() {
                    return this.serializedTree;
                };
                o.prototype.matchTree = function(e) {
                    return v(e, this.serializedTree);
                };
                o.prototype.applyToTree = function(e) {
                    return f(e, this.serializedTree);
                };
                return o;
            }();
            t.TreePreset = u;
            var s = function() {
                function l(e, t) {
                    this.presets = [];
                    this.matching = null;
                    this.presets = e;
                    this.matching = t;
                }
                l.createForTree = function(e, t, r) {
                    var n = p(t);
                    var o = [];
                    var i = null;
                    if (n != null) {
                        for (var a = 0, u = e; a < u.length; a++) {
                            var s = u[a];
                            var c = s.matchTree(n);
                            if (c.structure) {
                                o.push(s);
                                if (c.values && i == null) {
                                    i = s;
                                }
                            }
                        }
                    }
                    return new l(o, i);
                };
                l.prototype.getCompatiblePresets = function() {
                    return this.presets;
                };
                l.prototype.getMatchingPreset = function() {
                    return this.matching;
                };
                l.prototype.getPresetById = function(e) {
                    for (var t = 0, r = this.presets; t < r.length; t++) {
                        var n = r[t];
                        if (n.getId() == e) return n;
                    }
                    return null;
                };
                return l;
            }();
            t.TreePresetCollection = s;
            function p(e) {
                var t;
                var r = [];
                var n = {
                    name: e.name,
                    type: (0, c.serializeNodeType)(e.type)
                };
                if ((t = e.property) === null || t === void 0 ? void 0 : t.shouldIncludeInPreset()) {
                    var o = e.property.getValue();
                    if (o != null) {
                        n.valDef = e.property.getValueDefinition().getName();
                        n.value = o;
                    }
                }
                for (var i = 0, a = e.children; i < a.length; i++) {
                    var u = a[i];
                    var s = p(u);
                    if (s == null) continue;
                    r.push(s);
                    n.children = r;
                }
                if (n.value == null && r.length === 0) {
                    return null;
                }
                return n;
            }
            function v(e, t) {
                var r, n, o, i;
                var a = {
                    structure: true,
                    values: true
                };
                if (e.type !== t.type) a.structure = false;
                if (e.name !== t.name) a.structure = false;
                if (e.valDef !== t.valDef) a.structure = false;
                if (((r = e.children) === null || r === void 0 ? void 0 : r.length) !== ((n = t.children) === null || n === void 0 ? void 0 : n.length)) a.structure = false;
                if (!y(e, t)) a.values = false;
                if (!a.structure) return a;
                for (var u = 0, s = (o = e.children) !== null && o !== void 0 ? o : []; u < s.length; u++) {
                    var c = s[u];
                    var l = {
                        structure: false,
                        values: false
                    };
                    for (var p = 0, f = (i = t.children) !== null && i !== void 0 ? i : []; p < f.length; p++) {
                        var d = f[p];
                        var h = v(c, d);
                        if (h.structure) {
                            l = h;
                            break;
                        }
                    }
                    a.structure = a.structure && l.structure;
                    a.values = a.values && l.values;
                }
                return a;
            }
            function y(e, t) {
                if (e.valDef !== t.valDef) return false;
                switch (e.valDef) {
                  case "Angle":
                  case "Slider":
                    return (0, n.isNumberClose)(e.value, t.value);

                  case "Color":
                    return (0, o.isColorValueEqual)(e.value, t.value);

                  case "Point":
                    return (0, a.isPointValueEqual)(e.value, t.value);

                  default:
                    return e.value === t.value;
                }
            }
            function f(e, t) {
                var r;
                var n = (r = e.property) === null || r === void 0 ? void 0 : r.getValue();
                var o = l.resolve();
                if (e.property != null && t.value != null && n != t.value) {
                    o = e.property.setValue(t.value, false);
                }
                if (t.children == null) {
                    return o;
                }
                var i = [ o ];
                for (var a = 0, u = e.children; a < u.length; a++) {
                    var s = u[a];
                    var c = d(t.children, s);
                    if (c == null) continue;
                    i.push(f(s, c));
                }
                return l.all(i).then(function() {});
            }
            function d(e, t) {
                var r;
                var n = (0, c.serializeNodeType)(t.type);
                var o = (r = t.property) === null || r === void 0 ? void 0 : r.getValueDefinition().getName();
                for (var i = 0, a = e; i < a.length; i++) {
                    var u = a[i];
                    if (t.name === u.name && n === u.type && (u.valDef == null || o === u.valDef)) {
                        return u;
                    }
                }
                return null;
            }
        },
        4425: function(e, t) {
            "use strict";
            t.__esModule = true;
            t.parseClipLabels = t.isClipLocationEqual = t.ClipType = void 0;
            var r;
            (function(e) {
                e[e["Video"] = 1] = "Video";
                e[e["Audio"] = 2] = "Audio";
            })(r || (t.ClipType = r = {}));
            function n(e, t) {
                return e.trackIndex === t.trackIndex && e.clipIndex === t.clipIndex && e.type === t.type;
            }
            t.isClipLocationEqual = n;
            function o(e) {
                var t = {};
                var r = /\s*(\[\w+])\s*/g;
                var n;
                while ((n = r.exec(e)) != null) {
                    var o = n[1].toLowerCase();
                    switch (o) {
                      case "[fit]":
                        t.fitToFrame = true;
                        break;

                      case "[fill]":
                        t.fillFrame = true;
                        break;
                    }
                }
                e = e.replace(r, "");
                return [ t, e ];
            }
            t.parseClipLabels = o;
        },
        9388: function(e, t) {
            "use strict";
            t.__esModule = true;
            t.find = t.filter = t.some = t.every = t.reduce = t.map = t.isNumberArray = t.isNumberOrNullArray = t.isArray = void 0;
            function r(e) {
                return e != null && typeof e === "object" && "length" in e;
            }
            t.isArray = r;
            function n(e) {
                return r(e) && u(e, function(e) {
                    return typeof e === "number" || e === null;
                });
            }
            t.isNumberOrNullArray = n;
            function o(e) {
                return r(e) && u(e, function(e) {
                    return typeof e === "number";
                });
            }
            t.isNumberArray = o;
            function i(e, t) {
                var r = [];
                for (var n = 0; n < e.length; n++) {
                    r.push(t(e[n], n));
                }
                return r;
            }
            t.map = i;
            function a(e, t, r) {
                var n = r;
                for (var o = 0; o < e.length; o++) {
                    n = t(n, e[o], o);
                }
                return n;
            }
            t.reduce = a;
            function u(e, t) {
                for (var r = 0; r < e.length; r++) {
                    if (!t(e[r], r)) {
                        return false;
                    }
                }
                return true;
            }
            t.every = u;
            function s(e, t) {
                for (var r = 0; r < e.length; r++) {
                    if (t(e[r], r)) {
                        return true;
                    }
                }
                return false;
            }
            t.some = s;
            function c(e, t) {
                var r = [];
                for (var n = 0; n < e.length; n++) {
                    if (t(e[n], n)) {
                        r.push(e[n]);
                    }
                }
                return r;
            }
            t.filter = c;
            function l(e, t) {
                for (var r = 0; r < e.length; r++) {
                    if (t(e[r], r)) {
                        return e[r];
                    }
                }
            }
            t.find = l;
        },
        7750: function(e, t) {
            "use strict";
            t.__esModule = true;
            t.atob = t.btoa = void 0;
            function r(e) {
                var t = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
                var r = e;
                var n = "";
                for (var o = 0, i = void 0, a = 0, u = t; r.charAt(a | 0) || (u = "=", 
                a % 1); n += u.charAt(63 & o >> 8 - a % 1 * 8)) {
                    i = r.charCodeAt(a += 3 / 4);
                    if (i > 255) {
                        throw new Error("btoa() failed: The string to be encoded contains characters outside of the Latin1 range.");
                    }
                    o = o << 8 | i;
                }
                return n;
            }
            t.btoa = r;
            function n(e) {
                var t = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
                var r = e.replace(/[=]+$/, "");
                var n = "";
                if (r.length % 4 == 1) {
                    throw new Error("atob() failed: The string to be decoded is not correctly encoded.");
                }
                for (var o = 0, i = 0, a = void 0, u = 0; a = r.charAt(u++); ~a && (i = o % 4 ? i * 64 + a : a, 
                o++ % 4) ? n += String.fromCharCode(255 & i >> (-2 * o & 6)) : 0) {
                    a = t.indexOf(a);
                }
                return n;
            }
            t.atob = n;
        },
        2037: function(e, t, r) {
            "use strict";
            t.__esModule = true;
            t.isColorValueEqual = t.isColorValue = t.colorToHexString = t.hexStringToColor = void 0;
            var n = r(9388);
            var o = r(8736);
            function i(e) {
                if (e.length != 6) {
                    throw new Error("Invalid color hex string");
                }
                var t = parseInt(e.slice(0, 2), 16) / 255;
                var r = parseInt(e.slice(2, 4), 16) / 255;
                var n = parseInt(e.slice(4, 6), 16) / 255;
                return [ t, r, n ];
            }
            t.hexStringToColor = i;
            function a(e) {
                var t = "#";
                for (var r = 0; r < e.length; r++) {
                    var n = Math.round(e[r] * 255);
                    var o = n.toString(16);
                    t += o.length == 1 ? "0" + o : o;
                }
                return t;
            }
            t.colorToHexString = a;
            function u(e) {
                if (!(0, n.isArray)(e)) return false;
                if (e.length !== 3) return false;
                for (var t = 0; t < e.length; t++) {
                    var r = e[t];
                    if (typeof r !== "number") return false;
                    if (r < 0 || r > 1) return false;
                }
                return true;
            }
            t.isColorValue = u;
            function s(e, t) {
                for (var r = 0; r < e.length; r++) {
                    if (!(0, o.isNumberClose)(e[r], t[r], 1e-5)) return false;
                }
                return true;
            }
            t.isColorValueEqual = s;
        },
        4512: function(e, t) {
            "use strict";
            t.__esModule = true;
            t.matchWildcardPattern = void 0;
            function r(e, t) {
                var r = "^" + e.replace(/[.+?^${}()|[\]\\]/g, "\\$&").replace(/\*/g, ".*") + "$";
                var n = new RegExp(r);
                return n.test(t);
            }
            t.matchWildcardPattern = r;
        },
        8736: function(e, t) {
            "use strict";
            t.__esModule = true;
            t.isNumberClose = void 0;
            function r(e, t, r) {
                if (r === void 0) {
                    r = 1e-6;
                }
                return Math.abs(e - t) < r;
            }
            t.isNumberClose = r;
        },
        951: function(e, t, r) {
            "use strict";
            t.__esModule = true;
            t.isPointValueEqual = void 0;
            var n = r(8736);
            function o(e, t) {
                if (e.length !== t.length) return false;
                for (var r = 0; r < e.length; r++) {
                    if (!(0, n.isNumberClose)(e[r], t[r])) return false;
                }
                return true;
            }
            t.isPointValueEqual = o;
        },
        5897: function(e, t) {
            "use strict";
            t.__esModule = true;
            t.Set = void 0;
            var r = function() {
                function e() {
                    this.items = [];
                }
                e.prototype.add = function(e) {
                    if (!this.has(e)) {
                        this.items.push(e);
                    }
                };
                e.prototype.has = function(e) {
                    for (var t = 0, r = this.items; t < r.length; t++) {
                        var n = r[t];
                        if (n === e) return true;
                    }
                    return false;
                };
                e.prototype["delete"] = function(e) {
                    for (var t = 0; t < this.items.length; t++) {
                        var r = this.items[t];
                        if (r === e) {
                            this.items.splice(t, 1);
                            return;
                        }
                    }
                };
                e.prototype.values = function() {
                    return this.items;
                };
                return e;
            }();
            t.Set = r;
        }
    };
    var __webpack_module_cache__ = {};
    function __webpack_require__(e) {
        var t = __webpack_module_cache__[e];
        if (t !== undefined) {
            return t.exports;
        }
        var r = __webpack_module_cache__[e] = {
            exports: {}
        };
        __webpack_modules__[e].call(r.exports, r, r.exports, __webpack_require__);
        return r.exports;
    }
    var __webpack_exports__ = {};
    var bootstrap = __webpack_require__(9091);
    var plugin = __webpack_require__(1091);
    bootstrap.registerPlugin("mh_ac", function() {
        return new plugin.BrowserPlugin();
    });
})();