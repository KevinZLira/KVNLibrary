(function() {
    var n = {
        9091: function(t, e) {
            "use strict";
            e.__esModule = true;
            e.registerPlugin = e.loadPlugin = void 0;
            var r = $;
            function i(t, e) {
                var i = r[e];
                if (i != null) {
                    try {
                        i.destroy();
                    } catch (t) {
                        $.writeln("Failed to unload existing instance of " + e);
                    }
                }
                delete r[e];
                var n = new File(t);
                $.evalFile(n);
            }
            e.loadPlugin = i;
            function n(t, e) {
                if (r[t] != null) return;
                var i = e();
                r[t] = i;
            }
            e.registerPlugin = n;
        },
        6128: function(t, e, i) {
            "use strict";
            e.__esModule = true;
            e.MHTests = void 0;
            var n = i(9091);
            var r = function() {
                function t() {
                    this.initialized = false;
                }
                t.prototype.initExternalObjects = function() {
                    new ExternalObject("lib:PlugPlugExternalObject");
                };
                t.prototype.dispatchReadyEvent = function() {};
                t.prototype.initialize = function() {
                    if (this.initialized) return;
                    this.initExternalObjects();
                    this.dispatchReadyEvent();
                    this.initialized = true;
                };
                t.prototype.destroy = function() {};
                t.prototype.loadTestPlugin = function(t, e) {
                    (0, n.loadPlugin)(t, e);
                };
                return t;
            }();
            e.MHTests = r;
        }
    };
    var r = {};
    function o(t) {
        var e = r[t];
        if (e !== undefined) {
            return e.exports;
        }
        var i = r[t] = {
            exports: {}
        };
        n[t](i, i.exports, o);
        return i.exports;
    }
    var t = {};
    var e = o(9091);
    var i = o(6128);
    e.registerPlugin("mh_ac_tests", function() {
        return new i.MHTests();
    });
})();